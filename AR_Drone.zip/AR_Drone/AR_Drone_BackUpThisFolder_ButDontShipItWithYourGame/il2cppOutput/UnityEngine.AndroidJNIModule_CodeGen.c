﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void UnityEngine.AndroidJavaRunnable::.ctor(System.Object,System.IntPtr)
extern void AndroidJavaRunnable__ctor_m000E4FEB2DE8031A1CD733610D76E2BF60490334 (void);
// 0x00000002 System.Void UnityEngine.AndroidJavaRunnable::Invoke()
extern void AndroidJavaRunnable_Invoke_m98CFB1479B942F71BF29F53CFDAC1CB9DAFAEBE1 (void);
// 0x00000003 System.Void UnityEngine.AndroidJavaException::.ctor(System.String,System.String)
extern void AndroidJavaException__ctor_mD4B5992BB074504F8E86D79EA98752D3CB154541 (void);
// 0x00000004 System.String UnityEngine.AndroidJavaException::get_StackTrace()
extern void AndroidJavaException_get_StackTrace_m28AC922BCC16051CCBA4C7E5F69698264AA7CC27 (void);
// 0x00000005 System.Void UnityEngine.GlobalJavaObjectRef::.ctor(System.IntPtr)
extern void GlobalJavaObjectRef__ctor_mFE5679D1B51F51CBF11721773C0D767286AC22E8 (void);
// 0x00000006 System.Void UnityEngine.GlobalJavaObjectRef::Finalize()
extern void GlobalJavaObjectRef_Finalize_m2EE89F98A391773F885A4A312FD4BD134E0D46D8 (void);
// 0x00000007 System.IntPtr UnityEngine.GlobalJavaObjectRef::op_Implicit(UnityEngine.GlobalJavaObjectRef)
extern void GlobalJavaObjectRef_op_Implicit_m16AE2CD44F8CDE4667F4DA84D2567582544D4F4E (void);
// 0x00000008 System.Void UnityEngine.GlobalJavaObjectRef::Dispose()
extern void GlobalJavaObjectRef_Dispose_m45E67345587866D5A50D250D1C17425110703520 (void);
// 0x00000009 System.Void UnityEngine.AndroidJavaRunnableProxy::.ctor(UnityEngine.AndroidJavaRunnable)
extern void AndroidJavaRunnableProxy__ctor_mB173256AF7629962B226343C4F6F94FFFF7317C3 (void);
// 0x0000000A System.Void UnityEngine.AndroidJavaRunnableProxy::run()
extern void AndroidJavaRunnableProxy_run_m014F4E0A8ED56A054096F2BAC90653716D2A0D46 (void);
// 0x0000000B System.Void UnityEngine.AndroidJavaProxy::.ctor(System.String)
extern void AndroidJavaProxy__ctor_m2832886A0E1BBF6702653A7C6A4609F11FB712C7 (void);
// 0x0000000C System.Void UnityEngine.AndroidJavaProxy::.ctor(UnityEngine.AndroidJavaClass)
extern void AndroidJavaProxy__ctor_mFA05DF6B31FC284C65D378C02A2A34F277DFE6E5 (void);
// 0x0000000D System.Void UnityEngine.AndroidJavaProxy::Finalize()
extern void AndroidJavaProxy_Finalize_m6E4C294F2117D7A07E82A315081C9239AFA217E8 (void);
// 0x0000000E UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaProxy::Invoke(System.String,System.Object[])
extern void AndroidJavaProxy_Invoke_m9D765F3E7DC37C5CB14C4884F2873B48D2F96BFB (void);
// 0x0000000F UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaProxy::Invoke(System.String,UnityEngine.AndroidJavaObject[])
extern void AndroidJavaProxy_Invoke_mCAE9C5E669AD50DE372494E12224FF1F31A43F1D (void);
// 0x00000010 System.Boolean UnityEngine.AndroidJavaProxy::equals(UnityEngine.AndroidJavaObject)
extern void AndroidJavaProxy_equals_mC390139E035408E858940EB523D45ED3C8377110 (void);
// 0x00000011 System.Int32 UnityEngine.AndroidJavaProxy::hashCode()
extern void AndroidJavaProxy_hashCode_m7991233D3D6D5F994E7BC59C3CB65DBBEDF8CA93 (void);
// 0x00000012 System.String UnityEngine.AndroidJavaProxy::toString()
extern void AndroidJavaProxy_toString_mF77EEDD3BB413F1273D9970BFB0D7C388366B256 (void);
// 0x00000013 UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaProxy::GetProxyObject()
extern void AndroidJavaProxy_GetProxyObject_mBFD2FBEF9ED9D4AE23DECF5836E5C73A886E2109 (void);
// 0x00000014 System.IntPtr UnityEngine.AndroidJavaProxy::GetRawProxy()
extern void AndroidJavaProxy_GetRawProxy_m685E066A4D378B596CD88385B954AE90CBF328A9 (void);
// 0x00000015 System.Void UnityEngine.AndroidJavaProxy::.cctor()
extern void AndroidJavaProxy__cctor_mB40E77A0644729A8A761CC80A02E99020DD9790A (void);
// 0x00000016 System.Void UnityEngine.AndroidJavaObject::.ctor(System.String,System.String[])
extern void AndroidJavaObject__ctor_mB47CA3FC88F645DAB31FB0FAAA32E9159B1DB19E (void);
// 0x00000017 System.Void UnityEngine.AndroidJavaObject::.ctor(System.String,UnityEngine.AndroidJavaObject[])
extern void AndroidJavaObject__ctor_m1F1F88504475490860A246714F36205FB7D53362 (void);
// 0x00000018 System.Void UnityEngine.AndroidJavaObject::.ctor(System.String,UnityEngine.AndroidJavaClass[])
extern void AndroidJavaObject__ctor_m262439771D3A3EFBD18E5D06188D11989D562635 (void);
// 0x00000019 System.Void UnityEngine.AndroidJavaObject::.ctor(System.String,UnityEngine.AndroidJavaProxy[])
extern void AndroidJavaObject__ctor_m0F50ADD04B4BEA5ACB6B614BB206EBFA9353CF6B (void);
// 0x0000001A System.Void UnityEngine.AndroidJavaObject::.ctor(System.String,UnityEngine.AndroidJavaRunnable[])
extern void AndroidJavaObject__ctor_mA61E481C9C0F990FF9BEBFE9E1299612BC174E0E (void);
// 0x0000001B System.Void UnityEngine.AndroidJavaObject::.ctor(System.String,System.Object[])
extern void AndroidJavaObject__ctor_m5A65B5D325C2CEFAC4097A0D3813F8E158178DD7 (void);
// 0x0000001C System.Void UnityEngine.AndroidJavaObject::Dispose()
extern void AndroidJavaObject_Dispose_m2B1593C20B3CE1C8FF95982F638F50985F9DD9E6 (void);
// 0x0000001D System.Void UnityEngine.AndroidJavaObject::Call(System.String,T[])
// 0x0000001E System.Void UnityEngine.AndroidJavaObject::Call(System.String,System.Object[])
extern void AndroidJavaObject_Call_mDEF7846E2AB1C5379069BB21049ED55A9D837B1C (void);
// 0x0000001F System.Void UnityEngine.AndroidJavaObject::CallStatic(System.String,T[])
// 0x00000020 System.Void UnityEngine.AndroidJavaObject::CallStatic(System.String,System.Object[])
extern void AndroidJavaObject_CallStatic_mB677DE04369EDD8E6DECAF2F233116EE1F06555C (void);
// 0x00000021 FieldType UnityEngine.AndroidJavaObject::Get(System.String)
// 0x00000022 System.Void UnityEngine.AndroidJavaObject::Set(System.String,FieldType)
// 0x00000023 FieldType UnityEngine.AndroidJavaObject::GetStatic(System.String)
// 0x00000024 System.Void UnityEngine.AndroidJavaObject::SetStatic(System.String,FieldType)
// 0x00000025 System.IntPtr UnityEngine.AndroidJavaObject::GetRawObject()
extern void AndroidJavaObject_GetRawObject_m536F043B5CE2C21369FF6173C9D2A9A62136BC48 (void);
// 0x00000026 System.IntPtr UnityEngine.AndroidJavaObject::GetRawClass()
extern void AndroidJavaObject_GetRawClass_mE4FB4DC4F856A52E10C6AAD0B65BEBF47B5071F5 (void);
// 0x00000027 UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::CloneReference()
extern void AndroidJavaObject_CloneReference_m6DF6E2BF8D91804B303C93C2026E4A39977E8428 (void);
// 0x00000028 ReturnType UnityEngine.AndroidJavaObject::Call(System.String,T[])
// 0x00000029 ReturnType UnityEngine.AndroidJavaObject::Call(System.String,System.Object[])
// 0x0000002A ReturnType UnityEngine.AndroidJavaObject::CallStatic(System.String,T[])
// 0x0000002B ReturnType UnityEngine.AndroidJavaObject::CallStatic(System.String,System.Object[])
// 0x0000002C System.Void UnityEngine.AndroidJavaObject::DebugPrint(System.String)
extern void AndroidJavaObject_DebugPrint_m047934BF3D1E6676FDDBDA038E1AF387C5413533 (void);
// 0x0000002D System.Void UnityEngine.AndroidJavaObject::DebugPrint(System.String,System.String,System.String,System.Object[])
extern void AndroidJavaObject_DebugPrint_m41CA713464E773016D31C1B6C1489AC34A542CE6 (void);
// 0x0000002E System.Void UnityEngine.AndroidJavaObject::_AndroidJavaObject(System.String,System.Object[])
extern void AndroidJavaObject__AndroidJavaObject_m1284CB7198514B8C06A2BF794ACDC909DC26443F (void);
// 0x0000002F System.Void UnityEngine.AndroidJavaObject::.ctor(System.IntPtr)
extern void AndroidJavaObject__ctor_m0CEE7D570807333CE2C193A82AB3AB8D4F873A6B (void);
// 0x00000030 System.Void UnityEngine.AndroidJavaObject::.ctor()
extern void AndroidJavaObject__ctor_m67B4EEAB015B123D5A3EDCAD914B4795A3B67F04 (void);
// 0x00000031 System.Void UnityEngine.AndroidJavaObject::Finalize()
extern void AndroidJavaObject_Finalize_m87374EE46B27BE3559CACED8A1B62475200AB5AA (void);
// 0x00000032 System.Void UnityEngine.AndroidJavaObject::Dispose(System.Boolean)
extern void AndroidJavaObject_Dispose_m87886676A84FA079C0FE45E6C31D790D764652BE (void);
// 0x00000033 System.Void UnityEngine.AndroidJavaObject::_Call(System.String,System.Object[])
extern void AndroidJavaObject__Call_m4C4D7D7287030773175BDF47681EA018DFA4DF1A (void);
// 0x00000034 ReturnType UnityEngine.AndroidJavaObject::_Call(System.String,System.Object[])
// 0x00000035 FieldType UnityEngine.AndroidJavaObject::_Get(System.String)
// 0x00000036 System.Void UnityEngine.AndroidJavaObject::_Set(System.String,FieldType)
// 0x00000037 System.Void UnityEngine.AndroidJavaObject::_CallStatic(System.String,System.Object[])
extern void AndroidJavaObject__CallStatic_mD63902D30CD5626DAEAD1D6484AF7A9ACA85590E (void);
// 0x00000038 ReturnType UnityEngine.AndroidJavaObject::_CallStatic(System.String,System.Object[])
// 0x00000039 FieldType UnityEngine.AndroidJavaObject::_GetStatic(System.String)
// 0x0000003A System.Void UnityEngine.AndroidJavaObject::_SetStatic(System.String,FieldType)
// 0x0000003B UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::AndroidJavaObjectDeleteLocalRef(System.IntPtr)
extern void AndroidJavaObject_AndroidJavaObjectDeleteLocalRef_mB1EEE323CA333E5DB2871794F1E9094E488682E2 (void);
// 0x0000003C UnityEngine.AndroidJavaClass UnityEngine.AndroidJavaObject::AndroidJavaClassDeleteLocalRef(System.IntPtr)
extern void AndroidJavaObject_AndroidJavaClassDeleteLocalRef_m54CF986C577935C4B4FDC72612CCE0F13079AD08 (void);
// 0x0000003D ReturnType UnityEngine.AndroidJavaObject::FromJavaArrayDeleteLocalRef(System.IntPtr)
// 0x0000003E System.IntPtr UnityEngine.AndroidJavaObject::_GetRawObject()
extern void AndroidJavaObject__GetRawObject_mC5B8B60BEF515F5EE2A113D60991A433DA740C69 (void);
// 0x0000003F System.IntPtr UnityEngine.AndroidJavaObject::_GetRawClass()
extern void AndroidJavaObject__GetRawClass_m470EAEBF8B0BD365FD13F1C6F55119836452FDFA (void);
// 0x00000040 System.Void UnityEngine.AndroidJavaClass::.ctor(System.String)
extern void AndroidJavaClass__ctor_mB5466169E1151B8CC44C8FED234D79984B431389 (void);
// 0x00000041 System.Void UnityEngine.AndroidJavaClass::_AndroidJavaClass(System.String)
extern void AndroidJavaClass__AndroidJavaClass_mF481A9584D78F32C64219FDA49CB84B6F0A017DD (void);
// 0x00000042 System.Void UnityEngine.AndroidJavaClass::.ctor(System.IntPtr)
extern void AndroidJavaClass__ctor_mB206D3CB990755BD56E308F61CD43BB9EA4421D0 (void);
// 0x00000043 System.Boolean UnityEngine.AndroidReflection::IsPrimitive(System.Type)
extern void AndroidReflection_IsPrimitive_m48ED73958206D552B937EEC7560184C6C4228F3D (void);
// 0x00000044 System.Boolean UnityEngine.AndroidReflection::IsAssignableFrom(System.Type,System.Type)
extern void AndroidReflection_IsAssignableFrom_mE4CCA11A87A7E49591786C98FFE239D6EA66F8C5 (void);
// 0x00000045 System.IntPtr UnityEngine.AndroidReflection::GetStaticMethodID(System.String,System.String,System.String)
extern void AndroidReflection_GetStaticMethodID_mA7CC0C6E85BD03EA4BFDA8FAF883A4FF9B721C3E (void);
// 0x00000046 System.IntPtr UnityEngine.AndroidReflection::GetMethodID(System.String,System.String,System.String)
extern void AndroidReflection_GetMethodID_m7773DFE09DED5E42B5E6A607A4318318141104E5 (void);
// 0x00000047 System.IntPtr UnityEngine.AndroidReflection::GetConstructorMember(System.IntPtr,System.String)
extern void AndroidReflection_GetConstructorMember_m79D508363805E1AD5FC551644355A1DCF5A01A8A (void);
// 0x00000048 System.IntPtr UnityEngine.AndroidReflection::GetMethodMember(System.IntPtr,System.String,System.String,System.Boolean)
extern void AndroidReflection_GetMethodMember_m6EAFD27B17549F9EF623F5E6341DCAC9E33528CE (void);
// 0x00000049 System.IntPtr UnityEngine.AndroidReflection::GetFieldMember(System.IntPtr,System.String,System.String,System.Boolean)
extern void AndroidReflection_GetFieldMember_m66A8627EBBE89FFAF125264309A85E5001FCEEC3 (void);
// 0x0000004A System.IntPtr UnityEngine.AndroidReflection::GetFieldClass(System.IntPtr)
extern void AndroidReflection_GetFieldClass_m394CE3986B992FB51CDA6F18031A4D6390956E00 (void);
// 0x0000004B System.String UnityEngine.AndroidReflection::GetFieldSignature(System.IntPtr)
extern void AndroidReflection_GetFieldSignature_m9684AAB2E8AAB2DA4CE2A9DCC18C9088C5E82194 (void);
// 0x0000004C System.IntPtr UnityEngine.AndroidReflection::NewProxyInstance(System.IntPtr,System.IntPtr)
extern void AndroidReflection_NewProxyInstance_m06C9BF6A4805DDEED85EC565CDED394E15F2E793 (void);
// 0x0000004D System.Void UnityEngine.AndroidReflection::SetNativeExceptionOnProxy(System.IntPtr,System.Exception,System.Boolean)
extern void AndroidReflection_SetNativeExceptionOnProxy_m3AD392FDF28A10F33D16C0BE27A12D31B2C0883F (void);
// 0x0000004E System.Void UnityEngine.AndroidReflection::.cctor()
extern void AndroidReflection__cctor_m8CAB25F51D629BA5AC9986703DE25F9C93E8A454 (void);
// 0x0000004F System.IntPtr UnityEngine._AndroidJNIHelper::CreateJavaProxy(System.IntPtr,UnityEngine.AndroidJavaProxy)
extern void _AndroidJNIHelper_CreateJavaProxy_m6EB0D9FF190B75B8E49397619D1925F442EEBB8A (void);
// 0x00000050 System.IntPtr UnityEngine._AndroidJNIHelper::CreateJavaRunnable(UnityEngine.AndroidJavaRunnable)
extern void _AndroidJNIHelper_CreateJavaRunnable_m247E2AE8370951BEA9D154FC5AC04BE67F222CF1 (void);
// 0x00000051 System.IntPtr UnityEngine._AndroidJNIHelper::InvokeJavaProxyMethod(UnityEngine.AndroidJavaProxy,System.IntPtr,System.IntPtr)
extern void _AndroidJNIHelper_InvokeJavaProxyMethod_m1DB26565DC2BA3FD2AAA889D1EE72979E78EBD71 (void);
// 0x00000052 UnityEngine.jvalue[] UnityEngine._AndroidJNIHelper::CreateJNIArgArray(System.Object[])
extern void _AndroidJNIHelper_CreateJNIArgArray_m2075C9584C3A31C8DFFA5D1DDBEE8C5FFBB95892 (void);
// 0x00000053 System.Object UnityEngine._AndroidJNIHelper::UnboxArray(UnityEngine.AndroidJavaObject)
extern void _AndroidJNIHelper_UnboxArray_mD9697E8557EB29A0CFFC3A4423366F75B74C4F1D (void);
// 0x00000054 System.Object UnityEngine._AndroidJNIHelper::Unbox(UnityEngine.AndroidJavaObject)
extern void _AndroidJNIHelper_Unbox_mD43DC20EB0E844E2E3E9373EDDB825B5E61FC0BB (void);
// 0x00000055 UnityEngine.AndroidJavaObject UnityEngine._AndroidJNIHelper::Box(System.Object)
extern void _AndroidJNIHelper_Box_mB45F80703BDE58472E812A2122DC70CAFC4E5023 (void);
// 0x00000056 System.Void UnityEngine._AndroidJNIHelper::DeleteJNIArgArray(System.Object[],UnityEngine.jvalue[])
extern void _AndroidJNIHelper_DeleteJNIArgArray_mFA2A3664183847343FBB1F76ACD32DE1B1ED0681 (void);
// 0x00000057 System.IntPtr UnityEngine._AndroidJNIHelper::ConvertToJNIArray(System.Array)
extern void _AndroidJNIHelper_ConvertToJNIArray_mA0E7A187566E19273CEE6D3BAA053B2178FA6850 (void);
// 0x00000058 ArrayType UnityEngine._AndroidJNIHelper::ConvertFromJNIArray(System.IntPtr)
// 0x00000059 System.IntPtr UnityEngine._AndroidJNIHelper::GetConstructorID(System.IntPtr,System.Object[])
extern void _AndroidJNIHelper_GetConstructorID_m7506B43EEFEA5F37F1548F63497D31378460FC61 (void);
// 0x0000005A System.IntPtr UnityEngine._AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.Object[],System.Boolean)
extern void _AndroidJNIHelper_GetMethodID_mF34E230F83D1166968B9B80CF2F9F3CFC00CD0C4 (void);
// 0x0000005B System.IntPtr UnityEngine._AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.Object[],System.Boolean)
// 0x0000005C System.IntPtr UnityEngine._AndroidJNIHelper::GetFieldID(System.IntPtr,System.String,System.Boolean)
// 0x0000005D System.IntPtr UnityEngine._AndroidJNIHelper::GetConstructorID(System.IntPtr,System.String)
extern void _AndroidJNIHelper_GetConstructorID_m80A44C210DFE146BDF2EB8FDB2FF19A6BD0337CE (void);
// 0x0000005E System.IntPtr UnityEngine._AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.String,System.Boolean)
extern void _AndroidJNIHelper_GetMethodID_m289D8B1C26B13A8A132565AAFC42FD6C81E99072 (void);
// 0x0000005F System.IntPtr UnityEngine._AndroidJNIHelper::GetMethodIDFallback(System.IntPtr,System.String,System.String,System.Boolean)
extern void _AndroidJNIHelper_GetMethodIDFallback_m48DDC7CB61931DD61B3524E65449AFD4F8B9E9F3 (void);
// 0x00000060 System.IntPtr UnityEngine._AndroidJNIHelper::GetFieldID(System.IntPtr,System.String,System.String,System.Boolean)
extern void _AndroidJNIHelper_GetFieldID_mE63F3DAF58A223435525E46590D1AE4F624E9628 (void);
// 0x00000061 System.String UnityEngine._AndroidJNIHelper::GetSignature(System.Object)
extern void _AndroidJNIHelper_GetSignature_m1F94418EAEB87AF74E495191DC2AA5293136175B (void);
// 0x00000062 System.String UnityEngine._AndroidJNIHelper::GetSignature(System.Object[])
extern void _AndroidJNIHelper_GetSignature_m17AB4F708FC61A101E77C0154684E3E119720FEB (void);
// 0x00000063 System.String UnityEngine._AndroidJNIHelper::GetSignature(System.Object[])
// 0x00000064 System.Void UnityEngine._AndroidJNIHelper::.ctor()
extern void _AndroidJNIHelper__ctor_m0535562F59B589E117E57B8EA07ECE900848F509 (void);
// 0x00000065 System.Boolean UnityEngine.AndroidJNIHelper::get_debug()
extern void AndroidJNIHelper_get_debug_mEC07393E765F852EFF25F87915975ACB569823E9 (void);
// 0x00000066 System.Void UnityEngine.AndroidJNIHelper::set_debug(System.Boolean)
extern void AndroidJNIHelper_set_debug_mD423F7DFBAC26FE5600D5F3485CD9748B26F656D (void);
// 0x00000067 System.IntPtr UnityEngine.AndroidJNIHelper::GetConstructorID(System.IntPtr)
extern void AndroidJNIHelper_GetConstructorID_mE1D38830BF910D6D575EC04EAC94E9661670C13F (void);
// 0x00000068 System.IntPtr UnityEngine.AndroidJNIHelper::GetConstructorID(System.IntPtr,System.String)
extern void AndroidJNIHelper_GetConstructorID_m2A7EE301E50E6200B15858AD095B9E3DCA061B10 (void);
// 0x00000069 System.IntPtr UnityEngine.AndroidJNIHelper::GetMethodID(System.IntPtr,System.String)
extern void AndroidJNIHelper_GetMethodID_m6521C6F759BCADC3C7E1CCFCBAE8B3A5BB300796 (void);
// 0x0000006A System.IntPtr UnityEngine.AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNIHelper_GetMethodID_m8C726C02456CFB02AD38F596D8F67151776D8750 (void);
// 0x0000006B System.IntPtr UnityEngine.AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.String,System.Boolean)
extern void AndroidJNIHelper_GetMethodID_m5F33E127418D5DA40590E4AE3814D7ACF7810F6E (void);
// 0x0000006C System.IntPtr UnityEngine.AndroidJNIHelper::GetFieldID(System.IntPtr,System.String)
extern void AndroidJNIHelper_GetFieldID_m7B09827CF9F035A3C481B6A4654DA0AC9253CC95 (void);
// 0x0000006D System.IntPtr UnityEngine.AndroidJNIHelper::GetFieldID(System.IntPtr,System.String,System.String)
extern void AndroidJNIHelper_GetFieldID_m7ADF5933F6A48A98CAB6B54E22943061C8613B17 (void);
// 0x0000006E System.IntPtr UnityEngine.AndroidJNIHelper::GetFieldID(System.IntPtr,System.String,System.String,System.Boolean)
extern void AndroidJNIHelper_GetFieldID_mC795891C3B70C0E8F98D9E8AD2A85103761A0C75 (void);
// 0x0000006F System.IntPtr UnityEngine.AndroidJNIHelper::CreateJavaRunnable(UnityEngine.AndroidJavaRunnable)
extern void AndroidJNIHelper_CreateJavaRunnable_mAA9F7D043B9EDD0A0665E0CA217A7577962A456F (void);
// 0x00000070 System.IntPtr UnityEngine.AndroidJNIHelper::CreateJavaProxy(UnityEngine.AndroidJavaProxy)
extern void AndroidJNIHelper_CreateJavaProxy_m2694F6C774901F6F33044BC41DA29C7CA3F9C1F5 (void);
// 0x00000071 System.IntPtr UnityEngine.AndroidJNIHelper::ConvertToJNIArray(System.Array)
extern void AndroidJNIHelper_ConvertToJNIArray_m0561DD17E7D4E7F598504ADFBEF8EC85F3B3A8E7 (void);
// 0x00000072 UnityEngine.jvalue[] UnityEngine.AndroidJNIHelper::CreateJNIArgArray(System.Object[])
extern void AndroidJNIHelper_CreateJNIArgArray_mCA21BB6EB162E1E77E8F95812BD662EA078EDDBF (void);
// 0x00000073 System.Void UnityEngine.AndroidJNIHelper::DeleteJNIArgArray(System.Object[],UnityEngine.jvalue[])
extern void AndroidJNIHelper_DeleteJNIArgArray_m287B584251A89771CD7C767119A350BD6DDACCAB (void);
// 0x00000074 System.IntPtr UnityEngine.AndroidJNIHelper::GetConstructorID(System.IntPtr,System.Object[])
extern void AndroidJNIHelper_GetConstructorID_m06AB8A133FD78AE60E6B5871CBD24609B9444ED7 (void);
// 0x00000075 System.IntPtr UnityEngine.AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.Object[],System.Boolean)
extern void AndroidJNIHelper_GetMethodID_mC54EF67EA8929F905AA8ACC8A498F21B548E0964 (void);
// 0x00000076 System.String UnityEngine.AndroidJNIHelper::GetSignature(System.Object)
extern void AndroidJNIHelper_GetSignature_m1249745E0D54BE68ED874BDB11F97FE7E20B08B9 (void);
// 0x00000077 System.String UnityEngine.AndroidJNIHelper::GetSignature(System.Object[])
extern void AndroidJNIHelper_GetSignature_mA508F7FFFF3C58701661083E542C3EA41B36FE16 (void);
// 0x00000078 ArrayType UnityEngine.AndroidJNIHelper::ConvertFromJNIArray(System.IntPtr)
// 0x00000079 System.IntPtr UnityEngine.AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.Object[],System.Boolean)
// 0x0000007A System.IntPtr UnityEngine.AndroidJNIHelper::GetFieldID(System.IntPtr,System.String,System.Boolean)
// 0x0000007B System.String UnityEngine.AndroidJNIHelper::GetSignature(System.Object[])
// 0x0000007C System.Int32 UnityEngine.AndroidJNI::AttachCurrentThread()
extern void AndroidJNI_AttachCurrentThread_mD5647083E547A77F9377BDB78106D426878A00E7 (void);
// 0x0000007D System.Int32 UnityEngine.AndroidJNI::DetachCurrentThread()
extern void AndroidJNI_DetachCurrentThread_m8549BBC1875C2142A1C6BE5B57663E42B9C04A85 (void);
// 0x0000007E System.Int32 UnityEngine.AndroidJNI::GetVersion()
extern void AndroidJNI_GetVersion_m8778A340C12A1C9ADDC6E9D3470C5D2F842DDDFD (void);
// 0x0000007F System.IntPtr UnityEngine.AndroidJNI::FindClass(System.String)
extern void AndroidJNI_FindClass_mA0D17BF36250F96F40D8DCF193A7C65E6F6DED7F (void);
// 0x00000080 System.IntPtr UnityEngine.AndroidJNI::FromReflectedMethod(System.IntPtr)
extern void AndroidJNI_FromReflectedMethod_m4483E987AEC5B258356E5A89F4C3865573AADFE6 (void);
// 0x00000081 System.IntPtr UnityEngine.AndroidJNI::FromReflectedField(System.IntPtr)
extern void AndroidJNI_FromReflectedField_m28C7BEDA16685980423347534ECA29587CFEF86A (void);
// 0x00000082 System.IntPtr UnityEngine.AndroidJNI::ToReflectedMethod(System.IntPtr,System.IntPtr,System.Boolean)
extern void AndroidJNI_ToReflectedMethod_m09271FB4CE49C2C25AC57D8461B6770928C7C3A8 (void);
// 0x00000083 System.IntPtr UnityEngine.AndroidJNI::ToReflectedField(System.IntPtr,System.IntPtr,System.Boolean)
extern void AndroidJNI_ToReflectedField_m416106258D081C2DAE25E60CF8DE226AD77321C8 (void);
// 0x00000084 System.IntPtr UnityEngine.AndroidJNI::GetSuperclass(System.IntPtr)
extern void AndroidJNI_GetSuperclass_m62D8BD9B93EC9475A7CCEEE93B250AF3BEDCCF28 (void);
// 0x00000085 System.Boolean UnityEngine.AndroidJNI::IsAssignableFrom(System.IntPtr,System.IntPtr)
extern void AndroidJNI_IsAssignableFrom_m69B636F6024DBDE83BFCBE699672C8748D1DDFBB (void);
// 0x00000086 System.Int32 UnityEngine.AndroidJNI::Throw(System.IntPtr)
extern void AndroidJNI_Throw_m7DE4851503814B5B02B49548CA714123B9279CAD (void);
// 0x00000087 System.Int32 UnityEngine.AndroidJNI::ThrowNew(System.IntPtr,System.String)
extern void AndroidJNI_ThrowNew_m7A4F77C9C5760FCF134839419070A0BF6B1DD340 (void);
// 0x00000088 System.IntPtr UnityEngine.AndroidJNI::ExceptionOccurred()
extern void AndroidJNI_ExceptionOccurred_m6C27C01B14483F99373608BF1A56CA53BA46F926 (void);
// 0x00000089 System.Void UnityEngine.AndroidJNI::ExceptionDescribe()
extern void AndroidJNI_ExceptionDescribe_m9E582B7E3ED1CA3D23A35325F676CD88A1E05B5D (void);
// 0x0000008A System.Void UnityEngine.AndroidJNI::ExceptionClear()
extern void AndroidJNI_ExceptionClear_m90681289A6CEAF160DB188A3E2177F323D996F82 (void);
// 0x0000008B System.Void UnityEngine.AndroidJNI::FatalError(System.String)
extern void AndroidJNI_FatalError_m93E568BF56843D6C6BDE029BB290E7839D47EF4D (void);
// 0x0000008C System.Int32 UnityEngine.AndroidJNI::PushLocalFrame(System.Int32)
extern void AndroidJNI_PushLocalFrame_m4B2AE2B5D545086A6720E97FA8F427F245360FC8 (void);
// 0x0000008D System.IntPtr UnityEngine.AndroidJNI::PopLocalFrame(System.IntPtr)
extern void AndroidJNI_PopLocalFrame_m2128BB5AAAE2E2E12161EBD13866C69D50D5B78B (void);
// 0x0000008E System.IntPtr UnityEngine.AndroidJNI::NewGlobalRef(System.IntPtr)
extern void AndroidJNI_NewGlobalRef_m5F4875C8F71CF25DCC437D2EDB75320C487DB074 (void);
// 0x0000008F System.Void UnityEngine.AndroidJNI::DeleteGlobalRef(System.IntPtr)
extern void AndroidJNI_DeleteGlobalRef_m0420C00BACE4BD46DD58F8738DFD9EE8189F542A (void);
// 0x00000090 System.IntPtr UnityEngine.AndroidJNI::NewWeakGlobalRef(System.IntPtr)
extern void AndroidJNI_NewWeakGlobalRef_m74933FB5C1E361F566A96B25CF096C770860CD94 (void);
// 0x00000091 System.Void UnityEngine.AndroidJNI::DeleteWeakGlobalRef(System.IntPtr)
extern void AndroidJNI_DeleteWeakGlobalRef_m23C9808936212AC528658CB4989F15580BB0C734 (void);
// 0x00000092 System.IntPtr UnityEngine.AndroidJNI::NewLocalRef(System.IntPtr)
extern void AndroidJNI_NewLocalRef_mA95E1CDBA47E9CEC4D55BBA178F0ACF4219F6E29 (void);
// 0x00000093 System.Void UnityEngine.AndroidJNI::DeleteLocalRef(System.IntPtr)
extern void AndroidJNI_DeleteLocalRef_m2A8137D15FDE9F781B13F71348FD5FFA1F9841BD (void);
// 0x00000094 System.Boolean UnityEngine.AndroidJNI::IsSameObject(System.IntPtr,System.IntPtr)
extern void AndroidJNI_IsSameObject_m983046376CD2C6C1A1BA4F90CE1EE69570393598 (void);
// 0x00000095 System.Int32 UnityEngine.AndroidJNI::EnsureLocalCapacity(System.Int32)
extern void AndroidJNI_EnsureLocalCapacity_m861737EE2780929B6F4208C87A3C8F8CDC1C90E6 (void);
// 0x00000096 System.IntPtr UnityEngine.AndroidJNI::AllocObject(System.IntPtr)
extern void AndroidJNI_AllocObject_m74E773B115EF0FAAC5D4A518FFAFAA118E5EF33F (void);
// 0x00000097 System.IntPtr UnityEngine.AndroidJNI::NewObject(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_NewObject_mD058F016DBC3D58BF2A64EA84D6943052D01E8B1 (void);
// 0x00000098 System.IntPtr UnityEngine.AndroidJNI::GetObjectClass(System.IntPtr)
extern void AndroidJNI_GetObjectClass_mA8282FA341DF231C0ADD07DE0B0D0E5999EA0207 (void);
// 0x00000099 System.Boolean UnityEngine.AndroidJNI::IsInstanceOf(System.IntPtr,System.IntPtr)
extern void AndroidJNI_IsInstanceOf_m8A24F4CF1D7B2CD605A09834313BDB9B6DEC3246 (void);
// 0x0000009A System.IntPtr UnityEngine.AndroidJNI::GetMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNI_GetMethodID_mCB601A11C971557E2F89DD968224749BD71D2B3A (void);
// 0x0000009B System.IntPtr UnityEngine.AndroidJNI::GetFieldID(System.IntPtr,System.String,System.String)
extern void AndroidJNI_GetFieldID_m8CA4FD910FCC33D2D430E1A897043F9E7CD0DF19 (void);
// 0x0000009C System.IntPtr UnityEngine.AndroidJNI::GetStaticMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNI_GetStaticMethodID_m46303AF2AAD855E623DFC9C341E848735B626A77 (void);
// 0x0000009D System.IntPtr UnityEngine.AndroidJNI::GetStaticFieldID(System.IntPtr,System.String,System.String)
extern void AndroidJNI_GetStaticFieldID_m2B47B2D935455E73BDA9E9871FD5A6DF5EDD2717 (void);
// 0x0000009E System.IntPtr UnityEngine.AndroidJNI::NewString(System.String)
extern void AndroidJNI_NewString_mF3FC7534344BDF4B4BD2B2DB5442B06E2402B23F (void);
// 0x0000009F System.IntPtr UnityEngine.AndroidJNI::NewStringFromStr(System.String)
extern void AndroidJNI_NewStringFromStr_mEEF9F3FF518F3CEEE81780A61DDEB0B93D3ED548 (void);
// 0x000000A0 System.IntPtr UnityEngine.AndroidJNI::NewString(System.Char[])
extern void AndroidJNI_NewString_m3D31982AB8AC761DEEE7CCD7BAC11A78FA6EE6FB (void);
// 0x000000A1 System.IntPtr UnityEngine.AndroidJNI::NewStringUTF(System.String)
extern void AndroidJNI_NewStringUTF_mC6183C5B20FAAEA418F181A65DD24A7C76978701 (void);
// 0x000000A2 System.String UnityEngine.AndroidJNI::GetStringChars(System.IntPtr)
extern void AndroidJNI_GetStringChars_m462C62C322F38797F05A818CEF5C8D235F1F6714 (void);
// 0x000000A3 System.Int32 UnityEngine.AndroidJNI::GetStringLength(System.IntPtr)
extern void AndroidJNI_GetStringLength_m04D022FE0F5BD6CE06607E508BC4E1BB8AFE96C8 (void);
// 0x000000A4 System.Int32 UnityEngine.AndroidJNI::GetStringUTFLength(System.IntPtr)
extern void AndroidJNI_GetStringUTFLength_m51B5298ABF4A1A0958639F4571571BB537A4AC1F (void);
// 0x000000A5 System.String UnityEngine.AndroidJNI::GetStringUTFChars(System.IntPtr)
extern void AndroidJNI_GetStringUTFChars_m9C86681B1471BC74EDE87542229BA34894A8CD3A (void);
// 0x000000A6 System.String UnityEngine.AndroidJNI::CallStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStringMethod_m932940262AEC9A8121916054C90D79866D29C547 (void);
// 0x000000A7 System.IntPtr UnityEngine.AndroidJNI::CallObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallObjectMethod_m059D1BE669D486F2A26B40D6B90BF157B84A3CA3 (void);
// 0x000000A8 System.Int32 UnityEngine.AndroidJNI::CallIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallIntMethod_m5CE09EA0846BF49ABE3E23BC923710A0F1FF4787 (void);
// 0x000000A9 System.Boolean UnityEngine.AndroidJNI::CallBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallBooleanMethod_m6556ACCEDD78DE903521F341072907C4EC90FC96 (void);
// 0x000000AA System.Int16 UnityEngine.AndroidJNI::CallShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallShortMethod_m889B967EB2D48E331692B199D2EDABACEC8D5F01 (void);
// 0x000000AB System.Byte UnityEngine.AndroidJNI::CallByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallByteMethod_m15643014CE496B4D3E689ADEB6E5F88B44EABBF7 (void);
// 0x000000AC System.SByte UnityEngine.AndroidJNI::CallSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallSByteMethod_m45D5ABB4DDFBFEFC6DB132FC2D8463C501F1E4A5 (void);
// 0x000000AD System.Char UnityEngine.AndroidJNI::CallCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallCharMethod_mEF6E65AB2EE0BFAA136878966C42FB21529CB91D (void);
// 0x000000AE System.Single UnityEngine.AndroidJNI::CallFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallFloatMethod_m5BC422FC7D771A08DD18B443CBE3941ACD239FD9 (void);
// 0x000000AF System.Double UnityEngine.AndroidJNI::CallDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallDoubleMethod_m88A34942D1206EEE8BEA95475722D2E8FFFFC711 (void);
// 0x000000B0 System.Int64 UnityEngine.AndroidJNI::CallLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallLongMethod_m2AF630255CC50CB6A875E4FC1E13023699504C6E (void);
// 0x000000B1 System.Void UnityEngine.AndroidJNI::CallVoidMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallVoidMethod_m0B2ED17E5CA42D8D1D503CD329482A5923F1ED67 (void);
// 0x000000B2 System.String UnityEngine.AndroidJNI::GetStringField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStringField_m72B978571BE59E46CE385ABF43D27F4F3AD428DC (void);
// 0x000000B3 System.IntPtr UnityEngine.AndroidJNI::GetObjectField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetObjectField_mDC51440CDD5C41B8BE5AB1FC0DB1D4A75A0B00B6 (void);
// 0x000000B4 System.Boolean UnityEngine.AndroidJNI::GetBooleanField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetBooleanField_mD4A949E18A3AE1F8844105267EBD669EF4992736 (void);
// 0x000000B5 System.Byte UnityEngine.AndroidJNI::GetByteField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetByteField_mD5E50EE3D67C794822974082D8B413823DB51196 (void);
// 0x000000B6 System.SByte UnityEngine.AndroidJNI::GetSByteField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetSByteField_m74A3F36343350116F6A6F04E91117AAB5CBFFD0C (void);
// 0x000000B7 System.Char UnityEngine.AndroidJNI::GetCharField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetCharField_m2E6B5082E0CA1EF9F3F3A5F503BB61404DB4B64E (void);
// 0x000000B8 System.Int16 UnityEngine.AndroidJNI::GetShortField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetShortField_m1BCF7D56CEB4E2C85C1BE6C1F8BB6F194C437427 (void);
// 0x000000B9 System.Int32 UnityEngine.AndroidJNI::GetIntField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetIntField_m429B20FC0C03F9526125AF46A37FE36AEDB27A84 (void);
// 0x000000BA System.Int64 UnityEngine.AndroidJNI::GetLongField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetLongField_mE133B0457F7DA846EACEE402DA6FBA2F4ABE1904 (void);
// 0x000000BB System.Single UnityEngine.AndroidJNI::GetFloatField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetFloatField_mAFA7BF7AD9A5DCDFCA7847870CA28492776F87FC (void);
// 0x000000BC System.Double UnityEngine.AndroidJNI::GetDoubleField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetDoubleField_m3A52B3C44D03F55A287B38E5069240525EF73A28 (void);
// 0x000000BD System.Void UnityEngine.AndroidJNI::SetStringField(System.IntPtr,System.IntPtr,System.String)
extern void AndroidJNI_SetStringField_m137F3C45F7DCA41D0DBB6474C1F11ABDF92BD1E5 (void);
// 0x000000BE System.Void UnityEngine.AndroidJNI::SetObjectField(System.IntPtr,System.IntPtr,System.IntPtr)
extern void AndroidJNI_SetObjectField_m6C57BE78BFAD68BEB6F938F050E225C39952BCA7 (void);
// 0x000000BF System.Void UnityEngine.AndroidJNI::SetBooleanField(System.IntPtr,System.IntPtr,System.Boolean)
extern void AndroidJNI_SetBooleanField_m3E4D6E11693FFB0D7A37F06277EACAF6E5CC2441 (void);
// 0x000000C0 System.Void UnityEngine.AndroidJNI::SetByteField(System.IntPtr,System.IntPtr,System.Byte)
extern void AndroidJNI_SetByteField_m64709DD80DB6F4D9A15383D51CAFC5B0C71859A8 (void);
// 0x000000C1 System.Void UnityEngine.AndroidJNI::SetSByteField(System.IntPtr,System.IntPtr,System.SByte)
extern void AndroidJNI_SetSByteField_mAF33C0CEE6CFF0D5895D36499A7456DD4BA32022 (void);
// 0x000000C2 System.Void UnityEngine.AndroidJNI::SetCharField(System.IntPtr,System.IntPtr,System.Char)
extern void AndroidJNI_SetCharField_m9C07B22EF92F20790848DE682EE5D43F7EABF371 (void);
// 0x000000C3 System.Void UnityEngine.AndroidJNI::SetShortField(System.IntPtr,System.IntPtr,System.Int16)
extern void AndroidJNI_SetShortField_m7C1DCFA4AB07DD26F41820817B38AD1B255E1733 (void);
// 0x000000C4 System.Void UnityEngine.AndroidJNI::SetIntField(System.IntPtr,System.IntPtr,System.Int32)
extern void AndroidJNI_SetIntField_m81A869C1EDABE5E86A9C282908AE73CDF8B5D8AE (void);
// 0x000000C5 System.Void UnityEngine.AndroidJNI::SetLongField(System.IntPtr,System.IntPtr,System.Int64)
extern void AndroidJNI_SetLongField_mBB1D3A9EA6962BA3F587C5FCD1A2BBCADDE061B9 (void);
// 0x000000C6 System.Void UnityEngine.AndroidJNI::SetFloatField(System.IntPtr,System.IntPtr,System.Single)
extern void AndroidJNI_SetFloatField_m9AA38D8D235C9D789A6BD5E0F3E3FD4833984CAB (void);
// 0x000000C7 System.Void UnityEngine.AndroidJNI::SetDoubleField(System.IntPtr,System.IntPtr,System.Double)
extern void AndroidJNI_SetDoubleField_mE593C3C60A11AE3B157221EA9247DDBCD8FE5191 (void);
// 0x000000C8 System.String UnityEngine.AndroidJNI::CallStaticStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticStringMethod_m728910FCD2307FC8A06ACA204C6308896E1F9634 (void);
// 0x000000C9 System.IntPtr UnityEngine.AndroidJNI::CallStaticObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticObjectMethod_mD81C9407381F719A207F5AD038D38A1DDF181306 (void);
// 0x000000CA System.Int32 UnityEngine.AndroidJNI::CallStaticIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticIntMethod_mF3BBC45BEA5618BDE9E8C35CF86E4089CB366FAB (void);
// 0x000000CB System.Boolean UnityEngine.AndroidJNI::CallStaticBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticBooleanMethod_m19B53E56531AEDB6735F1D5651E622E4E823EE92 (void);
// 0x000000CC System.Int16 UnityEngine.AndroidJNI::CallStaticShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticShortMethod_m7510F3205665CF3134DD91BAB86458A916B4FA67 (void);
// 0x000000CD System.Byte UnityEngine.AndroidJNI::CallStaticByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticByteMethod_mA607D02EC420A4A811BF3B4DD3ACC29EF4F9E0D0 (void);
// 0x000000CE System.SByte UnityEngine.AndroidJNI::CallStaticSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticSByteMethod_m91B3565EC4E89DB5DD6994ED9DC03DC1506D9ABD (void);
// 0x000000CF System.Char UnityEngine.AndroidJNI::CallStaticCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticCharMethod_mC17CFB28DA453858E2D5189C4A93985A5074ECAC (void);
// 0x000000D0 System.Single UnityEngine.AndroidJNI::CallStaticFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticFloatMethod_m50DD95A67820F5A3E3C62556600D985DA697889B (void);
// 0x000000D1 System.Double UnityEngine.AndroidJNI::CallStaticDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticDoubleMethod_m9396E74A4DC7D047134A5DCFFBB343651C1C46FC (void);
// 0x000000D2 System.Int64 UnityEngine.AndroidJNI::CallStaticLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticLongMethod_m2E00D7592B163630AF5352E89F6180F6B56B8278 (void);
// 0x000000D3 System.Void UnityEngine.AndroidJNI::CallStaticVoidMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticVoidMethod_mE1E41BEF150679746147820E058E034CCE9F5FB3 (void);
// 0x000000D4 System.String UnityEngine.AndroidJNI::GetStaticStringField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticStringField_m6C8673931581ED0646BA2D059C45514ED9D8530F (void);
// 0x000000D5 System.IntPtr UnityEngine.AndroidJNI::GetStaticObjectField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticObjectField_m6E2116C7207C76FBFE2D26A376B10C00D9C49190 (void);
// 0x000000D6 System.Boolean UnityEngine.AndroidJNI::GetStaticBooleanField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticBooleanField_m91EE84C77BB16B3ADE727DDCC0F6AC7D262012CA (void);
// 0x000000D7 System.Byte UnityEngine.AndroidJNI::GetStaticByteField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticByteField_m5C141BD8E937CEB382D4FA050A4F7A638A76182E (void);
// 0x000000D8 System.SByte UnityEngine.AndroidJNI::GetStaticSByteField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticSByteField_m3F82DDF01CA24E139B8F35C5821C528FB8B04B96 (void);
// 0x000000D9 System.Char UnityEngine.AndroidJNI::GetStaticCharField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticCharField_m70532959E334E3745AEF21C7A77C10221E639F20 (void);
// 0x000000DA System.Int16 UnityEngine.AndroidJNI::GetStaticShortField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticShortField_mB4FC3F0637204FE8E2466F8E9C5F2AE9C4F53101 (void);
// 0x000000DB System.Int32 UnityEngine.AndroidJNI::GetStaticIntField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticIntField_m6AE681D1B1EF0DFE81714A3EB2CBEA6281DF136E (void);
// 0x000000DC System.Int64 UnityEngine.AndroidJNI::GetStaticLongField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticLongField_m2838DE5CE092E4DCD0BF8C69AE366444117AE22A (void);
// 0x000000DD System.Single UnityEngine.AndroidJNI::GetStaticFloatField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticFloatField_m33D3E4CC3A6219BD8529ACEF168644650093C326 (void);
// 0x000000DE System.Double UnityEngine.AndroidJNI::GetStaticDoubleField(System.IntPtr,System.IntPtr)
extern void AndroidJNI_GetStaticDoubleField_m538DA725808C50CF8CF77FA6539865F22761FA86 (void);
// 0x000000DF System.Void UnityEngine.AndroidJNI::SetStaticStringField(System.IntPtr,System.IntPtr,System.String)
extern void AndroidJNI_SetStaticStringField_mBE032CF9EBDF2E8D724512826F2CA5AFA075C21F (void);
// 0x000000E0 System.Void UnityEngine.AndroidJNI::SetStaticObjectField(System.IntPtr,System.IntPtr,System.IntPtr)
extern void AndroidJNI_SetStaticObjectField_mB5FFECBB4D5D963EF0454957F9F4661FFA833555 (void);
// 0x000000E1 System.Void UnityEngine.AndroidJNI::SetStaticBooleanField(System.IntPtr,System.IntPtr,System.Boolean)
extern void AndroidJNI_SetStaticBooleanField_m487E8387D32B024009C37D9B3A800381A475C659 (void);
// 0x000000E2 System.Void UnityEngine.AndroidJNI::SetStaticByteField(System.IntPtr,System.IntPtr,System.Byte)
extern void AndroidJNI_SetStaticByteField_m50FEB9D2D9D846AED6643B58E4AC7B2AE92986AC (void);
// 0x000000E3 System.Void UnityEngine.AndroidJNI::SetStaticSByteField(System.IntPtr,System.IntPtr,System.SByte)
extern void AndroidJNI_SetStaticSByteField_mBD550D0F0E9A54FD039C0DE4EE8C21990C5A39C3 (void);
// 0x000000E4 System.Void UnityEngine.AndroidJNI::SetStaticCharField(System.IntPtr,System.IntPtr,System.Char)
extern void AndroidJNI_SetStaticCharField_m06825B1CFD06746E47F0192FA4F2FC3D3125E9DA (void);
// 0x000000E5 System.Void UnityEngine.AndroidJNI::SetStaticShortField(System.IntPtr,System.IntPtr,System.Int16)
extern void AndroidJNI_SetStaticShortField_m4A4132E557627F1954AE30C36CDD3BB329949C9A (void);
// 0x000000E6 System.Void UnityEngine.AndroidJNI::SetStaticIntField(System.IntPtr,System.IntPtr,System.Int32)
extern void AndroidJNI_SetStaticIntField_mD0DDF159656B3F999FFD3BB812E97B3E39F08649 (void);
// 0x000000E7 System.Void UnityEngine.AndroidJNI::SetStaticLongField(System.IntPtr,System.IntPtr,System.Int64)
extern void AndroidJNI_SetStaticLongField_mCBC20FE3812F3C3CF5FA0C8CAE96A5A63061437E (void);
// 0x000000E8 System.Void UnityEngine.AndroidJNI::SetStaticFloatField(System.IntPtr,System.IntPtr,System.Single)
extern void AndroidJNI_SetStaticFloatField_mD6B054EE0170B31C26C9A85E49A6A01C60DFE908 (void);
// 0x000000E9 System.Void UnityEngine.AndroidJNI::SetStaticDoubleField(System.IntPtr,System.IntPtr,System.Double)
extern void AndroidJNI_SetStaticDoubleField_mE274169EFC6A08190E5D13984398A637500D069E (void);
// 0x000000EA System.IntPtr UnityEngine.AndroidJNI::ToBooleanArray(System.Boolean[])
extern void AndroidJNI_ToBooleanArray_m60F3CE17AE326BA244382C39F0FAE9F86DA1F206 (void);
// 0x000000EB System.IntPtr UnityEngine.AndroidJNI::ToByteArray(System.Byte[])
extern void AndroidJNI_ToByteArray_mA20FD81095A5C55B49F5362F586258D6E1361F14 (void);
// 0x000000EC System.IntPtr UnityEngine.AndroidJNI::ToSByteArray(System.SByte[])
extern void AndroidJNI_ToSByteArray_m5E75BAD1F59BF0993F573E548837DB5BEFD136D0 (void);
// 0x000000ED System.IntPtr UnityEngine.AndroidJNI::ToCharArray(System.Char[])
extern void AndroidJNI_ToCharArray_mA2081BFCF1F054F7AF1FF6C02DBCD3DDF842ACD1 (void);
// 0x000000EE System.IntPtr UnityEngine.AndroidJNI::ToShortArray(System.Int16[])
extern void AndroidJNI_ToShortArray_m5C720FF3C3E8A33E7F0679DEE1CF29279A3F6EE4 (void);
// 0x000000EF System.IntPtr UnityEngine.AndroidJNI::ToIntArray(System.Int32[])
extern void AndroidJNI_ToIntArray_m4F7B434E1B855ED0CCA21E5D3FE94BABCC246805 (void);
// 0x000000F0 System.IntPtr UnityEngine.AndroidJNI::ToLongArray(System.Int64[])
extern void AndroidJNI_ToLongArray_mBE89CB90348200EFD4A8939241A030FF7FB3B205 (void);
// 0x000000F1 System.IntPtr UnityEngine.AndroidJNI::ToFloatArray(System.Single[])
extern void AndroidJNI_ToFloatArray_m805231BFD408148D10ECB4B19935D49FD2E59E73 (void);
// 0x000000F2 System.IntPtr UnityEngine.AndroidJNI::ToDoubleArray(System.Double[])
extern void AndroidJNI_ToDoubleArray_m5365EB845635C82BAFC86696C6083F22A79F49EE (void);
// 0x000000F3 System.IntPtr UnityEngine.AndroidJNI::ToObjectArray(System.IntPtr[],System.IntPtr)
extern void AndroidJNI_ToObjectArray_mED4ECAFBCB6517A46658F92FCCF2492ADE08C3B5 (void);
// 0x000000F4 System.IntPtr UnityEngine.AndroidJNI::ToObjectArray(System.IntPtr[])
extern void AndroidJNI_ToObjectArray_m4C6CE46586423FD0BECCF68B8205DF5F6EE927BC (void);
// 0x000000F5 System.Boolean[] UnityEngine.AndroidJNI::FromBooleanArray(System.IntPtr)
extern void AndroidJNI_FromBooleanArray_m5EE3946B096CBAFCDED6E33AD0BEDF392CE3C2E3 (void);
// 0x000000F6 System.Byte[] UnityEngine.AndroidJNI::FromByteArray(System.IntPtr)
extern void AndroidJNI_FromByteArray_m2E5209DB888EB1CFD47E732AB5F565CEB351B766 (void);
// 0x000000F7 System.SByte[] UnityEngine.AndroidJNI::FromSByteArray(System.IntPtr)
extern void AndroidJNI_FromSByteArray_m46D4FF95707BEC89FB35BADAC0D778D1F9FFE600 (void);
// 0x000000F8 System.Char[] UnityEngine.AndroidJNI::FromCharArray(System.IntPtr)
extern void AndroidJNI_FromCharArray_mC965E533F95CD2ED4BE5DB99579D6C9723F9FFEF (void);
// 0x000000F9 System.Int16[] UnityEngine.AndroidJNI::FromShortArray(System.IntPtr)
extern void AndroidJNI_FromShortArray_m155B1A19DC1AA710079277D8392ECC84578C095C (void);
// 0x000000FA System.Int32[] UnityEngine.AndroidJNI::FromIntArray(System.IntPtr)
extern void AndroidJNI_FromIntArray_m0139900B65713B2EC09EB03596157D39968E81BC (void);
// 0x000000FB System.Int64[] UnityEngine.AndroidJNI::FromLongArray(System.IntPtr)
extern void AndroidJNI_FromLongArray_mCFB950966DB71AE966C3CE5B8B2FC63BD874B3EC (void);
// 0x000000FC System.Single[] UnityEngine.AndroidJNI::FromFloatArray(System.IntPtr)
extern void AndroidJNI_FromFloatArray_mDC9E8A87B643677DB1CD67FB90EE6AC30A2352C5 (void);
// 0x000000FD System.Double[] UnityEngine.AndroidJNI::FromDoubleArray(System.IntPtr)
extern void AndroidJNI_FromDoubleArray_m069C4F1F762610BA916F674B3125A68634F27AB8 (void);
// 0x000000FE System.IntPtr[] UnityEngine.AndroidJNI::FromObjectArray(System.IntPtr)
extern void AndroidJNI_FromObjectArray_mFED788163BF5C17E83D2DF65A9056DB08EF91761 (void);
// 0x000000FF System.Int32 UnityEngine.AndroidJNI::GetArrayLength(System.IntPtr)
extern void AndroidJNI_GetArrayLength_m67AF3E58A9CFD97E7934D2E63D0306865A78DA12 (void);
// 0x00000100 System.IntPtr UnityEngine.AndroidJNI::NewBooleanArray(System.Int32)
extern void AndroidJNI_NewBooleanArray_m3B0B21E3EDEEEB7C24DB553D3647A08B49B77236 (void);
// 0x00000101 System.IntPtr UnityEngine.AndroidJNI::NewByteArray(System.Int32)
extern void AndroidJNI_NewByteArray_m5F59BAD46869E8B2FEDF729F0D822FA15FE8B808 (void);
// 0x00000102 System.IntPtr UnityEngine.AndroidJNI::NewSByteArray(System.Int32)
extern void AndroidJNI_NewSByteArray_mCC033B02E3FB52227DD2F7CF359C7259535BF40B (void);
// 0x00000103 System.IntPtr UnityEngine.AndroidJNI::NewCharArray(System.Int32)
extern void AndroidJNI_NewCharArray_m113A3ABE8D00BEAD48C9ADEEC42837DFD295DB5E (void);
// 0x00000104 System.IntPtr UnityEngine.AndroidJNI::NewShortArray(System.Int32)
extern void AndroidJNI_NewShortArray_m931058DCCBDBAA9BEFFAF0D605B11E292AAE845C (void);
// 0x00000105 System.IntPtr UnityEngine.AndroidJNI::NewIntArray(System.Int32)
extern void AndroidJNI_NewIntArray_m53DAF097F1A42A462C00032044E67F5ED2D46B55 (void);
// 0x00000106 System.IntPtr UnityEngine.AndroidJNI::NewLongArray(System.Int32)
extern void AndroidJNI_NewLongArray_mF29BD86C4CE9A89BC9D0C8D6AFB2BDD91A34615A (void);
// 0x00000107 System.IntPtr UnityEngine.AndroidJNI::NewFloatArray(System.Int32)
extern void AndroidJNI_NewFloatArray_m7B884413B6C595CD5BFA4ED4ED7D2503605783AE (void);
// 0x00000108 System.IntPtr UnityEngine.AndroidJNI::NewDoubleArray(System.Int32)
extern void AndroidJNI_NewDoubleArray_m1C7B86959F420149C5D5045FA1F68CC976C76165 (void);
// 0x00000109 System.IntPtr UnityEngine.AndroidJNI::NewObjectArray(System.Int32,System.IntPtr,System.IntPtr)
extern void AndroidJNI_NewObjectArray_m8B0C45BD47F6563EA916E35BE26691DFA6482A51 (void);
// 0x0000010A System.Boolean UnityEngine.AndroidJNI::GetBooleanArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetBooleanArrayElement_m9AE3C91E6EE77BBB1664BE6A698EB40DBAF0A715 (void);
// 0x0000010B System.Byte UnityEngine.AndroidJNI::GetByteArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetByteArrayElement_m3C4347DB47CB2AD3D35D2F10EF5F3B9A169CC209 (void);
// 0x0000010C System.SByte UnityEngine.AndroidJNI::GetSByteArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetSByteArrayElement_m9F91FD32379FD2C8658F113876A9C66C83F1B278 (void);
// 0x0000010D System.Char UnityEngine.AndroidJNI::GetCharArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetCharArrayElement_m158503FC9DC4456294B5825061535B2C57295D28 (void);
// 0x0000010E System.Int16 UnityEngine.AndroidJNI::GetShortArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetShortArrayElement_m402A50E5EB01EDB9D3471FDEBDBB291A2029E0EB (void);
// 0x0000010F System.Int32 UnityEngine.AndroidJNI::GetIntArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetIntArrayElement_mEB2F9FE140A298C151C1CD6E4C40E3F7CEE7364C (void);
// 0x00000110 System.Int64 UnityEngine.AndroidJNI::GetLongArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetLongArrayElement_mE5C85EE2864C469EB89227E9D9305DB1798D7631 (void);
// 0x00000111 System.Single UnityEngine.AndroidJNI::GetFloatArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetFloatArrayElement_m1F81665927FDA4E8C700297AB4455BBF5F9526C7 (void);
// 0x00000112 System.Double UnityEngine.AndroidJNI::GetDoubleArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetDoubleArrayElement_m5D2B8F144CD011AAA8A94F30DD3816EDA61BD155 (void);
// 0x00000113 System.IntPtr UnityEngine.AndroidJNI::GetObjectArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetObjectArrayElement_mDD7F2DC202FA14B8E5889755FB02B401C1127AD0 (void);
// 0x00000114 System.Void UnityEngine.AndroidJNI::SetBooleanArrayElement(System.IntPtr,System.Int32,System.Byte)
extern void AndroidJNI_SetBooleanArrayElement_mB3AE5B3BDD6852FB6115600B1EB2081F68A23B71 (void);
// 0x00000115 System.Void UnityEngine.AndroidJNI::SetBooleanArrayElement(System.IntPtr,System.Int32,System.Boolean)
extern void AndroidJNI_SetBooleanArrayElement_m981C25BCDCDE216B4DD88094586C7A9F17625322 (void);
// 0x00000116 System.Void UnityEngine.AndroidJNI::SetByteArrayElement(System.IntPtr,System.Int32,System.SByte)
extern void AndroidJNI_SetByteArrayElement_mCABBF82507C866AF4DF359F8A7FEC23EB0D14AB4 (void);
// 0x00000117 System.Void UnityEngine.AndroidJNI::SetSByteArrayElement(System.IntPtr,System.Int32,System.SByte)
extern void AndroidJNI_SetSByteArrayElement_mBB31E6212B68AAD76DF7BB433E8EE8539F6E7C62 (void);
// 0x00000118 System.Void UnityEngine.AndroidJNI::SetCharArrayElement(System.IntPtr,System.Int32,System.Char)
extern void AndroidJNI_SetCharArrayElement_m7C15256F6AFE46D6886443B6E8FFAA84213A3F3E (void);
// 0x00000119 System.Void UnityEngine.AndroidJNI::SetShortArrayElement(System.IntPtr,System.Int32,System.Int16)
extern void AndroidJNI_SetShortArrayElement_mB2924B72AD7F32281E0CDBF58B38F65A21C2A7BC (void);
// 0x0000011A System.Void UnityEngine.AndroidJNI::SetIntArrayElement(System.IntPtr,System.Int32,System.Int32)
extern void AndroidJNI_SetIntArrayElement_m97426E41A5D318E16C0DB59DDBD530D156010127 (void);
// 0x0000011B System.Void UnityEngine.AndroidJNI::SetLongArrayElement(System.IntPtr,System.Int32,System.Int64)
extern void AndroidJNI_SetLongArrayElement_m794F6D1322125F22DCDD8B1BEA94CFB37BD3E6B0 (void);
// 0x0000011C System.Void UnityEngine.AndroidJNI::SetFloatArrayElement(System.IntPtr,System.Int32,System.Single)
extern void AndroidJNI_SetFloatArrayElement_m373C39039A2EAEB220312B95C4AED773D1836B57 (void);
// 0x0000011D System.Void UnityEngine.AndroidJNI::SetDoubleArrayElement(System.IntPtr,System.Int32,System.Double)
extern void AndroidJNI_SetDoubleArrayElement_m8F33446F84DD44198CA338D5C7D0FE79064DAAFC (void);
// 0x0000011E System.Void UnityEngine.AndroidJNI::SetObjectArrayElement(System.IntPtr,System.Int32,System.IntPtr)
extern void AndroidJNI_SetObjectArrayElement_m5D80CF792A1C492F97EC3378E36FFF458BAFD8D1 (void);
// 0x0000011F System.Void UnityEngine.AndroidJNISafe::CheckException()
extern void AndroidJNISafe_CheckException_mD1BB59188CDDCC2559F595CE1240E6BB12F1D546 (void);
// 0x00000120 System.Void UnityEngine.AndroidJNISafe::DeleteGlobalRef(System.IntPtr)
extern void AndroidJNISafe_DeleteGlobalRef_mC71D9B4DBED2AB66D49764253BA8DE912F731A40 (void);
// 0x00000121 System.Void UnityEngine.AndroidJNISafe::DeleteWeakGlobalRef(System.IntPtr)
extern void AndroidJNISafe_DeleteWeakGlobalRef_m9B39A30D764938DC4C8D526321520701D77D34A7 (void);
// 0x00000122 System.Void UnityEngine.AndroidJNISafe::DeleteLocalRef(System.IntPtr)
extern void AndroidJNISafe_DeleteLocalRef_m80503AA6C85CE46E8CE72C62215E1BE62964424D (void);
// 0x00000123 System.IntPtr UnityEngine.AndroidJNISafe::NewString(System.String)
extern void AndroidJNISafe_NewString_m6D6411F7DACFD383054457D88C0F0F1F8AE0CFB9 (void);
// 0x00000124 System.String UnityEngine.AndroidJNISafe::GetStringChars(System.IntPtr)
extern void AndroidJNISafe_GetStringChars_m21A07825755C0A9AF91F8248A1C98F861E26928F (void);
// 0x00000125 System.IntPtr UnityEngine.AndroidJNISafe::GetObjectClass(System.IntPtr)
extern void AndroidJNISafe_GetObjectClass_m78626C2B107D46FA9276B6FD32D746EEB81E8D2D (void);
// 0x00000126 System.IntPtr UnityEngine.AndroidJNISafe::GetStaticMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNISafe_GetStaticMethodID_mDD304107A2DCF7C4FFFC6E820361618693FCD8C7 (void);
// 0x00000127 System.IntPtr UnityEngine.AndroidJNISafe::GetMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNISafe_GetMethodID_m4E480BAEFB37F467848EC9074C6917A2D8E853DC (void);
// 0x00000128 System.IntPtr UnityEngine.AndroidJNISafe::GetFieldID(System.IntPtr,System.String,System.String)
extern void AndroidJNISafe_GetFieldID_m82034BB65220C7ACA5CA977789463EF827C4C0BF (void);
// 0x00000129 System.IntPtr UnityEngine.AndroidJNISafe::GetStaticFieldID(System.IntPtr,System.String,System.String)
extern void AndroidJNISafe_GetStaticFieldID_mC79AC0A4A44034B7A6D19ED2CE6AF24F7369B698 (void);
// 0x0000012A System.IntPtr UnityEngine.AndroidJNISafe::FromReflectedMethod(System.IntPtr)
extern void AndroidJNISafe_FromReflectedMethod_mA0F291FDD88E4B0BD2242D9846833C696CF64F86 (void);
// 0x0000012B System.IntPtr UnityEngine.AndroidJNISafe::FindClass(System.String)
extern void AndroidJNISafe_FindClass_m921B6BE5C8F1F1A4207761AD07A57C0D5F599DDE (void);
// 0x0000012C System.IntPtr UnityEngine.AndroidJNISafe::NewObject(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_NewObject_mCA783442B4DE3E0071D2C71DE69A655EF8538E2C (void);
// 0x0000012D System.Void UnityEngine.AndroidJNISafe::SetStaticObjectField(System.IntPtr,System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_SetStaticObjectField_mE4688623E6BD1DD91127F4958DC4712290380DBA (void);
// 0x0000012E System.Void UnityEngine.AndroidJNISafe::SetStaticStringField(System.IntPtr,System.IntPtr,System.String)
extern void AndroidJNISafe_SetStaticStringField_m509E182615D4C2F7B753B225A04A8BFBA126FFA0 (void);
// 0x0000012F System.Void UnityEngine.AndroidJNISafe::SetStaticCharField(System.IntPtr,System.IntPtr,System.Char)
extern void AndroidJNISafe_SetStaticCharField_m73E7E7D9BE1A738206FAC4F90C26D5B316D07214 (void);
// 0x00000130 System.Void UnityEngine.AndroidJNISafe::SetStaticDoubleField(System.IntPtr,System.IntPtr,System.Double)
extern void AndroidJNISafe_SetStaticDoubleField_m94C4E9C749D081B785F5D24532B544D59E4096A6 (void);
// 0x00000131 System.Void UnityEngine.AndroidJNISafe::SetStaticFloatField(System.IntPtr,System.IntPtr,System.Single)
extern void AndroidJNISafe_SetStaticFloatField_mBBCC8840D96B2965206D6448B6B2EDAE3CDC2339 (void);
// 0x00000132 System.Void UnityEngine.AndroidJNISafe::SetStaticLongField(System.IntPtr,System.IntPtr,System.Int64)
extern void AndroidJNISafe_SetStaticLongField_m217087BFC4296606744CEB69506C4C0B9F49521F (void);
// 0x00000133 System.Void UnityEngine.AndroidJNISafe::SetStaticShortField(System.IntPtr,System.IntPtr,System.Int16)
extern void AndroidJNISafe_SetStaticShortField_m4EC080E45ACC7D82F242F68EBC2C7ACDA3CB8D1C (void);
// 0x00000134 System.Void UnityEngine.AndroidJNISafe::SetStaticSByteField(System.IntPtr,System.IntPtr,System.SByte)
extern void AndroidJNISafe_SetStaticSByteField_m05DB36918BF549ED3783179BB25BD2BB434400F0 (void);
// 0x00000135 System.Void UnityEngine.AndroidJNISafe::SetStaticBooleanField(System.IntPtr,System.IntPtr,System.Boolean)
extern void AndroidJNISafe_SetStaticBooleanField_m4DCD279423F848CE0884BACEF2ABBECC5B21BB37 (void);
// 0x00000136 System.Void UnityEngine.AndroidJNISafe::SetStaticIntField(System.IntPtr,System.IntPtr,System.Int32)
extern void AndroidJNISafe_SetStaticIntField_mE36FEAE2FEB2D1B231F31D52EAEE2C956B496CB7 (void);
// 0x00000137 System.IntPtr UnityEngine.AndroidJNISafe::GetStaticObjectField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStaticObjectField_m7A3E277AE5003C9ADB2B184739736F86A0A03AD4 (void);
// 0x00000138 System.String UnityEngine.AndroidJNISafe::GetStaticStringField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStaticStringField_mD0DC3837F26C82A38BFC42C8450823D53B0326EF (void);
// 0x00000139 System.Char UnityEngine.AndroidJNISafe::GetStaticCharField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStaticCharField_m4FDBF70F20C8A63D61CBE1DB322231C8D7CE2FF6 (void);
// 0x0000013A System.Double UnityEngine.AndroidJNISafe::GetStaticDoubleField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStaticDoubleField_mB0B0EC3DB652C45C177D663F71D63352CF31989E (void);
// 0x0000013B System.Single UnityEngine.AndroidJNISafe::GetStaticFloatField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStaticFloatField_mC947331D47B4102982F809E8A27FF05114E5321A (void);
// 0x0000013C System.Int64 UnityEngine.AndroidJNISafe::GetStaticLongField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStaticLongField_mF93D2C6310F4BAE072E311010A87C76F1E729379 (void);
// 0x0000013D System.Int16 UnityEngine.AndroidJNISafe::GetStaticShortField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStaticShortField_m84E78B16341CC92D47C97D5EBBEE157C24B3845A (void);
// 0x0000013E System.SByte UnityEngine.AndroidJNISafe::GetStaticSByteField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStaticSByteField_m0C17CA332A1C79E8AFB20119E9FC54301D40A847 (void);
// 0x0000013F System.Boolean UnityEngine.AndroidJNISafe::GetStaticBooleanField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStaticBooleanField_m5EE57D854FD22446DB1BD1A24019958B8FC9B4F2 (void);
// 0x00000140 System.Int32 UnityEngine.AndroidJNISafe::GetStaticIntField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStaticIntField_m8C4987D43981A1740AEFDA7B4B9A6A2C512E5AC4 (void);
// 0x00000141 System.Void UnityEngine.AndroidJNISafe::CallStaticVoidMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticVoidMethod_m965D8C47FDF1388EA6192108063B129C870B382F (void);
// 0x00000142 System.IntPtr UnityEngine.AndroidJNISafe::CallStaticObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticObjectMethod_mFF379E5F210AF38781F1FB59667AC39C4CFA5966 (void);
// 0x00000143 System.String UnityEngine.AndroidJNISafe::CallStaticStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticStringMethod_mC5449583711986CFF9CCDAD3F8058D9842229B88 (void);
// 0x00000144 System.Char UnityEngine.AndroidJNISafe::CallStaticCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticCharMethod_m435C3A57BC14CCA2F459E1CE9D3E9F084353634C (void);
// 0x00000145 System.Double UnityEngine.AndroidJNISafe::CallStaticDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticDoubleMethod_mDCA07255A15D31B20FFD77A795A7FD47C8661D1D (void);
// 0x00000146 System.Single UnityEngine.AndroidJNISafe::CallStaticFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticFloatMethod_mCEF7855DF0530B27B6E0B4B1C1E78667FD80B2B6 (void);
// 0x00000147 System.Int64 UnityEngine.AndroidJNISafe::CallStaticLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticLongMethod_mA98EE656033866FC4DE05F3F815F76594FA18D84 (void);
// 0x00000148 System.Int16 UnityEngine.AndroidJNISafe::CallStaticShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticShortMethod_m134B1C6791FD9A09180ADF481475880F4F8B79A4 (void);
// 0x00000149 System.SByte UnityEngine.AndroidJNISafe::CallStaticSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticSByteMethod_mC9057F28DC0C675701810414D19C7168A68F026D (void);
// 0x0000014A System.Boolean UnityEngine.AndroidJNISafe::CallStaticBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticBooleanMethod_mF980739844CAA33E0E0ADA82F5177F91E39CCB75 (void);
// 0x0000014B System.Int32 UnityEngine.AndroidJNISafe::CallStaticIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticIntMethod_mE174E036EAB1034BA4DC107F534F0F7B6DA8FBC6 (void);
// 0x0000014C System.Void UnityEngine.AndroidJNISafe::SetObjectField(System.IntPtr,System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_SetObjectField_mB37CDFD1291DC6BC7D73668AED11A3B59E1C2B10 (void);
// 0x0000014D System.Void UnityEngine.AndroidJNISafe::SetStringField(System.IntPtr,System.IntPtr,System.String)
extern void AndroidJNISafe_SetStringField_m7AC7481678855A9DFFFBAED8D5C095AA6D3D8C79 (void);
// 0x0000014E System.Void UnityEngine.AndroidJNISafe::SetCharField(System.IntPtr,System.IntPtr,System.Char)
extern void AndroidJNISafe_SetCharField_m1BC58426F7753388A053FEA0137561854AB919F8 (void);
// 0x0000014F System.Void UnityEngine.AndroidJNISafe::SetDoubleField(System.IntPtr,System.IntPtr,System.Double)
extern void AndroidJNISafe_SetDoubleField_m0F9363465DDCE31EAD4F86867549A85AA5C3A09B (void);
// 0x00000150 System.Void UnityEngine.AndroidJNISafe::SetFloatField(System.IntPtr,System.IntPtr,System.Single)
extern void AndroidJNISafe_SetFloatField_m84552EDFC955EB994071C5E2B03A955B169D2842 (void);
// 0x00000151 System.Void UnityEngine.AndroidJNISafe::SetLongField(System.IntPtr,System.IntPtr,System.Int64)
extern void AndroidJNISafe_SetLongField_m6F65BE8E3095D1344FD77A9E7D039A7E3D94A925 (void);
// 0x00000152 System.Void UnityEngine.AndroidJNISafe::SetShortField(System.IntPtr,System.IntPtr,System.Int16)
extern void AndroidJNISafe_SetShortField_m8626A5FBFCE546B5C17834F06326A2B7938E70B5 (void);
// 0x00000153 System.Void UnityEngine.AndroidJNISafe::SetSByteField(System.IntPtr,System.IntPtr,System.SByte)
extern void AndroidJNISafe_SetSByteField_m52A563214F0AB2027CB4124311F147F789AE52CB (void);
// 0x00000154 System.Void UnityEngine.AndroidJNISafe::SetBooleanField(System.IntPtr,System.IntPtr,System.Boolean)
extern void AndroidJNISafe_SetBooleanField_mE88CEE9AAF0B56AD5A1A1741C7612EEA6E0521F1 (void);
// 0x00000155 System.Void UnityEngine.AndroidJNISafe::SetIntField(System.IntPtr,System.IntPtr,System.Int32)
extern void AndroidJNISafe_SetIntField_mA25D81AEE8AB2AA562EA8B03BF7F81D9202C368C (void);
// 0x00000156 System.IntPtr UnityEngine.AndroidJNISafe::GetObjectField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetObjectField_mD645E1D470CF975C1285EFF0A28C66FC37EFA520 (void);
// 0x00000157 System.String UnityEngine.AndroidJNISafe::GetStringField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetStringField_m65B73D43D6FA6A76E18AA78FB566A123FC832381 (void);
// 0x00000158 System.Char UnityEngine.AndroidJNISafe::GetCharField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetCharField_mE1C213483F3E07366C8FAE114648538E446202B9 (void);
// 0x00000159 System.Double UnityEngine.AndroidJNISafe::GetDoubleField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetDoubleField_m5E7778FD959CAA9256AB3E6ADCAC024B5A8D1CC3 (void);
// 0x0000015A System.Single UnityEngine.AndroidJNISafe::GetFloatField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetFloatField_m86A2AE1F0D2D81BA1587FDF2EA10693786BA0BBB (void);
// 0x0000015B System.Int64 UnityEngine.AndroidJNISafe::GetLongField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetLongField_m31E20FF52A23F3928BC3576173FCF435076A45A0 (void);
// 0x0000015C System.Int16 UnityEngine.AndroidJNISafe::GetShortField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetShortField_m835A602FF3722BA91111A36120C09DC16F58BF69 (void);
// 0x0000015D System.SByte UnityEngine.AndroidJNISafe::GetSByteField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetSByteField_mBFC442E1921CD7542D2705337A7E1A8D806EC42C (void);
// 0x0000015E System.Boolean UnityEngine.AndroidJNISafe::GetBooleanField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetBooleanField_mB1CE25A87F17492A866F2FB302D69532A50ED114 (void);
// 0x0000015F System.Int32 UnityEngine.AndroidJNISafe::GetIntField(System.IntPtr,System.IntPtr)
extern void AndroidJNISafe_GetIntField_m61F97AAEAE3410AB91489B59E2B9F1714D686724 (void);
// 0x00000160 System.Void UnityEngine.AndroidJNISafe::CallVoidMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallVoidMethod_m37B8331F4A139234C98323FE19FAC5F3E29EE743 (void);
// 0x00000161 System.IntPtr UnityEngine.AndroidJNISafe::CallObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallObjectMethod_m220EBB62A14A40DD5693A48E5787DE4636D051EA (void);
// 0x00000162 System.String UnityEngine.AndroidJNISafe::CallStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStringMethod_mABFAE9A418A989676CB15D01E5971E431BFD4579 (void);
// 0x00000163 System.Char UnityEngine.AndroidJNISafe::CallCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallCharMethod_m4A39264614C8E7A9E2645F7C0E208062990A9D90 (void);
// 0x00000164 System.Double UnityEngine.AndroidJNISafe::CallDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallDoubleMethod_m53CDFD6982DECEB5F155858B4D0B8D7A06B426DD (void);
// 0x00000165 System.Single UnityEngine.AndroidJNISafe::CallFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallFloatMethod_m95871A924AA515B19EEFD76FC5DABE3E2FAE4909 (void);
// 0x00000166 System.Int64 UnityEngine.AndroidJNISafe::CallLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallLongMethod_m6F9F122D99AB7C95774CE395A98153B705D07931 (void);
// 0x00000167 System.Int16 UnityEngine.AndroidJNISafe::CallShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallShortMethod_mDA06E47602A9F365C91DB7D3B78A699D8A48F861 (void);
// 0x00000168 System.SByte UnityEngine.AndroidJNISafe::CallSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallSByteMethod_mA5011FBB030ABC0A47C34052A49A7BEBC1F9EDC0 (void);
// 0x00000169 System.Boolean UnityEngine.AndroidJNISafe::CallBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallBooleanMethod_m9B26AA2F5828D29D1F1BC3315BABE97F3614EE08 (void);
// 0x0000016A System.Int32 UnityEngine.AndroidJNISafe::CallIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallIntMethod_m1C01B0148542E93B661401AB695295F4DFB334A8 (void);
// 0x0000016B System.Char[] UnityEngine.AndroidJNISafe::FromCharArray(System.IntPtr)
extern void AndroidJNISafe_FromCharArray_mC1C728B67330FD610542B4C2D6B9759F78B2BD17 (void);
// 0x0000016C System.Double[] UnityEngine.AndroidJNISafe::FromDoubleArray(System.IntPtr)
extern void AndroidJNISafe_FromDoubleArray_mB752FB522CD25191E5C6AF8CEFA4553593F784A7 (void);
// 0x0000016D System.Single[] UnityEngine.AndroidJNISafe::FromFloatArray(System.IntPtr)
extern void AndroidJNISafe_FromFloatArray_m97B7BC8546EC3F9CF0784D434D4AA41FBB409892 (void);
// 0x0000016E System.Int64[] UnityEngine.AndroidJNISafe::FromLongArray(System.IntPtr)
extern void AndroidJNISafe_FromLongArray_m687FC548BFA4DC440379619E5C7CB56354E30D59 (void);
// 0x0000016F System.Int16[] UnityEngine.AndroidJNISafe::FromShortArray(System.IntPtr)
extern void AndroidJNISafe_FromShortArray_m227116D8E01EE3568936FB93C97CAEE9062A0A35 (void);
// 0x00000170 System.Byte[] UnityEngine.AndroidJNISafe::FromByteArray(System.IntPtr)
extern void AndroidJNISafe_FromByteArray_mAED5B8EEF34E268BB146A277842089C7FD8A06BB (void);
// 0x00000171 System.SByte[] UnityEngine.AndroidJNISafe::FromSByteArray(System.IntPtr)
extern void AndroidJNISafe_FromSByteArray_m5825C71BA6941CDF25627AD77CDBE648CB322476 (void);
// 0x00000172 System.Boolean[] UnityEngine.AndroidJNISafe::FromBooleanArray(System.IntPtr)
extern void AndroidJNISafe_FromBooleanArray_m3F57F10FDDBA3DC358BEF7296F58D819C9EC3BDE (void);
// 0x00000173 System.Int32[] UnityEngine.AndroidJNISafe::FromIntArray(System.IntPtr)
extern void AndroidJNISafe_FromIntArray_m899EDC375E4983DCF33B5B72E2131DC06AA4B5F0 (void);
// 0x00000174 System.IntPtr UnityEngine.AndroidJNISafe::ToObjectArray(System.IntPtr[],System.IntPtr)
extern void AndroidJNISafe_ToObjectArray_m0F776C4B1BA875104CCB8345797A9269A3EBCF07 (void);
// 0x00000175 System.IntPtr UnityEngine.AndroidJNISafe::ToCharArray(System.Char[])
extern void AndroidJNISafe_ToCharArray_m8C8F076F9A471146F6BCF063F7415E89BC0FC801 (void);
// 0x00000176 System.IntPtr UnityEngine.AndroidJNISafe::ToDoubleArray(System.Double[])
extern void AndroidJNISafe_ToDoubleArray_mCAF30FC9FA2947EBC680D89374A5296D775132A9 (void);
// 0x00000177 System.IntPtr UnityEngine.AndroidJNISafe::ToFloatArray(System.Single[])
extern void AndroidJNISafe_ToFloatArray_m15157B7C76CE04863F365E7052671AC87D8556E0 (void);
// 0x00000178 System.IntPtr UnityEngine.AndroidJNISafe::ToLongArray(System.Int64[])
extern void AndroidJNISafe_ToLongArray_m00D8D5A5D1B46639307AA78C5E4E7421EA0FF16A (void);
// 0x00000179 System.IntPtr UnityEngine.AndroidJNISafe::ToShortArray(System.Int16[])
extern void AndroidJNISafe_ToShortArray_m3591547B05CEABD583A023C267091A536E3F925C (void);
// 0x0000017A System.IntPtr UnityEngine.AndroidJNISafe::ToByteArray(System.Byte[])
extern void AndroidJNISafe_ToByteArray_m13141E44A84BDC2716432D09131984A4ADFC101F (void);
// 0x0000017B System.IntPtr UnityEngine.AndroidJNISafe::ToSByteArray(System.SByte[])
extern void AndroidJNISafe_ToSByteArray_mEFB80D7817A15C285872B8F3C1A9A1EDEA9ECC34 (void);
// 0x0000017C System.IntPtr UnityEngine.AndroidJNISafe::ToBooleanArray(System.Boolean[])
extern void AndroidJNISafe_ToBooleanArray_m2E622CCA3AB1B19FE519F975391636CA7DECDAF7 (void);
// 0x0000017D System.IntPtr UnityEngine.AndroidJNISafe::ToIntArray(System.Int32[])
extern void AndroidJNISafe_ToIntArray_mA46A79AFCB3909BB90FFF2D20EFDA042E6A4DE97 (void);
// 0x0000017E System.IntPtr UnityEngine.AndroidJNISafe::GetObjectArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNISafe_GetObjectArrayElement_m515AF7717FD44C40A5FFFD6E50DFCD65A35B8FF5 (void);
// 0x0000017F System.Int32 UnityEngine.AndroidJNISafe::GetArrayLength(System.IntPtr)
extern void AndroidJNISafe_GetArrayLength_mB5F7260E652BE95FE9237A47C1E1597306B462C3 (void);
// 0x00000180 System.Void UnityEngine.Android.AndroidAssetPackInfo::.ctor(System.String,UnityEngine.Android.AndroidAssetPackStatus,System.UInt64,System.UInt64,System.Single,UnityEngine.Android.AndroidAssetPackError)
extern void AndroidAssetPackInfo__ctor_m747C0EAD6448BA479BAE3C5EAB67F205E0307972 (void);
// 0x00000181 System.Void UnityEngine.Android.AndroidAssetPackState::.ctor(System.String,UnityEngine.Android.AndroidAssetPackStatus,UnityEngine.Android.AndroidAssetPackError)
extern void AndroidAssetPackState__ctor_m5CB1F078A45558A0966BA32FCFE18CFC46CA941B (void);
// 0x00000182 System.Void UnityEngine.Android.AndroidAssetPackUseMobileDataRequestResult::.ctor(System.Boolean)
extern void AndroidAssetPackUseMobileDataRequestResult__ctor_mB46211F6D3B3A421B1C1D9E05F3FC62858383E8F (void);
// 0x00000183 UnityEngine.AndroidJavaObject UnityEngine.Android.AndroidAssetPacks::GetAssetPackManager()
extern void AndroidAssetPacks_GetAssetPackManager_m4E016B09EB3D38DEE6E5A207439D48823A8017CD (void);
// 0x00000184 System.Void UnityEngine.Android.AndroidAssetPacks/AssetPackManagerDownloadStatusCallback::.ctor(System.Action`1<UnityEngine.Android.AndroidAssetPackInfo>,System.String[])
extern void AssetPackManagerDownloadStatusCallback__ctor_m03D0B212EFAEACF611D60596E978DD0468C6D936 (void);
// 0x00000185 System.Void UnityEngine.Android.AndroidAssetPacks/AssetPackManagerDownloadStatusCallback::onStatusUpdate(System.String,System.Int32,System.Int64,System.Int64,System.Int32,System.Int32)
extern void AssetPackManagerDownloadStatusCallback_onStatusUpdate_m4042BE15C2B4A64CE1BAF4734E6A0BF8DD4FFC7A (void);
// 0x00000186 System.Void UnityEngine.Android.AndroidAssetPacks/AssetPackManagerMobileDataConfirmationCallback::.ctor(System.Action`1<UnityEngine.Android.AndroidAssetPackUseMobileDataRequestResult>)
extern void AssetPackManagerMobileDataConfirmationCallback__ctor_m927FCB784F7D90524C6725B9E64EF8799538999B (void);
// 0x00000187 System.Void UnityEngine.Android.AndroidAssetPacks/AssetPackManagerMobileDataConfirmationCallback::onMobileDataConfirmationResult(System.Boolean)
extern void AssetPackManagerMobileDataConfirmationCallback_onMobileDataConfirmationResult_m61FEFDED8787D798CF30CB78DC133505B7D3614A (void);
// 0x00000188 System.Void UnityEngine.Android.AndroidAssetPacks/AssetPackManagerStatusQueryCallback::.ctor(System.Action`2<System.UInt64,UnityEngine.Android.AndroidAssetPackState[]>,System.String[])
extern void AssetPackManagerStatusQueryCallback__ctor_m66F3B4A8BD8911F07121E2F8EF871741CE3A2CDB (void);
// 0x00000189 System.Void UnityEngine.Android.AndroidAssetPacks/AssetPackManagerStatusQueryCallback::onStatusResult(System.Int64,System.String[],System.Int32[],System.Int32[])
extern void AssetPackManagerStatusQueryCallback_onStatusResult_m8C41C5CC2F37808E5C5C12B023DF31E1DF96C314 (void);
// 0x0000018A System.Void UnityEngine.Android.PermissionCallbacks::add_PermissionGranted(System.Action`1<System.String>)
extern void PermissionCallbacks_add_PermissionGranted_m74335D4200D9B1A7C80AB9C133F95C61FCDCDF89 (void);
// 0x0000018B System.Void UnityEngine.Android.PermissionCallbacks::remove_PermissionGranted(System.Action`1<System.String>)
extern void PermissionCallbacks_remove_PermissionGranted_m4A3F9873FC159F89A2AD35F2FCAFF66A19813AF4 (void);
// 0x0000018C System.Void UnityEngine.Android.PermissionCallbacks::add_PermissionDenied(System.Action`1<System.String>)
extern void PermissionCallbacks_add_PermissionDenied_mE0B2826463785B050C999C70F443FCC3822563D0 (void);
// 0x0000018D System.Void UnityEngine.Android.PermissionCallbacks::remove_PermissionDenied(System.Action`1<System.String>)
extern void PermissionCallbacks_remove_PermissionDenied_mF1A606ADE21F9520909126D3642B0BC2D6E994A1 (void);
// 0x0000018E System.Void UnityEngine.Android.PermissionCallbacks::add_PermissionDeniedAndDontAskAgain(System.Action`1<System.String>)
extern void PermissionCallbacks_add_PermissionDeniedAndDontAskAgain_mEDE8C00FEF2F649F10A47F30AC4ECB09E52DB9AA (void);
// 0x0000018F System.Void UnityEngine.Android.PermissionCallbacks::remove_PermissionDeniedAndDontAskAgain(System.Action`1<System.String>)
extern void PermissionCallbacks_remove_PermissionDeniedAndDontAskAgain_m55B04AE58C687946BDFA2094ED851518B2A1D68D (void);
// 0x00000190 System.Void UnityEngine.Android.PermissionCallbacks::.ctor()
extern void PermissionCallbacks__ctor_m91B14BBBC8913C131E400BA0D13576822AAE7A75 (void);
// 0x00000191 System.Void UnityEngine.Android.PermissionCallbacks::onPermissionGranted(System.String)
extern void PermissionCallbacks_onPermissionGranted_m723440705B5B21B97AF5206716275BAE2A122E3C (void);
// 0x00000192 System.Void UnityEngine.Android.PermissionCallbacks::onPermissionDenied(System.String)
extern void PermissionCallbacks_onPermissionDenied_m0E05122B560DD62BB38178EE601E65854017980A (void);
// 0x00000193 System.Void UnityEngine.Android.PermissionCallbacks::onPermissionDeniedAndDontAskAgain(System.String)
extern void PermissionCallbacks_onPermissionDeniedAndDontAskAgain_m1191CF6422AFD8E8FE7BDBDBC04721D63718A5D9 (void);
static Il2CppMethodPointer s_methodPointers[403] = 
{
	AndroidJavaRunnable__ctor_m000E4FEB2DE8031A1CD733610D76E2BF60490334,
	AndroidJavaRunnable_Invoke_m98CFB1479B942F71BF29F53CFDAC1CB9DAFAEBE1,
	AndroidJavaException__ctor_mD4B5992BB074504F8E86D79EA98752D3CB154541,
	AndroidJavaException_get_StackTrace_m28AC922BCC16051CCBA4C7E5F69698264AA7CC27,
	GlobalJavaObjectRef__ctor_mFE5679D1B51F51CBF11721773C0D767286AC22E8,
	GlobalJavaObjectRef_Finalize_m2EE89F98A391773F885A4A312FD4BD134E0D46D8,
	GlobalJavaObjectRef_op_Implicit_m16AE2CD44F8CDE4667F4DA84D2567582544D4F4E,
	GlobalJavaObjectRef_Dispose_m45E67345587866D5A50D250D1C17425110703520,
	AndroidJavaRunnableProxy__ctor_mB173256AF7629962B226343C4F6F94FFFF7317C3,
	AndroidJavaRunnableProxy_run_m014F4E0A8ED56A054096F2BAC90653716D2A0D46,
	AndroidJavaProxy__ctor_m2832886A0E1BBF6702653A7C6A4609F11FB712C7,
	AndroidJavaProxy__ctor_mFA05DF6B31FC284C65D378C02A2A34F277DFE6E5,
	AndroidJavaProxy_Finalize_m6E4C294F2117D7A07E82A315081C9239AFA217E8,
	AndroidJavaProxy_Invoke_m9D765F3E7DC37C5CB14C4884F2873B48D2F96BFB,
	AndroidJavaProxy_Invoke_mCAE9C5E669AD50DE372494E12224FF1F31A43F1D,
	AndroidJavaProxy_equals_mC390139E035408E858940EB523D45ED3C8377110,
	AndroidJavaProxy_hashCode_m7991233D3D6D5F994E7BC59C3CB65DBBEDF8CA93,
	AndroidJavaProxy_toString_mF77EEDD3BB413F1273D9970BFB0D7C388366B256,
	AndroidJavaProxy_GetProxyObject_mBFD2FBEF9ED9D4AE23DECF5836E5C73A886E2109,
	AndroidJavaProxy_GetRawProxy_m685E066A4D378B596CD88385B954AE90CBF328A9,
	AndroidJavaProxy__cctor_mB40E77A0644729A8A761CC80A02E99020DD9790A,
	AndroidJavaObject__ctor_mB47CA3FC88F645DAB31FB0FAAA32E9159B1DB19E,
	AndroidJavaObject__ctor_m1F1F88504475490860A246714F36205FB7D53362,
	AndroidJavaObject__ctor_m262439771D3A3EFBD18E5D06188D11989D562635,
	AndroidJavaObject__ctor_m0F50ADD04B4BEA5ACB6B614BB206EBFA9353CF6B,
	AndroidJavaObject__ctor_mA61E481C9C0F990FF9BEBFE9E1299612BC174E0E,
	AndroidJavaObject__ctor_m5A65B5D325C2CEFAC4097A0D3813F8E158178DD7,
	AndroidJavaObject_Dispose_m2B1593C20B3CE1C8FF95982F638F50985F9DD9E6,
	NULL,
	AndroidJavaObject_Call_mDEF7846E2AB1C5379069BB21049ED55A9D837B1C,
	NULL,
	AndroidJavaObject_CallStatic_mB677DE04369EDD8E6DECAF2F233116EE1F06555C,
	NULL,
	NULL,
	NULL,
	NULL,
	AndroidJavaObject_GetRawObject_m536F043B5CE2C21369FF6173C9D2A9A62136BC48,
	AndroidJavaObject_GetRawClass_mE4FB4DC4F856A52E10C6AAD0B65BEBF47B5071F5,
	AndroidJavaObject_CloneReference_m6DF6E2BF8D91804B303C93C2026E4A39977E8428,
	NULL,
	NULL,
	NULL,
	NULL,
	AndroidJavaObject_DebugPrint_m047934BF3D1E6676FDDBDA038E1AF387C5413533,
	AndroidJavaObject_DebugPrint_m41CA713464E773016D31C1B6C1489AC34A542CE6,
	AndroidJavaObject__AndroidJavaObject_m1284CB7198514B8C06A2BF794ACDC909DC26443F,
	AndroidJavaObject__ctor_m0CEE7D570807333CE2C193A82AB3AB8D4F873A6B,
	AndroidJavaObject__ctor_m67B4EEAB015B123D5A3EDCAD914B4795A3B67F04,
	AndroidJavaObject_Finalize_m87374EE46B27BE3559CACED8A1B62475200AB5AA,
	AndroidJavaObject_Dispose_m87886676A84FA079C0FE45E6C31D790D764652BE,
	AndroidJavaObject__Call_m4C4D7D7287030773175BDF47681EA018DFA4DF1A,
	NULL,
	NULL,
	NULL,
	AndroidJavaObject__CallStatic_mD63902D30CD5626DAEAD1D6484AF7A9ACA85590E,
	NULL,
	NULL,
	NULL,
	AndroidJavaObject_AndroidJavaObjectDeleteLocalRef_mB1EEE323CA333E5DB2871794F1E9094E488682E2,
	AndroidJavaObject_AndroidJavaClassDeleteLocalRef_m54CF986C577935C4B4FDC72612CCE0F13079AD08,
	NULL,
	AndroidJavaObject__GetRawObject_mC5B8B60BEF515F5EE2A113D60991A433DA740C69,
	AndroidJavaObject__GetRawClass_m470EAEBF8B0BD365FD13F1C6F55119836452FDFA,
	AndroidJavaClass__ctor_mB5466169E1151B8CC44C8FED234D79984B431389,
	AndroidJavaClass__AndroidJavaClass_mF481A9584D78F32C64219FDA49CB84B6F0A017DD,
	AndroidJavaClass__ctor_mB206D3CB990755BD56E308F61CD43BB9EA4421D0,
	AndroidReflection_IsPrimitive_m48ED73958206D552B937EEC7560184C6C4228F3D,
	AndroidReflection_IsAssignableFrom_mE4CCA11A87A7E49591786C98FFE239D6EA66F8C5,
	AndroidReflection_GetStaticMethodID_mA7CC0C6E85BD03EA4BFDA8FAF883A4FF9B721C3E,
	AndroidReflection_GetMethodID_m7773DFE09DED5E42B5E6A607A4318318141104E5,
	AndroidReflection_GetConstructorMember_m79D508363805E1AD5FC551644355A1DCF5A01A8A,
	AndroidReflection_GetMethodMember_m6EAFD27B17549F9EF623F5E6341DCAC9E33528CE,
	AndroidReflection_GetFieldMember_m66A8627EBBE89FFAF125264309A85E5001FCEEC3,
	AndroidReflection_GetFieldClass_m394CE3986B992FB51CDA6F18031A4D6390956E00,
	AndroidReflection_GetFieldSignature_m9684AAB2E8AAB2DA4CE2A9DCC18C9088C5E82194,
	AndroidReflection_NewProxyInstance_m06C9BF6A4805DDEED85EC565CDED394E15F2E793,
	AndroidReflection_SetNativeExceptionOnProxy_m3AD392FDF28A10F33D16C0BE27A12D31B2C0883F,
	AndroidReflection__cctor_m8CAB25F51D629BA5AC9986703DE25F9C93E8A454,
	_AndroidJNIHelper_CreateJavaProxy_m6EB0D9FF190B75B8E49397619D1925F442EEBB8A,
	_AndroidJNIHelper_CreateJavaRunnable_m247E2AE8370951BEA9D154FC5AC04BE67F222CF1,
	_AndroidJNIHelper_InvokeJavaProxyMethod_m1DB26565DC2BA3FD2AAA889D1EE72979E78EBD71,
	_AndroidJNIHelper_CreateJNIArgArray_m2075C9584C3A31C8DFFA5D1DDBEE8C5FFBB95892,
	_AndroidJNIHelper_UnboxArray_mD9697E8557EB29A0CFFC3A4423366F75B74C4F1D,
	_AndroidJNIHelper_Unbox_mD43DC20EB0E844E2E3E9373EDDB825B5E61FC0BB,
	_AndroidJNIHelper_Box_mB45F80703BDE58472E812A2122DC70CAFC4E5023,
	_AndroidJNIHelper_DeleteJNIArgArray_mFA2A3664183847343FBB1F76ACD32DE1B1ED0681,
	_AndroidJNIHelper_ConvertToJNIArray_mA0E7A187566E19273CEE6D3BAA053B2178FA6850,
	NULL,
	_AndroidJNIHelper_GetConstructorID_m7506B43EEFEA5F37F1548F63497D31378460FC61,
	_AndroidJNIHelper_GetMethodID_mF34E230F83D1166968B9B80CF2F9F3CFC00CD0C4,
	NULL,
	NULL,
	_AndroidJNIHelper_GetConstructorID_m80A44C210DFE146BDF2EB8FDB2FF19A6BD0337CE,
	_AndroidJNIHelper_GetMethodID_m289D8B1C26B13A8A132565AAFC42FD6C81E99072,
	_AndroidJNIHelper_GetMethodIDFallback_m48DDC7CB61931DD61B3524E65449AFD4F8B9E9F3,
	_AndroidJNIHelper_GetFieldID_mE63F3DAF58A223435525E46590D1AE4F624E9628,
	_AndroidJNIHelper_GetSignature_m1F94418EAEB87AF74E495191DC2AA5293136175B,
	_AndroidJNIHelper_GetSignature_m17AB4F708FC61A101E77C0154684E3E119720FEB,
	NULL,
	_AndroidJNIHelper__ctor_m0535562F59B589E117E57B8EA07ECE900848F509,
	AndroidJNIHelper_get_debug_mEC07393E765F852EFF25F87915975ACB569823E9,
	AndroidJNIHelper_set_debug_mD423F7DFBAC26FE5600D5F3485CD9748B26F656D,
	AndroidJNIHelper_GetConstructorID_mE1D38830BF910D6D575EC04EAC94E9661670C13F,
	AndroidJNIHelper_GetConstructorID_m2A7EE301E50E6200B15858AD095B9E3DCA061B10,
	AndroidJNIHelper_GetMethodID_m6521C6F759BCADC3C7E1CCFCBAE8B3A5BB300796,
	AndroidJNIHelper_GetMethodID_m8C726C02456CFB02AD38F596D8F67151776D8750,
	AndroidJNIHelper_GetMethodID_m5F33E127418D5DA40590E4AE3814D7ACF7810F6E,
	AndroidJNIHelper_GetFieldID_m7B09827CF9F035A3C481B6A4654DA0AC9253CC95,
	AndroidJNIHelper_GetFieldID_m7ADF5933F6A48A98CAB6B54E22943061C8613B17,
	AndroidJNIHelper_GetFieldID_mC795891C3B70C0E8F98D9E8AD2A85103761A0C75,
	AndroidJNIHelper_CreateJavaRunnable_mAA9F7D043B9EDD0A0665E0CA217A7577962A456F,
	AndroidJNIHelper_CreateJavaProxy_m2694F6C774901F6F33044BC41DA29C7CA3F9C1F5,
	AndroidJNIHelper_ConvertToJNIArray_m0561DD17E7D4E7F598504ADFBEF8EC85F3B3A8E7,
	AndroidJNIHelper_CreateJNIArgArray_mCA21BB6EB162E1E77E8F95812BD662EA078EDDBF,
	AndroidJNIHelper_DeleteJNIArgArray_m287B584251A89771CD7C767119A350BD6DDACCAB,
	AndroidJNIHelper_GetConstructorID_m06AB8A133FD78AE60E6B5871CBD24609B9444ED7,
	AndroidJNIHelper_GetMethodID_mC54EF67EA8929F905AA8ACC8A498F21B548E0964,
	AndroidJNIHelper_GetSignature_m1249745E0D54BE68ED874BDB11F97FE7E20B08B9,
	AndroidJNIHelper_GetSignature_mA508F7FFFF3C58701661083E542C3EA41B36FE16,
	NULL,
	NULL,
	NULL,
	NULL,
	AndroidJNI_AttachCurrentThread_mD5647083E547A77F9377BDB78106D426878A00E7,
	AndroidJNI_DetachCurrentThread_m8549BBC1875C2142A1C6BE5B57663E42B9C04A85,
	AndroidJNI_GetVersion_m8778A340C12A1C9ADDC6E9D3470C5D2F842DDDFD,
	AndroidJNI_FindClass_mA0D17BF36250F96F40D8DCF193A7C65E6F6DED7F,
	AndroidJNI_FromReflectedMethod_m4483E987AEC5B258356E5A89F4C3865573AADFE6,
	AndroidJNI_FromReflectedField_m28C7BEDA16685980423347534ECA29587CFEF86A,
	AndroidJNI_ToReflectedMethod_m09271FB4CE49C2C25AC57D8461B6770928C7C3A8,
	AndroidJNI_ToReflectedField_m416106258D081C2DAE25E60CF8DE226AD77321C8,
	AndroidJNI_GetSuperclass_m62D8BD9B93EC9475A7CCEEE93B250AF3BEDCCF28,
	AndroidJNI_IsAssignableFrom_m69B636F6024DBDE83BFCBE699672C8748D1DDFBB,
	AndroidJNI_Throw_m7DE4851503814B5B02B49548CA714123B9279CAD,
	AndroidJNI_ThrowNew_m7A4F77C9C5760FCF134839419070A0BF6B1DD340,
	AndroidJNI_ExceptionOccurred_m6C27C01B14483F99373608BF1A56CA53BA46F926,
	AndroidJNI_ExceptionDescribe_m9E582B7E3ED1CA3D23A35325F676CD88A1E05B5D,
	AndroidJNI_ExceptionClear_m90681289A6CEAF160DB188A3E2177F323D996F82,
	AndroidJNI_FatalError_m93E568BF56843D6C6BDE029BB290E7839D47EF4D,
	AndroidJNI_PushLocalFrame_m4B2AE2B5D545086A6720E97FA8F427F245360FC8,
	AndroidJNI_PopLocalFrame_m2128BB5AAAE2E2E12161EBD13866C69D50D5B78B,
	AndroidJNI_NewGlobalRef_m5F4875C8F71CF25DCC437D2EDB75320C487DB074,
	AndroidJNI_DeleteGlobalRef_m0420C00BACE4BD46DD58F8738DFD9EE8189F542A,
	AndroidJNI_NewWeakGlobalRef_m74933FB5C1E361F566A96B25CF096C770860CD94,
	AndroidJNI_DeleteWeakGlobalRef_m23C9808936212AC528658CB4989F15580BB0C734,
	AndroidJNI_NewLocalRef_mA95E1CDBA47E9CEC4D55BBA178F0ACF4219F6E29,
	AndroidJNI_DeleteLocalRef_m2A8137D15FDE9F781B13F71348FD5FFA1F9841BD,
	AndroidJNI_IsSameObject_m983046376CD2C6C1A1BA4F90CE1EE69570393598,
	AndroidJNI_EnsureLocalCapacity_m861737EE2780929B6F4208C87A3C8F8CDC1C90E6,
	AndroidJNI_AllocObject_m74E773B115EF0FAAC5D4A518FFAFAA118E5EF33F,
	AndroidJNI_NewObject_mD058F016DBC3D58BF2A64EA84D6943052D01E8B1,
	AndroidJNI_GetObjectClass_mA8282FA341DF231C0ADD07DE0B0D0E5999EA0207,
	AndroidJNI_IsInstanceOf_m8A24F4CF1D7B2CD605A09834313BDB9B6DEC3246,
	AndroidJNI_GetMethodID_mCB601A11C971557E2F89DD968224749BD71D2B3A,
	AndroidJNI_GetFieldID_m8CA4FD910FCC33D2D430E1A897043F9E7CD0DF19,
	AndroidJNI_GetStaticMethodID_m46303AF2AAD855E623DFC9C341E848735B626A77,
	AndroidJNI_GetStaticFieldID_m2B47B2D935455E73BDA9E9871FD5A6DF5EDD2717,
	AndroidJNI_NewString_mF3FC7534344BDF4B4BD2B2DB5442B06E2402B23F,
	AndroidJNI_NewStringFromStr_mEEF9F3FF518F3CEEE81780A61DDEB0B93D3ED548,
	AndroidJNI_NewString_m3D31982AB8AC761DEEE7CCD7BAC11A78FA6EE6FB,
	AndroidJNI_NewStringUTF_mC6183C5B20FAAEA418F181A65DD24A7C76978701,
	AndroidJNI_GetStringChars_m462C62C322F38797F05A818CEF5C8D235F1F6714,
	AndroidJNI_GetStringLength_m04D022FE0F5BD6CE06607E508BC4E1BB8AFE96C8,
	AndroidJNI_GetStringUTFLength_m51B5298ABF4A1A0958639F4571571BB537A4AC1F,
	AndroidJNI_GetStringUTFChars_m9C86681B1471BC74EDE87542229BA34894A8CD3A,
	AndroidJNI_CallStringMethod_m932940262AEC9A8121916054C90D79866D29C547,
	AndroidJNI_CallObjectMethod_m059D1BE669D486F2A26B40D6B90BF157B84A3CA3,
	AndroidJNI_CallIntMethod_m5CE09EA0846BF49ABE3E23BC923710A0F1FF4787,
	AndroidJNI_CallBooleanMethod_m6556ACCEDD78DE903521F341072907C4EC90FC96,
	AndroidJNI_CallShortMethod_m889B967EB2D48E331692B199D2EDABACEC8D5F01,
	AndroidJNI_CallByteMethod_m15643014CE496B4D3E689ADEB6E5F88B44EABBF7,
	AndroidJNI_CallSByteMethod_m45D5ABB4DDFBFEFC6DB132FC2D8463C501F1E4A5,
	AndroidJNI_CallCharMethod_mEF6E65AB2EE0BFAA136878966C42FB21529CB91D,
	AndroidJNI_CallFloatMethod_m5BC422FC7D771A08DD18B443CBE3941ACD239FD9,
	AndroidJNI_CallDoubleMethod_m88A34942D1206EEE8BEA95475722D2E8FFFFC711,
	AndroidJNI_CallLongMethod_m2AF630255CC50CB6A875E4FC1E13023699504C6E,
	AndroidJNI_CallVoidMethod_m0B2ED17E5CA42D8D1D503CD329482A5923F1ED67,
	AndroidJNI_GetStringField_m72B978571BE59E46CE385ABF43D27F4F3AD428DC,
	AndroidJNI_GetObjectField_mDC51440CDD5C41B8BE5AB1FC0DB1D4A75A0B00B6,
	AndroidJNI_GetBooleanField_mD4A949E18A3AE1F8844105267EBD669EF4992736,
	AndroidJNI_GetByteField_mD5E50EE3D67C794822974082D8B413823DB51196,
	AndroidJNI_GetSByteField_m74A3F36343350116F6A6F04E91117AAB5CBFFD0C,
	AndroidJNI_GetCharField_m2E6B5082E0CA1EF9F3F3A5F503BB61404DB4B64E,
	AndroidJNI_GetShortField_m1BCF7D56CEB4E2C85C1BE6C1F8BB6F194C437427,
	AndroidJNI_GetIntField_m429B20FC0C03F9526125AF46A37FE36AEDB27A84,
	AndroidJNI_GetLongField_mE133B0457F7DA846EACEE402DA6FBA2F4ABE1904,
	AndroidJNI_GetFloatField_mAFA7BF7AD9A5DCDFCA7847870CA28492776F87FC,
	AndroidJNI_GetDoubleField_m3A52B3C44D03F55A287B38E5069240525EF73A28,
	AndroidJNI_SetStringField_m137F3C45F7DCA41D0DBB6474C1F11ABDF92BD1E5,
	AndroidJNI_SetObjectField_m6C57BE78BFAD68BEB6F938F050E225C39952BCA7,
	AndroidJNI_SetBooleanField_m3E4D6E11693FFB0D7A37F06277EACAF6E5CC2441,
	AndroidJNI_SetByteField_m64709DD80DB6F4D9A15383D51CAFC5B0C71859A8,
	AndroidJNI_SetSByteField_mAF33C0CEE6CFF0D5895D36499A7456DD4BA32022,
	AndroidJNI_SetCharField_m9C07B22EF92F20790848DE682EE5D43F7EABF371,
	AndroidJNI_SetShortField_m7C1DCFA4AB07DD26F41820817B38AD1B255E1733,
	AndroidJNI_SetIntField_m81A869C1EDABE5E86A9C282908AE73CDF8B5D8AE,
	AndroidJNI_SetLongField_mBB1D3A9EA6962BA3F587C5FCD1A2BBCADDE061B9,
	AndroidJNI_SetFloatField_m9AA38D8D235C9D789A6BD5E0F3E3FD4833984CAB,
	AndroidJNI_SetDoubleField_mE593C3C60A11AE3B157221EA9247DDBCD8FE5191,
	AndroidJNI_CallStaticStringMethod_m728910FCD2307FC8A06ACA204C6308896E1F9634,
	AndroidJNI_CallStaticObjectMethod_mD81C9407381F719A207F5AD038D38A1DDF181306,
	AndroidJNI_CallStaticIntMethod_mF3BBC45BEA5618BDE9E8C35CF86E4089CB366FAB,
	AndroidJNI_CallStaticBooleanMethod_m19B53E56531AEDB6735F1D5651E622E4E823EE92,
	AndroidJNI_CallStaticShortMethod_m7510F3205665CF3134DD91BAB86458A916B4FA67,
	AndroidJNI_CallStaticByteMethod_mA607D02EC420A4A811BF3B4DD3ACC29EF4F9E0D0,
	AndroidJNI_CallStaticSByteMethod_m91B3565EC4E89DB5DD6994ED9DC03DC1506D9ABD,
	AndroidJNI_CallStaticCharMethod_mC17CFB28DA453858E2D5189C4A93985A5074ECAC,
	AndroidJNI_CallStaticFloatMethod_m50DD95A67820F5A3E3C62556600D985DA697889B,
	AndroidJNI_CallStaticDoubleMethod_m9396E74A4DC7D047134A5DCFFBB343651C1C46FC,
	AndroidJNI_CallStaticLongMethod_m2E00D7592B163630AF5352E89F6180F6B56B8278,
	AndroidJNI_CallStaticVoidMethod_mE1E41BEF150679746147820E058E034CCE9F5FB3,
	AndroidJNI_GetStaticStringField_m6C8673931581ED0646BA2D059C45514ED9D8530F,
	AndroidJNI_GetStaticObjectField_m6E2116C7207C76FBFE2D26A376B10C00D9C49190,
	AndroidJNI_GetStaticBooleanField_m91EE84C77BB16B3ADE727DDCC0F6AC7D262012CA,
	AndroidJNI_GetStaticByteField_m5C141BD8E937CEB382D4FA050A4F7A638A76182E,
	AndroidJNI_GetStaticSByteField_m3F82DDF01CA24E139B8F35C5821C528FB8B04B96,
	AndroidJNI_GetStaticCharField_m70532959E334E3745AEF21C7A77C10221E639F20,
	AndroidJNI_GetStaticShortField_mB4FC3F0637204FE8E2466F8E9C5F2AE9C4F53101,
	AndroidJNI_GetStaticIntField_m6AE681D1B1EF0DFE81714A3EB2CBEA6281DF136E,
	AndroidJNI_GetStaticLongField_m2838DE5CE092E4DCD0BF8C69AE366444117AE22A,
	AndroidJNI_GetStaticFloatField_m33D3E4CC3A6219BD8529ACEF168644650093C326,
	AndroidJNI_GetStaticDoubleField_m538DA725808C50CF8CF77FA6539865F22761FA86,
	AndroidJNI_SetStaticStringField_mBE032CF9EBDF2E8D724512826F2CA5AFA075C21F,
	AndroidJNI_SetStaticObjectField_mB5FFECBB4D5D963EF0454957F9F4661FFA833555,
	AndroidJNI_SetStaticBooleanField_m487E8387D32B024009C37D9B3A800381A475C659,
	AndroidJNI_SetStaticByteField_m50FEB9D2D9D846AED6643B58E4AC7B2AE92986AC,
	AndroidJNI_SetStaticSByteField_mBD550D0F0E9A54FD039C0DE4EE8C21990C5A39C3,
	AndroidJNI_SetStaticCharField_m06825B1CFD06746E47F0192FA4F2FC3D3125E9DA,
	AndroidJNI_SetStaticShortField_m4A4132E557627F1954AE30C36CDD3BB329949C9A,
	AndroidJNI_SetStaticIntField_mD0DDF159656B3F999FFD3BB812E97B3E39F08649,
	AndroidJNI_SetStaticLongField_mCBC20FE3812F3C3CF5FA0C8CAE96A5A63061437E,
	AndroidJNI_SetStaticFloatField_mD6B054EE0170B31C26C9A85E49A6A01C60DFE908,
	AndroidJNI_SetStaticDoubleField_mE274169EFC6A08190E5D13984398A637500D069E,
	AndroidJNI_ToBooleanArray_m60F3CE17AE326BA244382C39F0FAE9F86DA1F206,
	AndroidJNI_ToByteArray_mA20FD81095A5C55B49F5362F586258D6E1361F14,
	AndroidJNI_ToSByteArray_m5E75BAD1F59BF0993F573E548837DB5BEFD136D0,
	AndroidJNI_ToCharArray_mA2081BFCF1F054F7AF1FF6C02DBCD3DDF842ACD1,
	AndroidJNI_ToShortArray_m5C720FF3C3E8A33E7F0679DEE1CF29279A3F6EE4,
	AndroidJNI_ToIntArray_m4F7B434E1B855ED0CCA21E5D3FE94BABCC246805,
	AndroidJNI_ToLongArray_mBE89CB90348200EFD4A8939241A030FF7FB3B205,
	AndroidJNI_ToFloatArray_m805231BFD408148D10ECB4B19935D49FD2E59E73,
	AndroidJNI_ToDoubleArray_m5365EB845635C82BAFC86696C6083F22A79F49EE,
	AndroidJNI_ToObjectArray_mED4ECAFBCB6517A46658F92FCCF2492ADE08C3B5,
	AndroidJNI_ToObjectArray_m4C6CE46586423FD0BECCF68B8205DF5F6EE927BC,
	AndroidJNI_FromBooleanArray_m5EE3946B096CBAFCDED6E33AD0BEDF392CE3C2E3,
	AndroidJNI_FromByteArray_m2E5209DB888EB1CFD47E732AB5F565CEB351B766,
	AndroidJNI_FromSByteArray_m46D4FF95707BEC89FB35BADAC0D778D1F9FFE600,
	AndroidJNI_FromCharArray_mC965E533F95CD2ED4BE5DB99579D6C9723F9FFEF,
	AndroidJNI_FromShortArray_m155B1A19DC1AA710079277D8392ECC84578C095C,
	AndroidJNI_FromIntArray_m0139900B65713B2EC09EB03596157D39968E81BC,
	AndroidJNI_FromLongArray_mCFB950966DB71AE966C3CE5B8B2FC63BD874B3EC,
	AndroidJNI_FromFloatArray_mDC9E8A87B643677DB1CD67FB90EE6AC30A2352C5,
	AndroidJNI_FromDoubleArray_m069C4F1F762610BA916F674B3125A68634F27AB8,
	AndroidJNI_FromObjectArray_mFED788163BF5C17E83D2DF65A9056DB08EF91761,
	AndroidJNI_GetArrayLength_m67AF3E58A9CFD97E7934D2E63D0306865A78DA12,
	AndroidJNI_NewBooleanArray_m3B0B21E3EDEEEB7C24DB553D3647A08B49B77236,
	AndroidJNI_NewByteArray_m5F59BAD46869E8B2FEDF729F0D822FA15FE8B808,
	AndroidJNI_NewSByteArray_mCC033B02E3FB52227DD2F7CF359C7259535BF40B,
	AndroidJNI_NewCharArray_m113A3ABE8D00BEAD48C9ADEEC42837DFD295DB5E,
	AndroidJNI_NewShortArray_m931058DCCBDBAA9BEFFAF0D605B11E292AAE845C,
	AndroidJNI_NewIntArray_m53DAF097F1A42A462C00032044E67F5ED2D46B55,
	AndroidJNI_NewLongArray_mF29BD86C4CE9A89BC9D0C8D6AFB2BDD91A34615A,
	AndroidJNI_NewFloatArray_m7B884413B6C595CD5BFA4ED4ED7D2503605783AE,
	AndroidJNI_NewDoubleArray_m1C7B86959F420149C5D5045FA1F68CC976C76165,
	AndroidJNI_NewObjectArray_m8B0C45BD47F6563EA916E35BE26691DFA6482A51,
	AndroidJNI_GetBooleanArrayElement_m9AE3C91E6EE77BBB1664BE6A698EB40DBAF0A715,
	AndroidJNI_GetByteArrayElement_m3C4347DB47CB2AD3D35D2F10EF5F3B9A169CC209,
	AndroidJNI_GetSByteArrayElement_m9F91FD32379FD2C8658F113876A9C66C83F1B278,
	AndroidJNI_GetCharArrayElement_m158503FC9DC4456294B5825061535B2C57295D28,
	AndroidJNI_GetShortArrayElement_m402A50E5EB01EDB9D3471FDEBDBB291A2029E0EB,
	AndroidJNI_GetIntArrayElement_mEB2F9FE140A298C151C1CD6E4C40E3F7CEE7364C,
	AndroidJNI_GetLongArrayElement_mE5C85EE2864C469EB89227E9D9305DB1798D7631,
	AndroidJNI_GetFloatArrayElement_m1F81665927FDA4E8C700297AB4455BBF5F9526C7,
	AndroidJNI_GetDoubleArrayElement_m5D2B8F144CD011AAA8A94F30DD3816EDA61BD155,
	AndroidJNI_GetObjectArrayElement_mDD7F2DC202FA14B8E5889755FB02B401C1127AD0,
	AndroidJNI_SetBooleanArrayElement_mB3AE5B3BDD6852FB6115600B1EB2081F68A23B71,
	AndroidJNI_SetBooleanArrayElement_m981C25BCDCDE216B4DD88094586C7A9F17625322,
	AndroidJNI_SetByteArrayElement_mCABBF82507C866AF4DF359F8A7FEC23EB0D14AB4,
	AndroidJNI_SetSByteArrayElement_mBB31E6212B68AAD76DF7BB433E8EE8539F6E7C62,
	AndroidJNI_SetCharArrayElement_m7C15256F6AFE46D6886443B6E8FFAA84213A3F3E,
	AndroidJNI_SetShortArrayElement_mB2924B72AD7F32281E0CDBF58B38F65A21C2A7BC,
	AndroidJNI_SetIntArrayElement_m97426E41A5D318E16C0DB59DDBD530D156010127,
	AndroidJNI_SetLongArrayElement_m794F6D1322125F22DCDD8B1BEA94CFB37BD3E6B0,
	AndroidJNI_SetFloatArrayElement_m373C39039A2EAEB220312B95C4AED773D1836B57,
	AndroidJNI_SetDoubleArrayElement_m8F33446F84DD44198CA338D5C7D0FE79064DAAFC,
	AndroidJNI_SetObjectArrayElement_m5D80CF792A1C492F97EC3378E36FFF458BAFD8D1,
	AndroidJNISafe_CheckException_mD1BB59188CDDCC2559F595CE1240E6BB12F1D546,
	AndroidJNISafe_DeleteGlobalRef_mC71D9B4DBED2AB66D49764253BA8DE912F731A40,
	AndroidJNISafe_DeleteWeakGlobalRef_m9B39A30D764938DC4C8D526321520701D77D34A7,
	AndroidJNISafe_DeleteLocalRef_m80503AA6C85CE46E8CE72C62215E1BE62964424D,
	AndroidJNISafe_NewString_m6D6411F7DACFD383054457D88C0F0F1F8AE0CFB9,
	AndroidJNISafe_GetStringChars_m21A07825755C0A9AF91F8248A1C98F861E26928F,
	AndroidJNISafe_GetObjectClass_m78626C2B107D46FA9276B6FD32D746EEB81E8D2D,
	AndroidJNISafe_GetStaticMethodID_mDD304107A2DCF7C4FFFC6E820361618693FCD8C7,
	AndroidJNISafe_GetMethodID_m4E480BAEFB37F467848EC9074C6917A2D8E853DC,
	AndroidJNISafe_GetFieldID_m82034BB65220C7ACA5CA977789463EF827C4C0BF,
	AndroidJNISafe_GetStaticFieldID_mC79AC0A4A44034B7A6D19ED2CE6AF24F7369B698,
	AndroidJNISafe_FromReflectedMethod_mA0F291FDD88E4B0BD2242D9846833C696CF64F86,
	AndroidJNISafe_FindClass_m921B6BE5C8F1F1A4207761AD07A57C0D5F599DDE,
	AndroidJNISafe_NewObject_mCA783442B4DE3E0071D2C71DE69A655EF8538E2C,
	AndroidJNISafe_SetStaticObjectField_mE4688623E6BD1DD91127F4958DC4712290380DBA,
	AndroidJNISafe_SetStaticStringField_m509E182615D4C2F7B753B225A04A8BFBA126FFA0,
	AndroidJNISafe_SetStaticCharField_m73E7E7D9BE1A738206FAC4F90C26D5B316D07214,
	AndroidJNISafe_SetStaticDoubleField_m94C4E9C749D081B785F5D24532B544D59E4096A6,
	AndroidJNISafe_SetStaticFloatField_mBBCC8840D96B2965206D6448B6B2EDAE3CDC2339,
	AndroidJNISafe_SetStaticLongField_m217087BFC4296606744CEB69506C4C0B9F49521F,
	AndroidJNISafe_SetStaticShortField_m4EC080E45ACC7D82F242F68EBC2C7ACDA3CB8D1C,
	AndroidJNISafe_SetStaticSByteField_m05DB36918BF549ED3783179BB25BD2BB434400F0,
	AndroidJNISafe_SetStaticBooleanField_m4DCD279423F848CE0884BACEF2ABBECC5B21BB37,
	AndroidJNISafe_SetStaticIntField_mE36FEAE2FEB2D1B231F31D52EAEE2C956B496CB7,
	AndroidJNISafe_GetStaticObjectField_m7A3E277AE5003C9ADB2B184739736F86A0A03AD4,
	AndroidJNISafe_GetStaticStringField_mD0DC3837F26C82A38BFC42C8450823D53B0326EF,
	AndroidJNISafe_GetStaticCharField_m4FDBF70F20C8A63D61CBE1DB322231C8D7CE2FF6,
	AndroidJNISafe_GetStaticDoubleField_mB0B0EC3DB652C45C177D663F71D63352CF31989E,
	AndroidJNISafe_GetStaticFloatField_mC947331D47B4102982F809E8A27FF05114E5321A,
	AndroidJNISafe_GetStaticLongField_mF93D2C6310F4BAE072E311010A87C76F1E729379,
	AndroidJNISafe_GetStaticShortField_m84E78B16341CC92D47C97D5EBBEE157C24B3845A,
	AndroidJNISafe_GetStaticSByteField_m0C17CA332A1C79E8AFB20119E9FC54301D40A847,
	AndroidJNISafe_GetStaticBooleanField_m5EE57D854FD22446DB1BD1A24019958B8FC9B4F2,
	AndroidJNISafe_GetStaticIntField_m8C4987D43981A1740AEFDA7B4B9A6A2C512E5AC4,
	AndroidJNISafe_CallStaticVoidMethod_m965D8C47FDF1388EA6192108063B129C870B382F,
	AndroidJNISafe_CallStaticObjectMethod_mFF379E5F210AF38781F1FB59667AC39C4CFA5966,
	AndroidJNISafe_CallStaticStringMethod_mC5449583711986CFF9CCDAD3F8058D9842229B88,
	AndroidJNISafe_CallStaticCharMethod_m435C3A57BC14CCA2F459E1CE9D3E9F084353634C,
	AndroidJNISafe_CallStaticDoubleMethod_mDCA07255A15D31B20FFD77A795A7FD47C8661D1D,
	AndroidJNISafe_CallStaticFloatMethod_mCEF7855DF0530B27B6E0B4B1C1E78667FD80B2B6,
	AndroidJNISafe_CallStaticLongMethod_mA98EE656033866FC4DE05F3F815F76594FA18D84,
	AndroidJNISafe_CallStaticShortMethod_m134B1C6791FD9A09180ADF481475880F4F8B79A4,
	AndroidJNISafe_CallStaticSByteMethod_mC9057F28DC0C675701810414D19C7168A68F026D,
	AndroidJNISafe_CallStaticBooleanMethod_mF980739844CAA33E0E0ADA82F5177F91E39CCB75,
	AndroidJNISafe_CallStaticIntMethod_mE174E036EAB1034BA4DC107F534F0F7B6DA8FBC6,
	AndroidJNISafe_SetObjectField_mB37CDFD1291DC6BC7D73668AED11A3B59E1C2B10,
	AndroidJNISafe_SetStringField_m7AC7481678855A9DFFFBAED8D5C095AA6D3D8C79,
	AndroidJNISafe_SetCharField_m1BC58426F7753388A053FEA0137561854AB919F8,
	AndroidJNISafe_SetDoubleField_m0F9363465DDCE31EAD4F86867549A85AA5C3A09B,
	AndroidJNISafe_SetFloatField_m84552EDFC955EB994071C5E2B03A955B169D2842,
	AndroidJNISafe_SetLongField_m6F65BE8E3095D1344FD77A9E7D039A7E3D94A925,
	AndroidJNISafe_SetShortField_m8626A5FBFCE546B5C17834F06326A2B7938E70B5,
	AndroidJNISafe_SetSByteField_m52A563214F0AB2027CB4124311F147F789AE52CB,
	AndroidJNISafe_SetBooleanField_mE88CEE9AAF0B56AD5A1A1741C7612EEA6E0521F1,
	AndroidJNISafe_SetIntField_mA25D81AEE8AB2AA562EA8B03BF7F81D9202C368C,
	AndroidJNISafe_GetObjectField_mD645E1D470CF975C1285EFF0A28C66FC37EFA520,
	AndroidJNISafe_GetStringField_m65B73D43D6FA6A76E18AA78FB566A123FC832381,
	AndroidJNISafe_GetCharField_mE1C213483F3E07366C8FAE114648538E446202B9,
	AndroidJNISafe_GetDoubleField_m5E7778FD959CAA9256AB3E6ADCAC024B5A8D1CC3,
	AndroidJNISafe_GetFloatField_m86A2AE1F0D2D81BA1587FDF2EA10693786BA0BBB,
	AndroidJNISafe_GetLongField_m31E20FF52A23F3928BC3576173FCF435076A45A0,
	AndroidJNISafe_GetShortField_m835A602FF3722BA91111A36120C09DC16F58BF69,
	AndroidJNISafe_GetSByteField_mBFC442E1921CD7542D2705337A7E1A8D806EC42C,
	AndroidJNISafe_GetBooleanField_mB1CE25A87F17492A866F2FB302D69532A50ED114,
	AndroidJNISafe_GetIntField_m61F97AAEAE3410AB91489B59E2B9F1714D686724,
	AndroidJNISafe_CallVoidMethod_m37B8331F4A139234C98323FE19FAC5F3E29EE743,
	AndroidJNISafe_CallObjectMethod_m220EBB62A14A40DD5693A48E5787DE4636D051EA,
	AndroidJNISafe_CallStringMethod_mABFAE9A418A989676CB15D01E5971E431BFD4579,
	AndroidJNISafe_CallCharMethod_m4A39264614C8E7A9E2645F7C0E208062990A9D90,
	AndroidJNISafe_CallDoubleMethod_m53CDFD6982DECEB5F155858B4D0B8D7A06B426DD,
	AndroidJNISafe_CallFloatMethod_m95871A924AA515B19EEFD76FC5DABE3E2FAE4909,
	AndroidJNISafe_CallLongMethod_m6F9F122D99AB7C95774CE395A98153B705D07931,
	AndroidJNISafe_CallShortMethod_mDA06E47602A9F365C91DB7D3B78A699D8A48F861,
	AndroidJNISafe_CallSByteMethod_mA5011FBB030ABC0A47C34052A49A7BEBC1F9EDC0,
	AndroidJNISafe_CallBooleanMethod_m9B26AA2F5828D29D1F1BC3315BABE97F3614EE08,
	AndroidJNISafe_CallIntMethod_m1C01B0148542E93B661401AB695295F4DFB334A8,
	AndroidJNISafe_FromCharArray_mC1C728B67330FD610542B4C2D6B9759F78B2BD17,
	AndroidJNISafe_FromDoubleArray_mB752FB522CD25191E5C6AF8CEFA4553593F784A7,
	AndroidJNISafe_FromFloatArray_m97B7BC8546EC3F9CF0784D434D4AA41FBB409892,
	AndroidJNISafe_FromLongArray_m687FC548BFA4DC440379619E5C7CB56354E30D59,
	AndroidJNISafe_FromShortArray_m227116D8E01EE3568936FB93C97CAEE9062A0A35,
	AndroidJNISafe_FromByteArray_mAED5B8EEF34E268BB146A277842089C7FD8A06BB,
	AndroidJNISafe_FromSByteArray_m5825C71BA6941CDF25627AD77CDBE648CB322476,
	AndroidJNISafe_FromBooleanArray_m3F57F10FDDBA3DC358BEF7296F58D819C9EC3BDE,
	AndroidJNISafe_FromIntArray_m899EDC375E4983DCF33B5B72E2131DC06AA4B5F0,
	AndroidJNISafe_ToObjectArray_m0F776C4B1BA875104CCB8345797A9269A3EBCF07,
	AndroidJNISafe_ToCharArray_m8C8F076F9A471146F6BCF063F7415E89BC0FC801,
	AndroidJNISafe_ToDoubleArray_mCAF30FC9FA2947EBC680D89374A5296D775132A9,
	AndroidJNISafe_ToFloatArray_m15157B7C76CE04863F365E7052671AC87D8556E0,
	AndroidJNISafe_ToLongArray_m00D8D5A5D1B46639307AA78C5E4E7421EA0FF16A,
	AndroidJNISafe_ToShortArray_m3591547B05CEABD583A023C267091A536E3F925C,
	AndroidJNISafe_ToByteArray_m13141E44A84BDC2716432D09131984A4ADFC101F,
	AndroidJNISafe_ToSByteArray_mEFB80D7817A15C285872B8F3C1A9A1EDEA9ECC34,
	AndroidJNISafe_ToBooleanArray_m2E622CCA3AB1B19FE519F975391636CA7DECDAF7,
	AndroidJNISafe_ToIntArray_mA46A79AFCB3909BB90FFF2D20EFDA042E6A4DE97,
	AndroidJNISafe_GetObjectArrayElement_m515AF7717FD44C40A5FFFD6E50DFCD65A35B8FF5,
	AndroidJNISafe_GetArrayLength_mB5F7260E652BE95FE9237A47C1E1597306B462C3,
	AndroidAssetPackInfo__ctor_m747C0EAD6448BA479BAE3C5EAB67F205E0307972,
	AndroidAssetPackState__ctor_m5CB1F078A45558A0966BA32FCFE18CFC46CA941B,
	AndroidAssetPackUseMobileDataRequestResult__ctor_mB46211F6D3B3A421B1C1D9E05F3FC62858383E8F,
	AndroidAssetPacks_GetAssetPackManager_m4E016B09EB3D38DEE6E5A207439D48823A8017CD,
	AssetPackManagerDownloadStatusCallback__ctor_m03D0B212EFAEACF611D60596E978DD0468C6D936,
	AssetPackManagerDownloadStatusCallback_onStatusUpdate_m4042BE15C2B4A64CE1BAF4734E6A0BF8DD4FFC7A,
	AssetPackManagerMobileDataConfirmationCallback__ctor_m927FCB784F7D90524C6725B9E64EF8799538999B,
	AssetPackManagerMobileDataConfirmationCallback_onMobileDataConfirmationResult_m61FEFDED8787D798CF30CB78DC133505B7D3614A,
	AssetPackManagerStatusQueryCallback__ctor_m66F3B4A8BD8911F07121E2F8EF871741CE3A2CDB,
	AssetPackManagerStatusQueryCallback_onStatusResult_m8C41C5CC2F37808E5C5C12B023DF31E1DF96C314,
	PermissionCallbacks_add_PermissionGranted_m74335D4200D9B1A7C80AB9C133F95C61FCDCDF89,
	PermissionCallbacks_remove_PermissionGranted_m4A3F9873FC159F89A2AD35F2FCAFF66A19813AF4,
	PermissionCallbacks_add_PermissionDenied_mE0B2826463785B050C999C70F443FCC3822563D0,
	PermissionCallbacks_remove_PermissionDenied_mF1A606ADE21F9520909126D3642B0BC2D6E994A1,
	PermissionCallbacks_add_PermissionDeniedAndDontAskAgain_mEDE8C00FEF2F649F10A47F30AC4ECB09E52DB9AA,
	PermissionCallbacks_remove_PermissionDeniedAndDontAskAgain_m55B04AE58C687946BDFA2094ED851518B2A1D68D,
	PermissionCallbacks__ctor_m91B14BBBC8913C131E400BA0D13576822AAE7A75,
	PermissionCallbacks_onPermissionGranted_m723440705B5B21B97AF5206716275BAE2A122E3C,
	PermissionCallbacks_onPermissionDenied_m0E05122B560DD62BB38178EE601E65854017980A,
	PermissionCallbacks_onPermissionDeniedAndDontAskAgain_m1191CF6422AFD8E8FE7BDBDBC04721D63718A5D9,
};
static const int32_t s_InvokerIndices[403] = 
{
	2278,
	5418,
	2281,
	5312,
	4285,
	5418,
	8060,
	5418,
	4309,
	5418,
	4309,
	4309,
	5418,
	1712,
	1712,
	2983,
	5284,
	5312,
	5312,
	5286,
	8497,
	2281,
	2281,
	2281,
	2281,
	2281,
	2281,
	5418,
	0,
	2281,
	0,
	2281,
	0,
	0,
	0,
	0,
	5286,
	5286,
	5312,
	0,
	0,
	0,
	0,
	4309,
	805,
	2281,
	4285,
	5418,
	5418,
	4219,
	2281,
	0,
	0,
	0,
	2281,
	0,
	0,
	0,
	8131,
	8131,
	0,
	5286,
	5286,
	4309,
	4309,
	4285,
	7931,
	7193,
	6666,
	6666,
	7409,
	6281,
	6281,
	8059,
	8131,
	7408,
	6982,
	8497,
	7409,
	8060,
	6665,
	8133,
	8133,
	8133,
	8133,
	7693,
	8060,
	0,
	7409,
	6281,
	0,
	0,
	7409,
	6281,
	6281,
	6281,
	8133,
	8133,
	0,
	5418,
	8428,
	8307,
	8059,
	7409,
	7409,
	6662,
	6281,
	7409,
	6662,
	6281,
	8060,
	8060,
	8060,
	8133,
	7693,
	7409,
	6281,
	8133,
	8133,
	0,
	0,
	0,
	0,
	8450,
	8450,
	8450,
	8060,
	8059,
	8059,
	6659,
	6659,
	8059,
	7179,
	8025,
	7378,
	8452,
	8497,
	8497,
	8319,
	8023,
	8059,
	8059,
	8317,
	8059,
	8317,
	8059,
	8317,
	7179,
	8023,
	8059,
	6660,
	8059,
	7179,
	6662,
	6662,
	6662,
	6662,
	8060,
	8060,
	8060,
	8060,
	8131,
	8025,
	8025,
	8131,
	6694,
	6660,
	6621,
	6534,
	6597,
	6534,
	6730,
	6762,
	6740,
	6587,
	6651,
	6977,
	7443,
	7408,
	7179,
	7179,
	7503,
	7537,
	7342,
	7377,
	7400,
	7509,
	7328,
	6977,
	6976,
	6971,
	6971,
	6978,
	6980,
	6973,
	6974,
	6975,
	6979,
	6972,
	6694,
	6660,
	6621,
	6534,
	6597,
	6534,
	6730,
	6762,
	6740,
	6587,
	6651,
	6977,
	7443,
	7408,
	7179,
	7179,
	7503,
	7537,
	7342,
	7377,
	7400,
	7509,
	7328,
	6977,
	6976,
	6971,
	6971,
	6978,
	6980,
	6973,
	6974,
	6975,
	6979,
	6972,
	8060,
	8060,
	8060,
	8060,
	8060,
	8060,
	8060,
	8060,
	8060,
	7411,
	8060,
	8131,
	8131,
	8131,
	8131,
	8131,
	8131,
	8131,
	8131,
	8131,
	8131,
	8025,
	8057,
	8057,
	8057,
	8057,
	8057,
	8057,
	8057,
	8057,
	8057,
	6658,
	7178,
	7178,
	7502,
	7536,
	7341,
	7376,
	7399,
	7508,
	7327,
	7407,
	6962,
	6962,
	6968,
	6968,
	6970,
	6964,
	6965,
	6966,
	6969,
	6963,
	6967,
	8497,
	8317,
	8317,
	8317,
	8060,
	8131,
	8059,
	6662,
	6662,
	6662,
	6662,
	8059,
	8060,
	6660,
	6976,
	6977,
	6980,
	6972,
	6979,
	6975,
	6973,
	6978,
	6971,
	6974,
	7408,
	7443,
	7537,
	7328,
	7509,
	7400,
	7342,
	7503,
	7179,
	7377,
	6977,
	6660,
	6694,
	6762,
	6587,
	6740,
	6651,
	6597,
	6730,
	6534,
	6621,
	6976,
	6977,
	6980,
	6972,
	6979,
	6975,
	6973,
	6978,
	6971,
	6974,
	7408,
	7443,
	7537,
	7328,
	7509,
	7400,
	7342,
	7503,
	7179,
	7377,
	6977,
	6660,
	6694,
	6762,
	6587,
	6740,
	6651,
	6597,
	6730,
	6534,
	6621,
	8131,
	8131,
	8131,
	8131,
	8131,
	8131,
	8131,
	8131,
	8131,
	7411,
	8060,
	8060,
	8060,
	8060,
	8060,
	8060,
	8060,
	8060,
	8060,
	7407,
	8025,
	186,
	1140,
	4219,
	8458,
	2281,
	182,
	4309,
	4219,
	2281,
	747,
	4309,
	4309,
	4309,
	4309,
	4309,
	4309,
	5418,
	4309,
	4309,
	4309,
};
static const Il2CppTokenRangePair s_rgctxIndices[23] = 
{
	{ 0x06000021, { 0, 1 } },
	{ 0x06000022, { 1, 1 } },
	{ 0x06000023, { 2, 1 } },
	{ 0x06000024, { 3, 1 } },
	{ 0x06000028, { 4, 1 } },
	{ 0x06000029, { 5, 1 } },
	{ 0x0600002A, { 6, 1 } },
	{ 0x0600002B, { 7, 1 } },
	{ 0x06000034, { 8, 4 } },
	{ 0x06000035, { 12, 4 } },
	{ 0x06000036, { 16, 3 } },
	{ 0x06000038, { 19, 4 } },
	{ 0x06000039, { 23, 4 } },
	{ 0x0600003A, { 27, 3 } },
	{ 0x0600003D, { 30, 2 } },
	{ 0x06000058, { 32, 2 } },
	{ 0x0600005B, { 34, 1 } },
	{ 0x0600005C, { 35, 1 } },
	{ 0x06000063, { 36, 1 } },
	{ 0x06000078, { 37, 1 } },
	{ 0x06000079, { 38, 1 } },
	{ 0x0600007A, { 39, 1 } },
	{ 0x0600007B, { 40, 1 } },
};
extern const uint32_t g_rgctx_AndroidJavaObject__Get_TisFieldType_tE541E61DC1EE486A3DDC10DCA2A2DD9A2A3BADE8_m06134DE4CC6EA8E3189542B792E94123E91E03C6;
extern const uint32_t g_rgctx_AndroidJavaObject__Set_TisFieldType_t5C6F84F3CFFB0874A4DA0D1C58053A25B835551E_m462146FCC7D2B3F83FF6E8999553D33E4959F5BE;
extern const uint32_t g_rgctx_AndroidJavaObject__GetStatic_TisFieldType_tBB418E296327456981AAF34C2BEB510AEC3C4E4D_m287CA0417FCCBDC7C54BA521F00661EE781AE83E;
extern const uint32_t g_rgctx_AndroidJavaObject__SetStatic_TisFieldType_t6076CC06F19BCC0301AE8C734F26CA429D2DB469_m63581F10344537651B9090C50B7BAFA8B9CDB1A3;
extern const uint32_t g_rgctx_AndroidJavaObject__Call_TisReturnType_t6A981EFC55AACA8DB2914A6B9C24AF2C1F0D86E3_mBA92180AE68E07DA29AB2ED05D52AA22E1ECEC52;
extern const uint32_t g_rgctx_AndroidJavaObject__Call_TisReturnType_t7C9CEFF53F7F785E3B0A2AA52BF0599DB9E4C7A7_m53C8581E9FA8AB194F9919FD0B5F910D4D0EDEDF;
extern const uint32_t g_rgctx_AndroidJavaObject__CallStatic_TisReturnType_t41223B870DEBD9DC66C7F3F6FDDF2CF6D061E4EB_mA272E4A1258A5DB68113DF8B90DF5B5B3A724832;
extern const uint32_t g_rgctx_AndroidJavaObject__CallStatic_TisReturnType_t94E13999E45FF70AA5DA5E427955FC4E439412B2_m7F6D9361C675DD63CF53A9BE7588D79625F85B4D;
extern const uint32_t g_rgctx_AndroidJNIHelper_GetMethodID_TisReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9_m7FA36234B45F9903C0B0CDEBE1B54DCD39A13C72;
extern const uint32_t g_rgctx_ReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9;
extern const uint32_t g_rgctx_ReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9;
extern const uint32_t g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9_m5ED9B59C80B23E79BB4230605BCE9D3A137F981E;
extern const uint32_t g_rgctx_AndroidJNIHelper_GetFieldID_TisFieldType_tBD81DD51AB3076BC0134BD255EBBAC34E341C535_m6368887E847198EC2D7995760B85C36C079CBD51;
extern const uint32_t g_rgctx_FieldType_tBD81DD51AB3076BC0134BD255EBBAC34E341C535;
extern const uint32_t g_rgctx_FieldType_tBD81DD51AB3076BC0134BD255EBBAC34E341C535;
extern const uint32_t g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisFieldType_tBD81DD51AB3076BC0134BD255EBBAC34E341C535_m0F52966238B5888B94F0FB77CA01442E5F02E6F7;
extern const uint32_t g_rgctx_AndroidJNIHelper_GetFieldID_TisFieldType_t2F905C7C598CE04C35E1297452F5AE8BFD208DAE_m0D46185EB2E37AAF12DDA38D56D57B1F227DEAC5;
extern const uint32_t g_rgctx_FieldType_t2F905C7C598CE04C35E1297452F5AE8BFD208DAE;
extern const uint32_t g_rgctx_FieldType_t2F905C7C598CE04C35E1297452F5AE8BFD208DAE;
extern const uint32_t g_rgctx_AndroidJNIHelper_GetMethodID_TisReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27_m41D8B27438C044781B1CAEFF8C3D98E9E6B21818;
extern const uint32_t g_rgctx_ReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27;
extern const uint32_t g_rgctx_ReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27;
extern const uint32_t g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27_mB3A1E6CF7D03BB9DDF35E7E2BE4C29EA2F36C17F;
extern const uint32_t g_rgctx_AndroidJNIHelper_GetFieldID_TisFieldType_t31FF3BC94504224433BABB9DAD6CE4032EA80634_mE5BA64651BBE7A67E794246A07DEE5EABBA41DD0;
extern const uint32_t g_rgctx_FieldType_t31FF3BC94504224433BABB9DAD6CE4032EA80634;
extern const uint32_t g_rgctx_FieldType_t31FF3BC94504224433BABB9DAD6CE4032EA80634;
extern const uint32_t g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisFieldType_t31FF3BC94504224433BABB9DAD6CE4032EA80634_mE30D9C8DD4A4C690594B1118242BA9EFBA4E04DE;
extern const uint32_t g_rgctx_AndroidJNIHelper_GetFieldID_TisFieldType_t0374C27CAE86F7DA1E32463BA4A51CE6B68D02E1_m24F4A0D0476D023A96987DC8AAC67E118C1C9422;
extern const uint32_t g_rgctx_FieldType_t0374C27CAE86F7DA1E32463BA4A51CE6B68D02E1;
extern const uint32_t g_rgctx_FieldType_t0374C27CAE86F7DA1E32463BA4A51CE6B68D02E1;
extern const uint32_t g_rgctx_AndroidJNIHelper_ConvertFromJNIArray_TisReturnType_t6F6A8AAD1934478A88473188C291F7CEEE555E73_m4B892F7AD0542C392F743019B7218AFDAFEABD68;
extern const uint32_t g_rgctx_ReturnType_t6F6A8AAD1934478A88473188C291F7CEEE555E73;
extern const uint32_t g_rgctx_ArrayType_t39F42761AC90C900B8A48509E901BA6E97D3879B;
extern const uint32_t g_rgctx_ArrayType_t39F42761AC90C900B8A48509E901BA6E97D3879B;
extern const uint32_t g_rgctx__AndroidJNIHelper_GetSignature_TisReturnType_tEC17892DFE45E2A034D63503275043AAE3B9599D_m36DEB041CA570208002E5FB9A443601A54460C73;
extern const uint32_t g_rgctx_ReturnType_t4115D49E15B816AA2133301AFBEEA6B5E9928819;
extern const uint32_t g_rgctx_ReturnType_tBDDF22167069A86BB26C0100BBDE8BF7FE746984;
extern const uint32_t g_rgctx__AndroidJNIHelper_ConvertFromJNIArray_TisArrayType_t4E16470C69F824CCEAFF1C35E3BD65E700433C8D_m79E24A56A47AA341285459B81B432B0DB4BB5E00;
extern const uint32_t g_rgctx__AndroidJNIHelper_GetMethodID_TisReturnType_t9337B47B2F29B15EC319F165264468E864AE5381_mE5379E80F384020D4EE22BD44DE9FF5766BA175B;
extern const uint32_t g_rgctx__AndroidJNIHelper_GetFieldID_TisFieldType_tC608EDFA1FEABDBF35DB2E6BAB0FF88B3CCC5305_mCF183F032307D5B8EF7DD48DE9DC136B7294A2DC;
extern const uint32_t g_rgctx__AndroidJNIHelper_GetSignature_TisReturnType_t1A180124B8DA763DAEE7F018A86273E3F46C0221_m7A66522327751D68EEE60A2AFB5B6244012BE829;
static const Il2CppRGCTXDefinition s_rgctxValues[41] = 
{
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject__Get_TisFieldType_tE541E61DC1EE486A3DDC10DCA2A2DD9A2A3BADE8_m06134DE4CC6EA8E3189542B792E94123E91E03C6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject__Set_TisFieldType_t5C6F84F3CFFB0874A4DA0D1C58053A25B835551E_m462146FCC7D2B3F83FF6E8999553D33E4959F5BE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject__GetStatic_TisFieldType_tBB418E296327456981AAF34C2BEB510AEC3C4E4D_m287CA0417FCCBDC7C54BA521F00661EE781AE83E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject__SetStatic_TisFieldType_t6076CC06F19BCC0301AE8C734F26CA429D2DB469_m63581F10344537651B9090C50B7BAFA8B9CDB1A3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject__Call_TisReturnType_t6A981EFC55AACA8DB2914A6B9C24AF2C1F0D86E3_mBA92180AE68E07DA29AB2ED05D52AA22E1ECEC52 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject__Call_TisReturnType_t7C9CEFF53F7F785E3B0A2AA52BF0599DB9E4C7A7_m53C8581E9FA8AB194F9919FD0B5F910D4D0EDEDF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject__CallStatic_TisReturnType_t41223B870DEBD9DC66C7F3F6FDDF2CF6D061E4EB_mA272E4A1258A5DB68113DF8B90DF5B5B3A724832 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject__CallStatic_TisReturnType_t94E13999E45FF70AA5DA5E427955FC4E439412B2_m7F6D9361C675DD63CF53A9BE7588D79625F85B4D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJNIHelper_GetMethodID_TisReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9_m7FA36234B45F9903C0B0CDEBE1B54DCD39A13C72 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_ReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9_m5ED9B59C80B23E79BB4230605BCE9D3A137F981E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJNIHelper_GetFieldID_TisFieldType_tBD81DD51AB3076BC0134BD255EBBAC34E341C535_m6368887E847198EC2D7995760B85C36C079CBD51 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_FieldType_tBD81DD51AB3076BC0134BD255EBBAC34E341C535 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_FieldType_tBD81DD51AB3076BC0134BD255EBBAC34E341C535 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisFieldType_tBD81DD51AB3076BC0134BD255EBBAC34E341C535_m0F52966238B5888B94F0FB77CA01442E5F02E6F7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJNIHelper_GetFieldID_TisFieldType_t2F905C7C598CE04C35E1297452F5AE8BFD208DAE_m0D46185EB2E37AAF12DDA38D56D57B1F227DEAC5 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_FieldType_t2F905C7C598CE04C35E1297452F5AE8BFD208DAE },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_FieldType_t2F905C7C598CE04C35E1297452F5AE8BFD208DAE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJNIHelper_GetMethodID_TisReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27_m41D8B27438C044781B1CAEFF8C3D98E9E6B21818 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_ReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27_mB3A1E6CF7D03BB9DDF35E7E2BE4C29EA2F36C17F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJNIHelper_GetFieldID_TisFieldType_t31FF3BC94504224433BABB9DAD6CE4032EA80634_mE5BA64651BBE7A67E794246A07DEE5EABBA41DD0 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_FieldType_t31FF3BC94504224433BABB9DAD6CE4032EA80634 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_FieldType_t31FF3BC94504224433BABB9DAD6CE4032EA80634 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisFieldType_t31FF3BC94504224433BABB9DAD6CE4032EA80634_mE30D9C8DD4A4C690594B1118242BA9EFBA4E04DE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJNIHelper_GetFieldID_TisFieldType_t0374C27CAE86F7DA1E32463BA4A51CE6B68D02E1_m24F4A0D0476D023A96987DC8AAC67E118C1C9422 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_FieldType_t0374C27CAE86F7DA1E32463BA4A51CE6B68D02E1 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_FieldType_t0374C27CAE86F7DA1E32463BA4A51CE6B68D02E1 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJNIHelper_ConvertFromJNIArray_TisReturnType_t6F6A8AAD1934478A88473188C291F7CEEE555E73_m4B892F7AD0542C392F743019B7218AFDAFEABD68 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ReturnType_t6F6A8AAD1934478A88473188C291F7CEEE555E73 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_ArrayType_t39F42761AC90C900B8A48509E901BA6E97D3879B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ArrayType_t39F42761AC90C900B8A48509E901BA6E97D3879B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx__AndroidJNIHelper_GetSignature_TisReturnType_tEC17892DFE45E2A034D63503275043AAE3B9599D_m36DEB041CA570208002E5FB9A443601A54460C73 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_ReturnType_t4115D49E15B816AA2133301AFBEEA6B5E9928819 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_ReturnType_tBDDF22167069A86BB26C0100BBDE8BF7FE746984 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx__AndroidJNIHelper_ConvertFromJNIArray_TisArrayType_t4E16470C69F824CCEAFF1C35E3BD65E700433C8D_m79E24A56A47AA341285459B81B432B0DB4BB5E00 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx__AndroidJNIHelper_GetMethodID_TisReturnType_t9337B47B2F29B15EC319F165264468E864AE5381_mE5379E80F384020D4EE22BD44DE9FF5766BA175B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx__AndroidJNIHelper_GetFieldID_TisFieldType_tC608EDFA1FEABDBF35DB2E6BAB0FF88B3CCC5305_mCF183F032307D5B8EF7DD48DE9DC136B7294A2DC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx__AndroidJNIHelper_GetSignature_TisReturnType_t1A180124B8DA763DAEE7F018A86273E3F46C0221_m7A66522327751D68EEE60A2AFB5B6244012BE829 },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_AndroidJNIModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_AndroidJNIModule_CodeGenModule = 
{
	"UnityEngine.AndroidJNIModule.dll",
	403,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	23,
	s_rgctxIndices,
	41,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
