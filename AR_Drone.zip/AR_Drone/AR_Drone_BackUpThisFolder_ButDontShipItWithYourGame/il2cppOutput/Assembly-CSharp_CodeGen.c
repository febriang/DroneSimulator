﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void FlyingAndMovingState::OnStateEnter(UnityEngine.Animator,UnityEngine.AnimatorStateInfo,System.Int32)
extern void FlyingAndMovingState_OnStateEnter_mAB7C690C75676AA68EA0BFABE2E4B5137AAF98A1 (void);
// 0x00000002 System.Void FlyingAndMovingState::OnStateExit(UnityEngine.Animator,UnityEngine.AnimatorStateInfo,System.Int32)
extern void FlyingAndMovingState_OnStateExit_m6DF8F0E1881A0843C384C09888BFA5149109E59E (void);
// 0x00000003 System.Void FlyingAndMovingState::.ctor()
extern void FlyingAndMovingState__ctor_m8111CEAD06862C6E047A42FEE6549B8D1A01FA82 (void);
// 0x00000004 System.Void LandingAndMovingState::OnStateExit(UnityEngine.Animator,UnityEngine.AnimatorStateInfo,System.Int32)
extern void LandingAndMovingState_OnStateExit_m86718D5A7650CD3C36F4A90CFB4437258BE19FE0 (void);
// 0x00000005 System.Void LandingAndMovingState::.ctor()
extern void LandingAndMovingState__ctor_mD8FB040C1B6625A966B62BC5A49F9C1720DA5387 (void);
// 0x00000006 System.Void LandingState::OnStateExit(UnityEngine.Animator,UnityEngine.AnimatorStateInfo,System.Int32)
extern void LandingState_OnStateExit_m1307B6055E45BBA0E014ECC8A584E90AE575DB07 (void);
// 0x00000007 System.Void LandingState::.ctor()
extern void LandingState__ctor_mBAC11DA4A2C40B7D78BF2CC872BA18553CCD0E55 (void);
// 0x00000008 System.Void TakingOffState::OnStateExit(UnityEngine.Animator,UnityEngine.AnimatorStateInfo,System.Int32)
extern void TakingOffState_OnStateExit_m990A40AC77DC92908015A2EE45A6C75D33469907 (void);
// 0x00000009 System.Void TakingOffState::.ctor()
extern void TakingOffState__ctor_m17BD806A71324FE2F90345A826A5EB2A2F8B1AA2 (void);
// 0x0000000A System.Boolean DroneController::isIdle()
extern void DroneController_isIdle_m0503FEED16CB68156DD3D29FD51CB5EFC44BAA91 (void);
// 0x0000000B System.Void DroneController::TakeOff()
extern void DroneController_TakeOff_m928BF038D5556EEBFC9B42D32FC377AE3A6EEFFF (void);
// 0x0000000C System.Boolean DroneController::isFlying()
extern void DroneController_isFlying_m1132D94346C580AA6A21F0F83F0BB4F8AB0B114E (void);
// 0x0000000D System.Void DroneController::Land()
extern void DroneController_Land_m1B4F43B1862A535B0DDB877E254CEF683E50C1F4 (void);
// 0x0000000E System.Void DroneController::Start()
extern void DroneController_Start_m845711AE6688093E343C5E9D5E0458A0BC3FDD0F (void);
// 0x0000000F System.Void DroneController::UpdateDrone()
extern void DroneController_UpdateDrone_m77DA1ABBA0BB5541D79A519739743EBEDB3B0AF8 (void);
// 0x00000010 System.Void DroneController::Move(System.Single,System.Single)
extern void DroneController_Move_m708FB2651515D96F36EFA2DABA02A1E4E5282C1D (void);
// 0x00000011 System.Void DroneController::.ctor()
extern void DroneController__ctor_m12014F05D17C9138A05D8C9A066E049A6DC42768 (void);
// 0x00000012 System.Void GameManager::Start()
extern void GameManager_Start_m87A71D65F3171A58DBDDBFB03832ADA65643D0E2 (void);
// 0x00000013 System.Void GameManager::FixedUpdate()
extern void GameManager_FixedUpdate_mCBA9C3ED1DE7FC1B9D9609D702B13EFB38245017 (void);
// 0x00000014 System.Void GameManager::UpdateAR()
extern void GameManager_UpdateAR_m533285F601C34F0D7A288E7EE5C78CD59940D502 (void);
// 0x00000015 System.Void GameManager::UpdateControls(GameManager/DroneAnimationControls&)
extern void GameManager_UpdateControls_mD8BDFBFFE589F3BB16564ECCDD05B18800155EC0 (void);
// 0x00000016 System.Void GameManager::EventOnClickFlyButton()
extern void GameManager_EventOnClickFlyButton_m8D6025F86BE4B373C6A556C9E542A8AC449BCF0A (void);
// 0x00000017 System.Void GameManager::EventOnClickLandButton()
extern void GameManager_EventOnClickLandButton_m619FDD8BE73D5F6156E6C9E650055E065B515F72 (void);
// 0x00000018 System.Void GameManager::EventOnLeftButtonPressed()
extern void GameManager_EventOnLeftButtonPressed_mB91C6B3A974AD7B728E330831D32342A9E83156D (void);
// 0x00000019 System.Void GameManager::EventOnLeftButtonReleased()
extern void GameManager_EventOnLeftButtonReleased_m7B433DA1012435CBFD85F9E3530BF4D93B340812 (void);
// 0x0000001A System.Void GameManager::EventOnRightButtonPressed()
extern void GameManager_EventOnRightButtonPressed_mB64B3537CBC00343FA0A10B4E1555FB9F8E11196 (void);
// 0x0000001B System.Void GameManager::EventOnRightButtonReleased()
extern void GameManager_EventOnRightButtonReleased_m73D8647F49D0F58332FDE998EDD92ABA784D301D (void);
// 0x0000001C System.Void GameManager::EventOnBackButtonPressed()
extern void GameManager_EventOnBackButtonPressed_m966FC1BFF44A44F2B1E405023C25A555FCC96C81 (void);
// 0x0000001D System.Void GameManager::EventOnBackButtonReleased()
extern void GameManager_EventOnBackButtonReleased_m109EC88C00B6969F41F3CB37D6A339F74ACF257F (void);
// 0x0000001E System.Void GameManager::EventOnForwardButtonPressed()
extern void GameManager_EventOnForwardButtonPressed_m2DC4BD9341556B06D74510E2C33670F206FABD14 (void);
// 0x0000001F System.Void GameManager::EventOnForwardButtonReleased()
extern void GameManager_EventOnForwardButtonReleased_m0CDF52ACF63FF5930552AB6D57FF8C48FB4D0313 (void);
// 0x00000020 System.Void GameManager::BackMenu()
extern void GameManager_BackMenu_mC64E2FD55675D8837F393AE50B55E0337BB42D50 (void);
// 0x00000021 System.Void GameManager::.ctor()
extern void GameManager__ctor_mF453CED520617BFB65C52405A964E06CF17DB368 (void);
// 0x00000022 System.Void SwitchScene::StartMenu()
extern void SwitchScene_StartMenu_mDA5AE8EEE07D1ECDF3C35F1AFF483037B422892D (void);
// 0x00000023 System.Void SwitchScene::ExitMenu()
extern void SwitchScene_ExitMenu_mC778B4892D026D4BDA7C9BB5F97BB1927C9DB81B (void);
// 0x00000024 System.Void SwitchScene::.ctor()
extern void SwitchScene__ctor_m952ED4020DD0C41DFC96B2088E72F87611E4F028 (void);
static Il2CppMethodPointer s_methodPointers[36] = 
{
	FlyingAndMovingState_OnStateEnter_mAB7C690C75676AA68EA0BFABE2E4B5137AAF98A1,
	FlyingAndMovingState_OnStateExit_m6DF8F0E1881A0843C384C09888BFA5149109E59E,
	FlyingAndMovingState__ctor_m8111CEAD06862C6E047A42FEE6549B8D1A01FA82,
	LandingAndMovingState_OnStateExit_m86718D5A7650CD3C36F4A90CFB4437258BE19FE0,
	LandingAndMovingState__ctor_mD8FB040C1B6625A966B62BC5A49F9C1720DA5387,
	LandingState_OnStateExit_m1307B6055E45BBA0E014ECC8A584E90AE575DB07,
	LandingState__ctor_mBAC11DA4A2C40B7D78BF2CC872BA18553CCD0E55,
	TakingOffState_OnStateExit_m990A40AC77DC92908015A2EE45A6C75D33469907,
	TakingOffState__ctor_m17BD806A71324FE2F90345A826A5EB2A2F8B1AA2,
	DroneController_isIdle_m0503FEED16CB68156DD3D29FD51CB5EFC44BAA91,
	DroneController_TakeOff_m928BF038D5556EEBFC9B42D32FC377AE3A6EEFFF,
	DroneController_isFlying_m1132D94346C580AA6A21F0F83F0BB4F8AB0B114E,
	DroneController_Land_m1B4F43B1862A535B0DDB877E254CEF683E50C1F4,
	DroneController_Start_m845711AE6688093E343C5E9D5E0458A0BC3FDD0F,
	DroneController_UpdateDrone_m77DA1ABBA0BB5541D79A519739743EBEDB3B0AF8,
	DroneController_Move_m708FB2651515D96F36EFA2DABA02A1E4E5282C1D,
	DroneController__ctor_m12014F05D17C9138A05D8C9A066E049A6DC42768,
	GameManager_Start_m87A71D65F3171A58DBDDBFB03832ADA65643D0E2,
	GameManager_FixedUpdate_mCBA9C3ED1DE7FC1B9D9609D702B13EFB38245017,
	GameManager_UpdateAR_m533285F601C34F0D7A288E7EE5C78CD59940D502,
	GameManager_UpdateControls_mD8BDFBFFE589F3BB16564ECCDD05B18800155EC0,
	GameManager_EventOnClickFlyButton_m8D6025F86BE4B373C6A556C9E542A8AC449BCF0A,
	GameManager_EventOnClickLandButton_m619FDD8BE73D5F6156E6C9E650055E065B515F72,
	GameManager_EventOnLeftButtonPressed_mB91C6B3A974AD7B728E330831D32342A9E83156D,
	GameManager_EventOnLeftButtonReleased_m7B433DA1012435CBFD85F9E3530BF4D93B340812,
	GameManager_EventOnRightButtonPressed_mB64B3537CBC00343FA0A10B4E1555FB9F8E11196,
	GameManager_EventOnRightButtonReleased_m73D8647F49D0F58332FDE998EDD92ABA784D301D,
	GameManager_EventOnBackButtonPressed_m966FC1BFF44A44F2B1E405023C25A555FCC96C81,
	GameManager_EventOnBackButtonReleased_m109EC88C00B6969F41F3CB37D6A339F74ACF257F,
	GameManager_EventOnForwardButtonPressed_m2DC4BD9341556B06D74510E2C33670F206FABD14,
	GameManager_EventOnForwardButtonReleased_m0CDF52ACF63FF5930552AB6D57FF8C48FB4D0313,
	GameManager_BackMenu_mC64E2FD55675D8837F393AE50B55E0337BB42D50,
	GameManager__ctor_mF453CED520617BFB65C52405A964E06CF17DB368,
	SwitchScene_StartMenu_mDA5AE8EEE07D1ECDF3C35F1AFF483037B422892D,
	SwitchScene_ExitMenu_mC778B4892D026D4BDA7C9BB5F97BB1927C9DB81B,
	SwitchScene__ctor_m952ED4020DD0C41DFC96B2088E72F87611E4F028,
};
static const int32_t s_InvokerIndices[36] = 
{
	1127,
	1127,
	5418,
	1127,
	5418,
	1127,
	5418,
	1127,
	5418,
	5223,
	5418,
	5223,
	5418,
	5418,
	5418,
	2331,
	5418,
	5418,
	5418,
	5418,
	4181,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	36,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
