﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void UnityEngine.TextCore.Text.Character::.ctor()
extern void Character__ctor_m5DCCE862D40487C733C29A233DB8513A9A6A02F6 (void);
// 0x00000002 System.Void UnityEngine.TextCore.Text.Character::.ctor(System.UInt32,UnityEngine.TextCore.Text.FontAsset,UnityEngine.TextCore.Glyph)
extern void Character__ctor_mEEAC42D4227E0053C8008C12B222CC208D781795 (void);
// 0x00000003 System.Void UnityEngine.TextCore.Text.Character::.ctor(System.UInt32,System.UInt32)
extern void Character__ctor_m21FBFAF1F6324565246096EFFB81C3F9E15D43CC (void);
// 0x00000004 System.Boolean UnityEngine.TextCore.Text.ColorUtilities::CompareColors(UnityEngine.Color32,UnityEngine.Color32)
extern void ColorUtilities_CompareColors_m66829BD52BE7906CCEAC57DE94C4024AF372BD8D (void);
// 0x00000005 UnityEngine.Color32 UnityEngine.TextCore.Text.ColorUtilities::MultiplyColors(UnityEngine.Color32,UnityEngine.Color32)
extern void ColorUtilities_MultiplyColors_m1C827E2736C56C30621318B1358ABC9BF5B59C68 (void);
// 0x00000006 UnityEngine.Font UnityEngine.TextCore.Text.FontAsset::get_sourceFontFile()
extern void FontAsset_get_sourceFontFile_m6B0E805BD1B7712F0B5135D157E96F3F40314830 (void);
// 0x00000007 System.Void UnityEngine.TextCore.Text.FontAsset::set_sourceFontFile(UnityEngine.Font)
extern void FontAsset_set_sourceFontFile_m2E6D2AED5E5D2585A09E9BF830387DEB10A2F4E8 (void);
// 0x00000008 UnityEngine.TextCore.Text.AtlasPopulationMode UnityEngine.TextCore.Text.FontAsset::get_atlasPopulationMode()
extern void FontAsset_get_atlasPopulationMode_m5364C5A9E84969D8E4FF8436BD18A3F10BF90366 (void);
// 0x00000009 System.Void UnityEngine.TextCore.Text.FontAsset::set_atlasPopulationMode(UnityEngine.TextCore.Text.AtlasPopulationMode)
extern void FontAsset_set_atlasPopulationMode_m1A9DD5C702ED0924B9C208F4CE5ADEACF9188268 (void);
// 0x0000000A UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.Text.FontAsset::get_faceInfo()
extern void FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9 (void);
// 0x0000000B System.Void UnityEngine.TextCore.Text.FontAsset::set_faceInfo(UnityEngine.TextCore.FaceInfo)
extern void FontAsset_set_faceInfo_mCCA87B67C4CA2C0A1F6D85FB1FAA09667996EDCD (void);
// 0x0000000C System.Int32 UnityEngine.TextCore.Text.FontAsset::get_familyNameHashCode()
extern void FontAsset_get_familyNameHashCode_mF2DB211A5712A291B2D28FCDB7F7C29057770330 (void);
// 0x0000000D System.Void UnityEngine.TextCore.Text.FontAsset::set_familyNameHashCode(System.Int32)
extern void FontAsset_set_familyNameHashCode_mE1495199BCE7B771CC920E2DBB86A8AF1518CB55 (void);
// 0x0000000E System.Int32 UnityEngine.TextCore.Text.FontAsset::get_styleNameHashCode()
extern void FontAsset_get_styleNameHashCode_m3CD3D77F64DAEB31D8F69E4D7CC1AD0AC784ABF5 (void);
// 0x0000000F System.Void UnityEngine.TextCore.Text.FontAsset::set_styleNameHashCode(System.Int32)
extern void FontAsset_set_styleNameHashCode_mE1BE5B75DE1E9EA0F76569609E6C4FFDC57558BA (void);
// 0x00000010 UnityEngine.TextCore.Text.FontWeightPair[] UnityEngine.TextCore.Text.FontAsset::get_fontWeightTable()
extern void FontAsset_get_fontWeightTable_m8DADE0BCE53D53EEECE27025F7E94FDD4BF00099 (void);
// 0x00000011 System.Void UnityEngine.TextCore.Text.FontAsset::set_fontWeightTable(UnityEngine.TextCore.Text.FontWeightPair[])
extern void FontAsset_set_fontWeightTable_m39D8B63BD3FCC773AAB5634C6D9314C713161814 (void);
// 0x00000012 System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph> UnityEngine.TextCore.Text.FontAsset::get_glyphTable()
extern void FontAsset_get_glyphTable_m212E940F74AEE62ACBB3374486296CA518D934B5 (void);
// 0x00000013 System.Void UnityEngine.TextCore.Text.FontAsset::set_glyphTable(System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph>)
extern void FontAsset_set_glyphTable_m2753BC6CEE011983C2B4B181867C3EB00CDE87D4 (void);
// 0x00000014 System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Glyph> UnityEngine.TextCore.Text.FontAsset::get_glyphLookupTable()
extern void FontAsset_get_glyphLookupTable_mD04A90D8262F1963EDC472272B67BBFAF73DEEA5 (void);
// 0x00000015 System.Collections.Generic.List`1<UnityEngine.TextCore.Text.Character> UnityEngine.TextCore.Text.FontAsset::get_characterTable()
extern void FontAsset_get_characterTable_mC77FAE1355269834F7C8A2D46AFB4BFE7B7AD72D (void);
// 0x00000016 System.Void UnityEngine.TextCore.Text.FontAsset::set_characterTable(System.Collections.Generic.List`1<UnityEngine.TextCore.Text.Character>)
extern void FontAsset_set_characterTable_m44703292F669F2F6D4920EB9427077E24FB1512C (void);
// 0x00000017 System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.Character> UnityEngine.TextCore.Text.FontAsset::get_characterLookupTable()
extern void FontAsset_get_characterLookupTable_m7E76D6C706C5CEB04A9541C68AE6D9E5C75F0FFC (void);
// 0x00000018 UnityEngine.Texture2D UnityEngine.TextCore.Text.FontAsset::get_atlasTexture()
extern void FontAsset_get_atlasTexture_mC49216F40093C7AC4FA5DA68F9F5C9FCC83B8F27 (void);
// 0x00000019 UnityEngine.Texture2D[] UnityEngine.TextCore.Text.FontAsset::get_atlasTextures()
extern void FontAsset_get_atlasTextures_mADD7A506F0444A1EE4F1D52536B0C5DA9BE35075 (void);
// 0x0000001A System.Void UnityEngine.TextCore.Text.FontAsset::set_atlasTextures(UnityEngine.Texture2D[])
extern void FontAsset_set_atlasTextures_m5315BA4903B77742EFA1E54CEA2AF12726B10A99 (void);
// 0x0000001B System.Int32 UnityEngine.TextCore.Text.FontAsset::get_atlasTextureCount()
extern void FontAsset_get_atlasTextureCount_mC20300C53E52D7A8351DE296BAD565268568119F (void);
// 0x0000001C System.Boolean UnityEngine.TextCore.Text.FontAsset::get_isMultiAtlasTexturesEnabled()
extern void FontAsset_get_isMultiAtlasTexturesEnabled_mF222228A76102BB0EA593A60439D22F912761F1E (void);
// 0x0000001D System.Void UnityEngine.TextCore.Text.FontAsset::set_isMultiAtlasTexturesEnabled(System.Boolean)
extern void FontAsset_set_isMultiAtlasTexturesEnabled_mA470AF6D312989E752C68DC0FD5700235877566B (void);
// 0x0000001E System.Boolean UnityEngine.TextCore.Text.FontAsset::get_clearDynamicDataOnBuild()
extern void FontAsset_get_clearDynamicDataOnBuild_mC1F714E56F087B29E0A3B43D820EDCEB78E9EE75 (void);
// 0x0000001F System.Void UnityEngine.TextCore.Text.FontAsset::set_clearDynamicDataOnBuild(System.Boolean)
extern void FontAsset_set_clearDynamicDataOnBuild_mA1C6F298742DF78EC0F81157F0E04246F8B82F7E (void);
// 0x00000020 System.Int32 UnityEngine.TextCore.Text.FontAsset::get_atlasWidth()
extern void FontAsset_get_atlasWidth_mE711550FDD4B5F988B77AB5D332A80A34B5CF364 (void);
// 0x00000021 System.Void UnityEngine.TextCore.Text.FontAsset::set_atlasWidth(System.Int32)
extern void FontAsset_set_atlasWidth_mFFB9D37EB1C648384ED1426B42E26A4104D329B1 (void);
// 0x00000022 System.Int32 UnityEngine.TextCore.Text.FontAsset::get_atlasHeight()
extern void FontAsset_get_atlasHeight_m306FBF7D35C39123A4770E147FAF95B1B8DE8086 (void);
// 0x00000023 System.Void UnityEngine.TextCore.Text.FontAsset::set_atlasHeight(System.Int32)
extern void FontAsset_set_atlasHeight_m7116DFD32F38971CE39D7F4BF84CB5217DCAA2B5 (void);
// 0x00000024 System.Int32 UnityEngine.TextCore.Text.FontAsset::get_atlasPadding()
extern void FontAsset_get_atlasPadding_m251A35FB5F499EE66CC2E2150CBEDB2C8C5D5581 (void);
// 0x00000025 System.Void UnityEngine.TextCore.Text.FontAsset::set_atlasPadding(System.Int32)
extern void FontAsset_set_atlasPadding_mB34AA836A3D02722ABED71B3583D767560CA956D (void);
// 0x00000026 UnityEngine.TextCore.LowLevel.GlyphRenderMode UnityEngine.TextCore.Text.FontAsset::get_atlasRenderMode()
extern void FontAsset_get_atlasRenderMode_m036D4BA220E5D4B0C407CA6BC1B09D8914B5058A (void);
// 0x00000027 System.Void UnityEngine.TextCore.Text.FontAsset::set_atlasRenderMode(UnityEngine.TextCore.LowLevel.GlyphRenderMode)
extern void FontAsset_set_atlasRenderMode_m993764193CE75D57DC4CC755336596681A7866D2 (void);
// 0x00000028 System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect> UnityEngine.TextCore.Text.FontAsset::get_usedGlyphRects()
extern void FontAsset_get_usedGlyphRects_mE039AEF3AE45A15A86B2C0F774E6ED58AFA2F341 (void);
// 0x00000029 System.Void UnityEngine.TextCore.Text.FontAsset::set_usedGlyphRects(System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>)
extern void FontAsset_set_usedGlyphRects_mBF80C1063C0A274AD95F55C43DA734E126F6643F (void);
// 0x0000002A System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect> UnityEngine.TextCore.Text.FontAsset::get_freeGlyphRects()
extern void FontAsset_get_freeGlyphRects_mCDAEF0519586C5248BBEDEAA85086CC117903E88 (void);
// 0x0000002B System.Void UnityEngine.TextCore.Text.FontAsset::set_freeGlyphRects(System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>)
extern void FontAsset_set_freeGlyphRects_mED3C0E01ABFC63CE700C701476BA2B66D112AA9B (void);
// 0x0000002C UnityEngine.TextCore.Text.FontFeatureTable UnityEngine.TextCore.Text.FontAsset::get_fontFeatureTable()
extern void FontAsset_get_fontFeatureTable_m7C4EB9A655B237CE02FAF7B8B16C2F2863FE5070 (void);
// 0x0000002D System.Void UnityEngine.TextCore.Text.FontAsset::set_fontFeatureTable(UnityEngine.TextCore.Text.FontFeatureTable)
extern void FontAsset_set_fontFeatureTable_m3FD11B99122416777808E1CE5414D7BA40920C3B (void);
// 0x0000002E System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset> UnityEngine.TextCore.Text.FontAsset::get_fallbackFontAssetTable()
extern void FontAsset_get_fallbackFontAssetTable_m43303BFBE8A8C55D8CE8A67C47EFAFF5A712CB69 (void);
// 0x0000002F System.Void UnityEngine.TextCore.Text.FontAsset::set_fallbackFontAssetTable(System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset>)
extern void FontAsset_set_fallbackFontAssetTable_mE22C3D2323111FD6A5DF9847FB812BD41E18832E (void);
// 0x00000030 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings UnityEngine.TextCore.Text.FontAsset::get_fontAssetCreationEditorSettings()
extern void FontAsset_get_fontAssetCreationEditorSettings_m024033F91B976A8EAA5CBE67D3DB2A756B91CF01 (void);
// 0x00000031 System.Void UnityEngine.TextCore.Text.FontAsset::set_fontAssetCreationEditorSettings(UnityEngine.TextCore.Text.FontAssetCreationEditorSettings)
extern void FontAsset_set_fontAssetCreationEditorSettings_mF7EE6A46807D78A7E99872171D2AD774DE20C7EB (void);
// 0x00000032 System.Single UnityEngine.TextCore.Text.FontAsset::get_regularStyleWeight()
extern void FontAsset_get_regularStyleWeight_m6C4B4D4CAD36800E6E686A05A5DB8D4475F2707F (void);
// 0x00000033 System.Void UnityEngine.TextCore.Text.FontAsset::set_regularStyleWeight(System.Single)
extern void FontAsset_set_regularStyleWeight_m2D1E5440A5E1794A003FF087A87393DA9A114385 (void);
// 0x00000034 System.Single UnityEngine.TextCore.Text.FontAsset::get_regularStyleSpacing()
extern void FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1 (void);
// 0x00000035 System.Void UnityEngine.TextCore.Text.FontAsset::set_regularStyleSpacing(System.Single)
extern void FontAsset_set_regularStyleSpacing_m7CCE54FB9163D65A6B40269B2BDD30199023E797 (void);
// 0x00000036 System.Single UnityEngine.TextCore.Text.FontAsset::get_boldStyleWeight()
extern void FontAsset_get_boldStyleWeight_m804ACC85DD80DC72DB4BCC83C3FB866411F8EFCA (void);
// 0x00000037 System.Void UnityEngine.TextCore.Text.FontAsset::set_boldStyleWeight(System.Single)
extern void FontAsset_set_boldStyleWeight_m204B04CF9E98AD8669025BFDC0EF3CE9AB5CBBA2 (void);
// 0x00000038 System.Single UnityEngine.TextCore.Text.FontAsset::get_boldStyleSpacing()
extern void FontAsset_get_boldStyleSpacing_mB8CF4F4880B110E41D566648FF1D995010CF1FF0 (void);
// 0x00000039 System.Void UnityEngine.TextCore.Text.FontAsset::set_boldStyleSpacing(System.Single)
extern void FontAsset_set_boldStyleSpacing_m62DAA35837E8563DD76E3D162B6DB59BE3804914 (void);
// 0x0000003A System.Byte UnityEngine.TextCore.Text.FontAsset::get_italicStyleSlant()
extern void FontAsset_get_italicStyleSlant_m69E70060C6E7940B4ACE61F2B7CB8965F86DA96B (void);
// 0x0000003B System.Void UnityEngine.TextCore.Text.FontAsset::set_italicStyleSlant(System.Byte)
extern void FontAsset_set_italicStyleSlant_m223875ED81B0397CA36E94A6F346AEE68510C0D2 (void);
// 0x0000003C System.Byte UnityEngine.TextCore.Text.FontAsset::get_tabMultiple()
extern void FontAsset_get_tabMultiple_m9C0422A00BFCF82091F14F4E303E2717247350AE (void);
// 0x0000003D System.Void UnityEngine.TextCore.Text.FontAsset::set_tabMultiple(System.Byte)
extern void FontAsset_set_tabMultiple_mC927B74D27FBB94245E09FE39D9F6749AF07017B (void);
// 0x0000003E UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.FontAsset::CreateFontAsset(System.String,System.String,System.Int32)
extern void FontAsset_CreateFontAsset_mCEBA2B83D9355D570A4B115E529DBBAB30C53931 (void);
// 0x0000003F UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.FontAsset::CreateFontAsset(System.String,System.Int32,System.Int32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphRenderMode,System.Int32,System.Int32,UnityEngine.TextCore.Text.AtlasPopulationMode,System.Boolean)
extern void FontAsset_CreateFontAsset_mEB7722C56F39849ED3BF9A934DA9CB5D5E586D97 (void);
// 0x00000040 UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.FontAsset::CreateFontAsset(UnityEngine.Font)
extern void FontAsset_CreateFontAsset_mCCDD828A47635EA30F5AA67EC244BE2929D8E1F7 (void);
// 0x00000041 UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.FontAsset::CreateFontAsset(UnityEngine.Font,System.Int32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphRenderMode,System.Int32,System.Int32,UnityEngine.TextCore.Text.AtlasPopulationMode,System.Boolean)
extern void FontAsset_CreateFontAsset_m23E71782F785F220F1DD2BBBEB3322B3D4A2750C (void);
// 0x00000042 UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.FontAsset::CreateFontAsset(UnityEngine.Font,System.Int32,System.Int32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphRenderMode,System.Int32,System.Int32,UnityEngine.TextCore.Text.AtlasPopulationMode,System.Boolean)
extern void FontAsset_CreateFontAsset_m87F9CF95DFE84FE372688E2D76610A552C64E971 (void);
// 0x00000043 UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.FontAsset::CreateFontAssetInstance(UnityEngine.Font,System.Int32,UnityEngine.TextCore.LowLevel.GlyphRenderMode,System.Int32,System.Int32,UnityEngine.TextCore.Text.AtlasPopulationMode,System.Boolean)
extern void FontAsset_CreateFontAssetInstance_mFEFE28AC7D600C71046F743917BE70DC5A7532A0 (void);
// 0x00000044 System.Void UnityEngine.TextCore.Text.FontAsset::Awake()
extern void FontAsset_Awake_mB7906A1E21F5FAB84A023B97435F75C09EAB92ED (void);
// 0x00000045 System.Void UnityEngine.TextCore.Text.FontAsset::OnDestroy()
extern void FontAsset_OnDestroy_m3587016A089072C5C03168AA4C6AA1956FE12785 (void);
// 0x00000046 System.Void UnityEngine.TextCore.Text.FontAsset::ReadFontAssetDefinition()
extern void FontAsset_ReadFontAssetDefinition_m6D84DBCB130D530B2F78A7E24232D8A6A81AEC48 (void);
// 0x00000047 System.Void UnityEngine.TextCore.Text.FontAsset::InitializeDictionaryLookupTables()
extern void FontAsset_InitializeDictionaryLookupTables_m29A4AEF49CF11A0E49C229EF13B2262AE66757FF (void);
// 0x00000048 System.Void UnityEngine.TextCore.Text.FontAsset::InitializeGlyphLookupDictionary()
extern void FontAsset_InitializeGlyphLookupDictionary_m82782B7B5C602AD5097A016BF668868C0892CCF6 (void);
// 0x00000049 System.Void UnityEngine.TextCore.Text.FontAsset::InitializeCharacterLookupDictionary()
extern void FontAsset_InitializeCharacterLookupDictionary_m8886A4CA911334BD319AB78F1CBBD68E13624BB6 (void);
// 0x0000004A System.Void UnityEngine.TextCore.Text.FontAsset::InitializeGlyphPaidAdjustmentRecordsLookupDictionary()
extern void FontAsset_InitializeGlyphPaidAdjustmentRecordsLookupDictionary_mDF1C20792344999B9CF500685E6256B0642CE7DD (void);
// 0x0000004B System.Void UnityEngine.TextCore.Text.FontAsset::AddSynthesizedCharactersAndFaceMetrics()
extern void FontAsset_AddSynthesizedCharactersAndFaceMetrics_m203BD62D0A537A6EA7CD7DBA1FF9A94301492933 (void);
// 0x0000004C System.Void UnityEngine.TextCore.Text.FontAsset::AddSynthesizedCharacter(System.UInt32,System.Boolean,System.Boolean)
extern void FontAsset_AddSynthesizedCharacter_m6ABFCE6454A09D5CF7914F318DDC79198C47F9EA (void);
// 0x0000004D System.Void UnityEngine.TextCore.Text.FontAsset::AddCharacterToLookupCache(System.UInt32,UnityEngine.TextCore.Text.Character)
extern void FontAsset_AddCharacterToLookupCache_mB90E06CE313CC0BB6F81415BF8FB4E043108EED8 (void);
// 0x0000004E UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.Text.FontAsset::LoadFontFace()
extern void FontAsset_LoadFontFace_m64C78A2FE5DA2E7029E43B467A1B242827B45B4F (void);
// 0x0000004F System.Void UnityEngine.TextCore.Text.FontAsset::SortCharacterTable()
extern void FontAsset_SortCharacterTable_m9A551DF3B19E246E8C4BE86463E0ED1DEB27D321 (void);
// 0x00000050 System.Void UnityEngine.TextCore.Text.FontAsset::SortGlyphTable()
extern void FontAsset_SortGlyphTable_mC853714CB002D923A19C3A925BB24D6BF42A08CD (void);
// 0x00000051 System.Void UnityEngine.TextCore.Text.FontAsset::SortFontFeatureTable()
extern void FontAsset_SortFontFeatureTable_m072B32D6D8C562F60D3D6CBCC7DCB3282EDD587F (void);
// 0x00000052 System.Void UnityEngine.TextCore.Text.FontAsset::SortAllTables()
extern void FontAsset_SortAllTables_mACA7063865A460F5949E5B8A8D978D588124A094 (void);
// 0x00000053 System.Boolean UnityEngine.TextCore.Text.FontAsset::HasCharacter(System.Int32)
extern void FontAsset_HasCharacter_m6BAF48714E1BF5D8EE7ACF33F774C8C6EEE452F3 (void);
// 0x00000054 System.Boolean UnityEngine.TextCore.Text.FontAsset::HasCharacter(System.Char,System.Boolean,System.Boolean)
extern void FontAsset_HasCharacter_mE87EEF6CDA1F4E1D6928CC9A3C01A91922D4FB21 (void);
// 0x00000055 System.Boolean UnityEngine.TextCore.Text.FontAsset::HasCharacter_Internal(System.UInt32,System.Boolean,System.Boolean)
extern void FontAsset_HasCharacter_Internal_mDC0D2954E0975A7DBC8829E894CDBCABEA7D6A60 (void);
// 0x00000056 System.Boolean UnityEngine.TextCore.Text.FontAsset::HasCharacters(System.String,System.Collections.Generic.List`1<System.Char>&)
extern void FontAsset_HasCharacters_mD670CCEB48448CE5C1430B938F99D4FC659FB2F8 (void);
// 0x00000057 System.Boolean UnityEngine.TextCore.Text.FontAsset::HasCharacters(System.String,System.UInt32[]&,System.Boolean,System.Boolean)
extern void FontAsset_HasCharacters_m97A50BC627C163418CAE0B42A50893057B025E90 (void);
// 0x00000058 System.Boolean UnityEngine.TextCore.Text.FontAsset::HasCharacters(System.String)
extern void FontAsset_HasCharacters_m048839FDD1876CDCA3C5A744592545B46C75E15B (void);
// 0x00000059 System.String UnityEngine.TextCore.Text.FontAsset::GetCharacters(UnityEngine.TextCore.Text.FontAsset)
extern void FontAsset_GetCharacters_mEDFC9A3D23C31F641DC97FB5D19577C2EE3E7D23 (void);
// 0x0000005A System.Int32[] UnityEngine.TextCore.Text.FontAsset::GetCharactersArray(UnityEngine.TextCore.Text.FontAsset)
extern void FontAsset_GetCharactersArray_m0BCE8CB0B1BB70A75F7A1FF5C97C49FE6352AC28 (void);
// 0x0000005B System.UInt32 UnityEngine.TextCore.Text.FontAsset::GetGlyphIndex(System.UInt32)
extern void FontAsset_GetGlyphIndex_mF20097CDB68A8CE866E61D4C237FBB95257A9745 (void);
// 0x0000005C System.Void UnityEngine.TextCore.Text.FontAsset::RegisterFontAssetForFontFeatureUpdate(UnityEngine.TextCore.Text.FontAsset)
extern void FontAsset_RegisterFontAssetForFontFeatureUpdate_mA98498DA5D471A6504E3BC67AEAD6462B1B62C7F (void);
// 0x0000005D System.Void UnityEngine.TextCore.Text.FontAsset::UpdateFontFeaturesForFontAssetsInQueue()
extern void FontAsset_UpdateFontFeaturesForFontAssetsInQueue_m0EB26B49967B52B2EEFF4A2F9234D994B9E62621 (void);
// 0x0000005E System.Void UnityEngine.TextCore.Text.FontAsset::RegisterAtlasTextureForApply(UnityEngine.Texture2D)
extern void FontAsset_RegisterAtlasTextureForApply_m2123B35C0CD237E87C111A32C33D3D81AB8C3D08 (void);
// 0x0000005F System.Void UnityEngine.TextCore.Text.FontAsset::UpdateAtlasTexturesInQueue()
extern void FontAsset_UpdateAtlasTexturesInQueue_m70787779BB9231349342D9036761321A34286A70 (void);
// 0x00000060 System.Void UnityEngine.TextCore.Text.FontAsset::UpdateFontAssetInUpdateQueue()
extern void FontAsset_UpdateFontAssetInUpdateQueue_mF38C30B72EBABBF805BD542501783E2730F8B9B8 (void);
// 0x00000061 System.Boolean UnityEngine.TextCore.Text.FontAsset::TryAddCharacters(System.UInt32[],System.Boolean)
extern void FontAsset_TryAddCharacters_m7F1D0CB7E4D9B8D3CE44D4D01F9CDCEFD4D1B46B (void);
// 0x00000062 System.Boolean UnityEngine.TextCore.Text.FontAsset::TryAddCharacters(System.UInt32[],System.UInt32[]&,System.Boolean)
extern void FontAsset_TryAddCharacters_m9618B4F12C004B8267E0D17ED81B94BE48D85119 (void);
// 0x00000063 System.Boolean UnityEngine.TextCore.Text.FontAsset::TryAddCharacters(System.String,System.Boolean)
extern void FontAsset_TryAddCharacters_m5E282618D9ED92AD0112BC7B6B2C3B1066DDFA63 (void);
// 0x00000064 System.Boolean UnityEngine.TextCore.Text.FontAsset::TryAddCharacters(System.String,System.String&,System.Boolean)
extern void FontAsset_TryAddCharacters_mDA1C3A68799C84A80C27CDB84482684F6822137F (void);
// 0x00000065 System.Boolean UnityEngine.TextCore.Text.FontAsset::TryAddCharacterInternal(System.UInt32,UnityEngine.TextCore.Text.Character&,System.Boolean)
extern void FontAsset_TryAddCharacterInternal_mCDC9AE2C61B9F73B8879C3F5AE00598A67B2BA7F (void);
// 0x00000066 System.Boolean UnityEngine.TextCore.Text.FontAsset::TryGetCharacter_and_QueueRenderToTexture(System.UInt32,UnityEngine.TextCore.Text.Character&,System.Boolean)
extern void FontAsset_TryGetCharacter_and_QueueRenderToTexture_mA76A244F58E0F2978178FBBEB18F2E0DCA568AEC (void);
// 0x00000067 System.Void UnityEngine.TextCore.Text.FontAsset::TryAddGlyphsToAtlasTextures()
extern void FontAsset_TryAddGlyphsToAtlasTextures_m83F7EDB3193B3C9A4FA86B89A51E9FA6A41F6834 (void);
// 0x00000068 System.Boolean UnityEngine.TextCore.Text.FontAsset::TryAddGlyphsToNewAtlasTexture()
extern void FontAsset_TryAddGlyphsToNewAtlasTexture_m8F98FBF7A0EC1B37C4DB43536DA42D3864F6F3AB (void);
// 0x00000069 System.Void UnityEngine.TextCore.Text.FontAsset::SetupNewAtlasTexture()
extern void FontAsset_SetupNewAtlasTexture_m38F81BE1582A15DDDB950E7AAC650CD9B7D14168 (void);
// 0x0000006A System.Void UnityEngine.TextCore.Text.FontAsset::UpdateAtlasTexture()
extern void FontAsset_UpdateAtlasTexture_m30D7C235A878B1A33F2A3891D8096F534C10F6C5 (void);
// 0x0000006B System.Void UnityEngine.TextCore.Text.FontAsset::UpdateGlyphAdjustmentRecords()
extern void FontAsset_UpdateGlyphAdjustmentRecords_mD1C9297EA75EA767A823709CC39B6E57905E22A3 (void);
// 0x0000006C System.Void UnityEngine.TextCore.Text.FontAsset::UpdateGlyphAdjustmentRecords(System.UInt32[])
extern void FontAsset_UpdateGlyphAdjustmentRecords_mC9882537E81709FE1EFA9B744D88C6C32ACEDF52 (void);
// 0x0000006D System.Void UnityEngine.TextCore.Text.FontAsset::UpdateGlyphAdjustmentRecords(System.Collections.Generic.List`1<System.UInt32>)
extern void FontAsset_UpdateGlyphAdjustmentRecords_m2D0444352012E8DFDD6036025886EC0CED0AD82A (void);
// 0x0000006E System.Void UnityEngine.TextCore.Text.FontAsset::UpdateGlyphAdjustmentRecords(System.Collections.Generic.List`1<System.UInt32>,System.Collections.Generic.List`1<System.UInt32>)
extern void FontAsset_UpdateGlyphAdjustmentRecords_m9410421BA99635607C50EED1C9C374570EFABC60 (void);
// 0x0000006F System.Void UnityEngine.TextCore.Text.FontAsset::CopyListDataToArray(System.Collections.Generic.List`1<T>,T[]&)
// 0x00000070 System.Void UnityEngine.TextCore.Text.FontAsset::ClearFontAssetData(System.Boolean)
extern void FontAsset_ClearFontAssetData_m225ADFCBB0CFD481E18637F3D3FDFFEAFC6FE9A1 (void);
// 0x00000071 System.Void UnityEngine.TextCore.Text.FontAsset::ClearFontAssetDataInternal()
extern void FontAsset_ClearFontAssetDataInternal_mD3DB3516BB6D61F0A9630D9F6958F474DFE044F7 (void);
// 0x00000072 System.Void UnityEngine.TextCore.Text.FontAsset::UpdateFontAssetData()
extern void FontAsset_UpdateFontAssetData_mAAC0ED05410942C08E8EFD4678F9565FD8C373D4 (void);
// 0x00000073 System.Void UnityEngine.TextCore.Text.FontAsset::ClearFontAssetTables()
extern void FontAsset_ClearFontAssetTables_m38470615509BEFAE39C90C234D8B460F05824C39 (void);
// 0x00000074 System.Void UnityEngine.TextCore.Text.FontAsset::ClearAtlasTextures(System.Boolean)
extern void FontAsset_ClearAtlasTextures_m5B320A65E1CD35F2C17E27F09158F8E9BDA9EA2B (void);
// 0x00000075 System.Void UnityEngine.TextCore.Text.FontAsset::DestroyAtlasTextures()
extern void FontAsset_DestroyAtlasTextures_mBE2810F8C55E286B5B7ABE24A6F9132F51CBE027 (void);
// 0x00000076 System.Void UnityEngine.TextCore.Text.FontAsset::.ctor()
extern void FontAsset__ctor_mD55676BD025F9D05DBC9A5B32480E092169B9D45 (void);
// 0x00000077 System.Void UnityEngine.TextCore.Text.FontAsset::.cctor()
extern void FontAsset__cctor_m644B5E11138863C477F86E3EE75FA0A82CC6BB29 (void);
// 0x00000078 System.Void UnityEngine.TextCore.Text.FontAsset/<>c::.cctor()
extern void U3CU3Ec__cctor_m7CA74DE9372A832562FB866FB79E5A0CB25D23E1 (void);
// 0x00000079 System.Void UnityEngine.TextCore.Text.FontAsset/<>c::.ctor()
extern void U3CU3Ec__ctor_m3CDF0903C024856278B5A7DF46C7EFCBA6F6B651 (void);
// 0x0000007A System.UInt32 UnityEngine.TextCore.Text.FontAsset/<>c::<SortCharacterTable>b__144_0(UnityEngine.TextCore.Text.Character)
extern void U3CU3Ec_U3CSortCharacterTableU3Eb__144_0_m5655A423C374C42F5761CFBFBEA41E6566421B0B (void);
// 0x0000007B System.UInt32 UnityEngine.TextCore.Text.FontAsset/<>c::<SortGlyphTable>b__145_0(UnityEngine.TextCore.Glyph)
extern void U3CU3Ec_U3CSortGlyphTableU3Eb__145_0_m2BB897F83BD1FE22634624544AFCD8B5988788A0 (void);
// 0x0000007C UnityEngine.TextCore.Text.Character UnityEngine.TextCore.Text.FontAssetUtilities::GetCharacterFromFontAsset(System.UInt32,UnityEngine.TextCore.Text.FontAsset,System.Boolean,UnityEngine.TextCore.Text.FontStyles,UnityEngine.TextCore.Text.TextFontWeight,System.Boolean&)
extern void FontAssetUtilities_GetCharacterFromFontAsset_m2AADCA590977FA4C398D4ECF6E7DF0BE77527801 (void);
// 0x0000007D UnityEngine.TextCore.Text.Character UnityEngine.TextCore.Text.FontAssetUtilities::GetCharacterFromFontAsset_Internal(System.UInt32,UnityEngine.TextCore.Text.FontAsset,System.Boolean,UnityEngine.TextCore.Text.FontStyles,UnityEngine.TextCore.Text.TextFontWeight,System.Boolean&)
extern void FontAssetUtilities_GetCharacterFromFontAsset_Internal_m9B21F45D7C1568509888D6CAC3F428DD4B874AA4 (void);
// 0x0000007E UnityEngine.TextCore.Text.Character UnityEngine.TextCore.Text.FontAssetUtilities::GetCharacterFromFontAssets(System.UInt32,UnityEngine.TextCore.Text.FontAsset,System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset>,System.Boolean,UnityEngine.TextCore.Text.FontStyles,UnityEngine.TextCore.Text.TextFontWeight,System.Boolean&)
extern void FontAssetUtilities_GetCharacterFromFontAssets_mB1612268F7A1926C2C39A4EFFB5AB795F234F9DF (void);
// 0x0000007F UnityEngine.TextCore.Text.SpriteCharacter UnityEngine.TextCore.Text.FontAssetUtilities::GetSpriteCharacterFromSpriteAsset(System.UInt32,UnityEngine.TextCore.Text.SpriteAsset,System.Boolean)
extern void FontAssetUtilities_GetSpriteCharacterFromSpriteAsset_m0B6133849B1B4BDEF41D1DEADD26B8EB6174DD09 (void);
// 0x00000080 UnityEngine.TextCore.Text.SpriteCharacter UnityEngine.TextCore.Text.FontAssetUtilities::GetSpriteCharacterFromSpriteAsset_Internal(System.UInt32,UnityEngine.TextCore.Text.SpriteAsset,System.Boolean)
extern void FontAssetUtilities_GetSpriteCharacterFromSpriteAsset_Internal_mD1A527D6C350A716AEA20E61BBE7D958C4960060 (void);
// 0x00000081 System.Collections.Generic.List`1<UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord> UnityEngine.TextCore.Text.FontFeatureTable::get_glyphPairAdjustmentRecords()
extern void FontFeatureTable_get_glyphPairAdjustmentRecords_mABE78F7C2EA171927CC33170617D72E6C976323E (void);
// 0x00000082 System.Void UnityEngine.TextCore.Text.FontFeatureTable::.ctor()
extern void FontFeatureTable__ctor_m5F00F284C63F1867F679A3250ABFC1393C27025C (void);
// 0x00000083 System.Void UnityEngine.TextCore.Text.FontFeatureTable::SortGlyphPairAdjustmentRecords()
extern void FontFeatureTable_SortGlyphPairAdjustmentRecords_m2F5E2ED405FCAEE946CE5CF81163DDCC1B02A905 (void);
// 0x00000084 System.Void UnityEngine.TextCore.Text.FontFeatureTable/<>c::.cctor()
extern void U3CU3Ec__cctor_m1B7CCD6084985489A1607E2A0038672BB2080482 (void);
// 0x00000085 System.Void UnityEngine.TextCore.Text.FontFeatureTable/<>c::.ctor()
extern void U3CU3Ec__ctor_m51815D1379A3BDB616D65C006DA7AB32406723F4 (void);
// 0x00000086 System.UInt32 UnityEngine.TextCore.Text.FontFeatureTable/<>c::<SortGlyphPairAdjustmentRecords>b__6_0(UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord)
extern void U3CU3Ec_U3CSortGlyphPairAdjustmentRecordsU3Eb__6_0_m4A2B8B22BA5C619432654E7A0F5DEDAE949E12BA (void);
// 0x00000087 System.UInt32 UnityEngine.TextCore.Text.FontFeatureTable/<>c::<SortGlyphPairAdjustmentRecords>b__6_1(UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord)
extern void U3CU3Ec_U3CSortGlyphPairAdjustmentRecordsU3Eb__6_1_m5BF29DF1AB0CBEC9E1D73F20A998CBEC05DC7572 (void);
// 0x00000088 System.String UnityEngine.TextCore.Text.Extents::ToString()
extern void Extents_ToString_m8A1F748127EE9CCCD6FFAF4CE1F38E37C07831AC (void);
// 0x00000089 System.Void UnityEngine.TextCore.Text.LinkInfo::SetLinkId(System.Char[],System.Int32,System.Int32)
extern void LinkInfo_SetLinkId_mB4145264190D5C857705261CB27F87C6E10C3F3F (void);
// 0x0000008A UnityEngine.Material UnityEngine.TextCore.Text.MaterialManager::GetFallbackMaterial(UnityEngine.Material,UnityEngine.Material)
extern void MaterialManager_GetFallbackMaterial_m7BB3FDBF4411623DBA57727F2C54A33DA7F22554 (void);
// 0x0000008B UnityEngine.Material UnityEngine.TextCore.Text.MaterialManager::GetFallbackMaterial(UnityEngine.TextCore.Text.FontAsset,UnityEngine.Material,System.Int32)
extern void MaterialManager_GetFallbackMaterial_mEABF84B8A8BC620A6CB6D830089FB6890389C8B6 (void);
// 0x0000008C System.Void UnityEngine.TextCore.Text.MaterialManager::.cctor()
extern void MaterialManager__cctor_m851601D11F644A7CB79FC4FA3B7D716EACB6CC39 (void);
// 0x0000008D System.Void UnityEngine.TextCore.Text.MaterialReference::.ctor(System.Int32,UnityEngine.TextCore.Text.FontAsset,UnityEngine.TextCore.Text.SpriteAsset,UnityEngine.Material,System.Single)
extern void MaterialReference__ctor_m044AAA2C1079EB25A5534A6E0FA2314F033DB15A (void);
// 0x0000008E System.Int32 UnityEngine.TextCore.Text.MaterialReference::AddMaterialReference(UnityEngine.Material,UnityEngine.TextCore.Text.FontAsset,UnityEngine.TextCore.Text.MaterialReference[]&,System.Collections.Generic.Dictionary`2<System.Int32,System.Int32>)
extern void MaterialReference_AddMaterialReference_m6C0963F5E7C06B0371F2B18FE177D55B6C4C1105 (void);
// 0x0000008F System.Int32 UnityEngine.TextCore.Text.MaterialReference::AddMaterialReference(UnityEngine.Material,UnityEngine.TextCore.Text.SpriteAsset,UnityEngine.TextCore.Text.MaterialReference[]&,System.Collections.Generic.Dictionary`2<System.Int32,System.Int32>)
extern void MaterialReference_AddMaterialReference_m04F13DFCB5D0C707877E45A48B6C47CE80FC99E7 (void);
// 0x00000090 UnityEngine.TextCore.Text.MaterialReferenceManager UnityEngine.TextCore.Text.MaterialReferenceManager::get_instance()
extern void MaterialReferenceManager_get_instance_m4AB9F74DE21C3A47D7592AD444FACD97A375BE91 (void);
// 0x00000091 System.Void UnityEngine.TextCore.Text.MaterialReferenceManager::AddFontAsset(UnityEngine.TextCore.Text.FontAsset)
extern void MaterialReferenceManager_AddFontAsset_m52CD48B3A314C766C40A0D5BAAA092FFD2F6A204 (void);
// 0x00000092 System.Void UnityEngine.TextCore.Text.MaterialReferenceManager::AddFontAssetInternal(UnityEngine.TextCore.Text.FontAsset)
extern void MaterialReferenceManager_AddFontAssetInternal_m6F5A4E5ED988BA6F482F015F051ACD19D7B0A005 (void);
// 0x00000093 System.Void UnityEngine.TextCore.Text.MaterialReferenceManager::AddSpriteAsset(System.Int32,UnityEngine.TextCore.Text.SpriteAsset)
extern void MaterialReferenceManager_AddSpriteAsset_mC871D76124B93F40E57F5E99BAAB51770E347F49 (void);
// 0x00000094 System.Void UnityEngine.TextCore.Text.MaterialReferenceManager::AddSpriteAssetInternal(System.Int32,UnityEngine.TextCore.Text.SpriteAsset)
extern void MaterialReferenceManager_AddSpriteAssetInternal_m788619DC6BAD5B77E9419ACBDECBCCFE1A6AC97C (void);
// 0x00000095 System.Void UnityEngine.TextCore.Text.MaterialReferenceManager::AddFontMaterial(System.Int32,UnityEngine.Material)
extern void MaterialReferenceManager_AddFontMaterial_mBE61E1B0E6CBB58695731DC975859E349CA99C8A (void);
// 0x00000096 System.Void UnityEngine.TextCore.Text.MaterialReferenceManager::AddFontMaterialInternal(System.Int32,UnityEngine.Material)
extern void MaterialReferenceManager_AddFontMaterialInternal_m732F46EF768A41B9519917F4FA1E746E056C745C (void);
// 0x00000097 System.Void UnityEngine.TextCore.Text.MaterialReferenceManager::AddColorGradientPreset(System.Int32,UnityEngine.TextCore.Text.TextColorGradient)
extern void MaterialReferenceManager_AddColorGradientPreset_m8D59A614318734899E9AAD9924EBF4A18F76777D (void);
// 0x00000098 System.Void UnityEngine.TextCore.Text.MaterialReferenceManager::AddColorGradientPreset_Internal(System.Int32,UnityEngine.TextCore.Text.TextColorGradient)
extern void MaterialReferenceManager_AddColorGradientPreset_Internal_mF27270501EB3725B4CBE4C241B4A2FCD8D871BF1 (void);
// 0x00000099 System.Boolean UnityEngine.TextCore.Text.MaterialReferenceManager::TryGetFontAsset(System.Int32,UnityEngine.TextCore.Text.FontAsset&)
extern void MaterialReferenceManager_TryGetFontAsset_m81063D8799AF27566284930B3D3656A3022A1113 (void);
// 0x0000009A System.Boolean UnityEngine.TextCore.Text.MaterialReferenceManager::TryGetFontAssetInternal(System.Int32,UnityEngine.TextCore.Text.FontAsset&)
extern void MaterialReferenceManager_TryGetFontAssetInternal_m2FECC618624B12D200EB311F59CBEECA7CDBB69D (void);
// 0x0000009B System.Boolean UnityEngine.TextCore.Text.MaterialReferenceManager::TryGetSpriteAsset(System.Int32,UnityEngine.TextCore.Text.SpriteAsset&)
extern void MaterialReferenceManager_TryGetSpriteAsset_m848DD587C2EB15DF11C64095BAD6E34FE7CA8E3A (void);
// 0x0000009C System.Boolean UnityEngine.TextCore.Text.MaterialReferenceManager::TryGetSpriteAssetInternal(System.Int32,UnityEngine.TextCore.Text.SpriteAsset&)
extern void MaterialReferenceManager_TryGetSpriteAssetInternal_mC434A7C6DB005EDBBA52154E2AB0E36ED7083C84 (void);
// 0x0000009D System.Boolean UnityEngine.TextCore.Text.MaterialReferenceManager::TryGetColorGradientPreset(System.Int32,UnityEngine.TextCore.Text.TextColorGradient&)
extern void MaterialReferenceManager_TryGetColorGradientPreset_m379362C98A5E71979208D750F9699E6F7E3D5C44 (void);
// 0x0000009E System.Boolean UnityEngine.TextCore.Text.MaterialReferenceManager::TryGetColorGradientPresetInternal(System.Int32,UnityEngine.TextCore.Text.TextColorGradient&)
extern void MaterialReferenceManager_TryGetColorGradientPresetInternal_mD8018B3225786E71F804D629F3107AB75EE5212B (void);
// 0x0000009F System.Boolean UnityEngine.TextCore.Text.MaterialReferenceManager::TryGetMaterial(System.Int32,UnityEngine.Material&)
extern void MaterialReferenceManager_TryGetMaterial_m54A7E79A8D506AB95FED10236597C60C9F4CC8C1 (void);
// 0x000000A0 System.Boolean UnityEngine.TextCore.Text.MaterialReferenceManager::TryGetMaterialInternal(System.Int32,UnityEngine.Material&)
extern void MaterialReferenceManager_TryGetMaterialInternal_mEBFC9CE0A6063B25FEA9070F22FD8AD27107ECE7 (void);
// 0x000000A1 System.Void UnityEngine.TextCore.Text.MaterialReferenceManager::.ctor()
extern void MaterialReferenceManager__ctor_mC102EC445A27BE8E3968ADB80EF8FEF3BCFB7778 (void);
// 0x000000A2 System.Void UnityEngine.TextCore.Text.MeshInfo::.ctor(System.Int32)
extern void MeshInfo__ctor_mCC2410C5590BEA974468F4CECFA874BE966CDE61 (void);
// 0x000000A3 System.Void UnityEngine.TextCore.Text.MeshInfo::ResizeMeshInfo(System.Int32)
extern void MeshInfo_ResizeMeshInfo_mE411FE40935FB9CFB7C334B3A1F216A98B96F5FC (void);
// 0x000000A4 System.Void UnityEngine.TextCore.Text.MeshInfo::Clear(System.Boolean)
extern void MeshInfo_Clear_m06992FEB7AC9B2AE1728BEDFC8D8A39DE1AAD475 (void);
// 0x000000A5 System.Void UnityEngine.TextCore.Text.MeshInfo::ClearUnusedVertices()
extern void MeshInfo_ClearUnusedVertices_m7B6003EF4CA72C0ABBA4D25DEA8B0BF3934B2830 (void);
// 0x000000A6 System.Void UnityEngine.TextCore.Text.MeshInfo::SortGeometry(UnityEngine.TextCore.Text.VertexSortingOrder)
extern void MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1 (void);
// 0x000000A7 System.Void UnityEngine.TextCore.Text.MeshInfo::SwapVertexData(System.Int32,System.Int32)
extern void MeshInfo_SwapVertexData_mD145A4C2B45422DFCB2D9697956E16395E717C7F (void);
// 0x000000A8 System.Void UnityEngine.TextCore.Text.MeshInfo::.cctor()
extern void MeshInfo__cctor_mFFE09A28F0CFD120A1F4B3539FDC79122B1ACC48 (void);
// 0x000000A9 UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.Text.SpriteAsset::get_faceInfo()
extern void SpriteAsset_get_faceInfo_m54EC5227F682ED6A24F5633283258E6641CDA4DC (void);
// 0x000000AA System.Void UnityEngine.TextCore.Text.SpriteAsset::set_faceInfo(UnityEngine.TextCore.FaceInfo)
extern void SpriteAsset_set_faceInfo_m060A5DBBD5941A53BFE9D45E2B637D88ED8223EA (void);
// 0x000000AB UnityEngine.Texture UnityEngine.TextCore.Text.SpriteAsset::get_spriteSheet()
extern void SpriteAsset_get_spriteSheet_mC53205114A12A79F7495FA5F5EFC9948F151256B (void);
// 0x000000AC System.Void UnityEngine.TextCore.Text.SpriteAsset::set_spriteSheet(UnityEngine.Texture)
extern void SpriteAsset_set_spriteSheet_m1DE591615ABCBB4B10118BF4C0E1B57F559C6469 (void);
// 0x000000AD System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteCharacter> UnityEngine.TextCore.Text.SpriteAsset::get_spriteCharacterTable()
extern void SpriteAsset_get_spriteCharacterTable_m8D0D65C430AD8BC8C2BC8151DC4672CC0F690E0A (void);
// 0x000000AE System.Void UnityEngine.TextCore.Text.SpriteAsset::set_spriteCharacterTable(System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteCharacter>)
extern void SpriteAsset_set_spriteCharacterTable_m38553B81E01B502CCD568A654E9EF3B0D0BCA92D (void);
// 0x000000AF System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.SpriteCharacter> UnityEngine.TextCore.Text.SpriteAsset::get_spriteCharacterLookupTable()
extern void SpriteAsset_get_spriteCharacterLookupTable_mDB0BA7D703F58A05BB765AE44D6244D98C17DE03 (void);
// 0x000000B0 System.Void UnityEngine.TextCore.Text.SpriteAsset::set_spriteCharacterLookupTable(System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.SpriteCharacter>)
extern void SpriteAsset_set_spriteCharacterLookupTable_m38F3E7A0A52B82595C87E6A630B156E4D22F2E25 (void);
// 0x000000B1 System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteGlyph> UnityEngine.TextCore.Text.SpriteAsset::get_spriteGlyphTable()
extern void SpriteAsset_get_spriteGlyphTable_m491B3F4A5350C38D8B5166A60B7C43ED3608C0BA (void);
// 0x000000B2 System.Void UnityEngine.TextCore.Text.SpriteAsset::set_spriteGlyphTable(System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteGlyph>)
extern void SpriteAsset_set_spriteGlyphTable_m7402B7CF195E4B9F15DDA3273F49CA460A68DAD3 (void);
// 0x000000B3 System.Void UnityEngine.TextCore.Text.SpriteAsset::Awake()
extern void SpriteAsset_Awake_m3A012935612A7EB924A77B85EDCF6C09257F60BE (void);
// 0x000000B4 System.Void UnityEngine.TextCore.Text.SpriteAsset::UpdateLookupTables()
extern void SpriteAsset_UpdateLookupTables_mCC7A470A65A72908C9CDBDDFD17A056188A5C7CE (void);
// 0x000000B5 System.Int32 UnityEngine.TextCore.Text.SpriteAsset::GetSpriteIndexFromHashcode(System.Int32)
extern void SpriteAsset_GetSpriteIndexFromHashcode_mE73615D1D9A8BB45C3426197EC54B1A002642DE0 (void);
// 0x000000B6 System.Int32 UnityEngine.TextCore.Text.SpriteAsset::GetSpriteIndexFromUnicode(System.UInt32)
extern void SpriteAsset_GetSpriteIndexFromUnicode_m321E02B6000E5F6673F5724155C3EF1DE3F5A66B (void);
// 0x000000B7 System.Int32 UnityEngine.TextCore.Text.SpriteAsset::GetSpriteIndexFromName(System.String)
extern void SpriteAsset_GetSpriteIndexFromName_mBCB684ED6E3DF5663A7FDA02CA69C99D9B17281B (void);
// 0x000000B8 UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.SpriteAsset::SearchForSpriteByUnicode(UnityEngine.TextCore.Text.SpriteAsset,System.UInt32,System.Boolean,System.Int32&)
extern void SpriteAsset_SearchForSpriteByUnicode_mA7D1BEA72B7BB631ADD94B3391C968EE2F94C744 (void);
// 0x000000B9 UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.SpriteAsset::SearchForSpriteByUnicodeInternal(System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteAsset>,System.UInt32,System.Boolean,System.Int32&)
extern void SpriteAsset_SearchForSpriteByUnicodeInternal_m9ACF49A920E0594B3E9387AE48BB84490FA14EBE (void);
// 0x000000BA UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.SpriteAsset::SearchForSpriteByUnicodeInternal(UnityEngine.TextCore.Text.SpriteAsset,System.UInt32,System.Boolean,System.Int32&)
extern void SpriteAsset_SearchForSpriteByUnicodeInternal_m19491D77C3D6F01BB25A85C9B0D96380977CE814 (void);
// 0x000000BB UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.SpriteAsset::SearchForSpriteByHashCode(UnityEngine.TextCore.Text.SpriteAsset,System.Int32,System.Boolean,System.Int32&,UnityEngine.TextCore.Text.TextSettings)
extern void SpriteAsset_SearchForSpriteByHashCode_mE89EE4F71AA7F78A18D9C4BABBF8BD393E2A5035 (void);
// 0x000000BC UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.SpriteAsset::SearchForSpriteByHashCodeInternal(System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteAsset>,System.Int32,System.Boolean,System.Int32&)
extern void SpriteAsset_SearchForSpriteByHashCodeInternal_mC1583A1E630DFC7C4B7424B8A618E68E85738A9C (void);
// 0x000000BD UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.SpriteAsset::SearchForSpriteByHashCodeInternal(UnityEngine.TextCore.Text.SpriteAsset,System.Int32,System.Boolean,System.Int32&)
extern void SpriteAsset_SearchForSpriteByHashCodeInternal_m13FE1B5D13A07618190680252FD3354F6047DB9A (void);
// 0x000000BE System.Void UnityEngine.TextCore.Text.SpriteAsset::SortGlyphTable()
extern void SpriteAsset_SortGlyphTable_mA700CE5246D5798FA65779BE53179FFF4FFED6E5 (void);
// 0x000000BF System.Void UnityEngine.TextCore.Text.SpriteAsset::SortCharacterTable()
extern void SpriteAsset_SortCharacterTable_m5447649977AF2C9F62A14415B44CDDD897A53AE1 (void);
// 0x000000C0 System.Void UnityEngine.TextCore.Text.SpriteAsset::SortGlyphAndCharacterTables()
extern void SpriteAsset_SortGlyphAndCharacterTables_m0E2B691E7C1F284E12A88B47B705307E83C7D927 (void);
// 0x000000C1 System.Void UnityEngine.TextCore.Text.SpriteAsset::.ctor()
extern void SpriteAsset__ctor_mE03F69799389DE8D90E69CD70054955033C4ED3C (void);
// 0x000000C2 System.Void UnityEngine.TextCore.Text.SpriteAsset/<>c::.cctor()
extern void U3CU3Ec__cctor_m8B8A7374E1675126A3FD5136CDF2731C98F62741 (void);
// 0x000000C3 System.Void UnityEngine.TextCore.Text.SpriteAsset/<>c::.ctor()
extern void U3CU3Ec__ctor_mEFC122BF1D0D0CA8F0EAE9CE353C37A8CFABB5F3 (void);
// 0x000000C4 System.UInt32 UnityEngine.TextCore.Text.SpriteAsset/<>c::<SortGlyphTable>b__37_0(UnityEngine.TextCore.Text.SpriteGlyph)
extern void U3CU3Ec_U3CSortGlyphTableU3Eb__37_0_mC479CF63F85C34FC407D92E67878B9B2AD99B739 (void);
// 0x000000C5 System.UInt32 UnityEngine.TextCore.Text.SpriteAsset/<>c::<SortCharacterTable>b__38_0(UnityEngine.TextCore.Text.SpriteCharacter)
extern void U3CU3Ec_U3CSortCharacterTableU3Eb__38_0_m6A3F26D4286DF4F04DC23D23D04E12CA014D6E92 (void);
// 0x000000C6 System.String UnityEngine.TextCore.Text.SpriteCharacter::get_name()
extern void SpriteCharacter_get_name_mD5A9CC908308BB48D459973C8844FE1FD7C925B1 (void);
// 0x000000C7 System.Void UnityEngine.TextCore.Text.SpriteCharacter::.ctor()
extern void SpriteCharacter__ctor_m0B3812DF9A667CA2C3AA321DF3403197EEBC83BA (void);
// 0x000000C8 System.Void UnityEngine.TextCore.Text.SpriteGlyph::.ctor()
extern void SpriteGlyph__ctor_mFFE2D9AA5A28EA0C20C10694569A1E23A664BB4D (void);
// 0x000000C9 System.String UnityEngine.TextCore.Text.TextAsset::get_version()
extern void TextAsset_get_version_m2316C9F212FE4A13335032354A496CAEC86CB25B (void);
// 0x000000CA System.Void UnityEngine.TextCore.Text.TextAsset::set_version(System.String)
extern void TextAsset_set_version_m24718A4A6A86F4CE41D9ED1E0F796CCF367516CD (void);
// 0x000000CB System.Int32 UnityEngine.TextCore.Text.TextAsset::get_instanceID()
extern void TextAsset_get_instanceID_m843A6CAA7FE9322CD19546671D3F0E90A0E27AFB (void);
// 0x000000CC System.Int32 UnityEngine.TextCore.Text.TextAsset::get_hashCode()
extern void TextAsset_get_hashCode_m4D519E837097D8869A8D38EBD11611FADE411092 (void);
// 0x000000CD System.Void UnityEngine.TextCore.Text.TextAsset::set_hashCode(System.Int32)
extern void TextAsset_set_hashCode_mC6ED3271A5EFC05562FD1083BE1C872CB69CFF74 (void);
// 0x000000CE UnityEngine.Material UnityEngine.TextCore.Text.TextAsset::get_material()
extern void TextAsset_get_material_m4B9C02D34426436FDB01F1963A9FDC11D75604EF (void);
// 0x000000CF System.Void UnityEngine.TextCore.Text.TextAsset::set_material(UnityEngine.Material)
extern void TextAsset_set_material_mD9988165763E0E72C7FB7537760899EC1841C829 (void);
// 0x000000D0 System.Int32 UnityEngine.TextCore.Text.TextAsset::get_materialHashCode()
extern void TextAsset_get_materialHashCode_m9BAA469D5760D87EEC6E09B9ED3C5902B75017E6 (void);
// 0x000000D1 System.Void UnityEngine.TextCore.Text.TextAsset::set_materialHashCode(System.Int32)
extern void TextAsset_set_materialHashCode_m15EE7CCAF81DBAA326049F00788BCC918FDB2631 (void);
// 0x000000D2 System.Void UnityEngine.TextCore.Text.TextAsset::.ctor()
extern void TextAsset__ctor_m2C43EAC2D75854E6724A235794DEAF8A1AF9E786 (void);
// 0x000000D3 System.Void UnityEngine.TextCore.Text.TextColorGradient::.ctor()
extern void TextColorGradient__ctor_mAF03C3B68C29D94ED1F1517E65477CFC2B078FAC (void);
// 0x000000D4 System.Void UnityEngine.TextCore.Text.TextColorGradient::.ctor(UnityEngine.Color)
extern void TextColorGradient__ctor_m0712D0C09E7BCBC00909CEB71B43F2276ADB8B55 (void);
// 0x000000D5 System.Void UnityEngine.TextCore.Text.TextColorGradient::.ctor(UnityEngine.Color,UnityEngine.Color,UnityEngine.Color,UnityEngine.Color)
extern void TextColorGradient__ctor_m0A6B9264A8FBABEEC5BA84353D9B3DD7999DD2FF (void);
// 0x000000D6 System.Void UnityEngine.TextCore.Text.TextColorGradient::.cctor()
extern void TextColorGradient__cctor_m0C9B1A60EE8153D1DA39DC78EAF62F53C0202C86 (void);
// 0x000000D7 UnityEngine.TextCore.Text.TextElementType UnityEngine.TextCore.Text.TextElement::get_elementType()
extern void TextElement_get_elementType_m7BF97842479112227C1C3C83E0E94A176CD7D31A (void);
// 0x000000D8 System.UInt32 UnityEngine.TextCore.Text.TextElement::get_unicode()
extern void TextElement_get_unicode_m40C69806537940F7BA1D3969713DA10CCBE57BC7 (void);
// 0x000000D9 System.Void UnityEngine.TextCore.Text.TextElement::set_unicode(System.UInt32)
extern void TextElement_set_unicode_m99608D824B25E3529236C06BCC0983B5FC094F98 (void);
// 0x000000DA UnityEngine.TextCore.Text.TextAsset UnityEngine.TextCore.Text.TextElement::get_textAsset()
extern void TextElement_get_textAsset_m52383A3758AABF5BEA013155765BD1141479685A (void);
// 0x000000DB System.Void UnityEngine.TextCore.Text.TextElement::set_textAsset(UnityEngine.TextCore.Text.TextAsset)
extern void TextElement_set_textAsset_m3F65429660C011F6F25B65D6BA7C4B2CF05659FA (void);
// 0x000000DC UnityEngine.TextCore.Glyph UnityEngine.TextCore.Text.TextElement::get_glyph()
extern void TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2 (void);
// 0x000000DD System.Void UnityEngine.TextCore.Text.TextElement::set_glyph(UnityEngine.TextCore.Glyph)
extern void TextElement_set_glyph_m6E8E2F1366089FA638680F1CF53F6F5027D022A5 (void);
// 0x000000DE System.UInt32 UnityEngine.TextCore.Text.TextElement::get_glyphIndex()
extern void TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56 (void);
// 0x000000DF System.Void UnityEngine.TextCore.Text.TextElement::set_glyphIndex(System.UInt32)
extern void TextElement_set_glyphIndex_mFD72B93816998BE291DA6379EAF5E4153BC64F6C (void);
// 0x000000E0 System.Single UnityEngine.TextCore.Text.TextElement::get_scale()
extern void TextElement_get_scale_mD16946900449FEE9E2F86B2C4C71E26F4491A0E6 (void);
// 0x000000E1 System.Void UnityEngine.TextCore.Text.TextElement::set_scale(System.Single)
extern void TextElement_set_scale_m83FC0850B2B0F31BDFC779954923F50FD06DC03F (void);
// 0x000000E2 System.Void UnityEngine.TextCore.Text.TextElement::.ctor()
extern void TextElement__ctor_m8CB701D9A4C0444E834F178D97E9FC63E6D7E0B9 (void);
// 0x000000E3 System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::Equals(UnityEngine.TextCore.Text.TextGenerationSettings)
extern void TextGenerationSettings_Equals_mA5EDDF0453F2A7314AF5E1FE29F4138CD97E52D5 (void);
// 0x000000E4 System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::Equals(System.Object)
extern void TextGenerationSettings_Equals_mDCEEB056B70FC65ED6065E3BFE8D69D823DFEFD0 (void);
// 0x000000E5 System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::GetHashCode()
extern void TextGenerationSettings_GetHashCode_m1F750434FCE1853C36A579827B064619E85453E0 (void);
// 0x000000E6 System.Void UnityEngine.TextCore.Text.TextGenerationSettings::.ctor()
extern void TextGenerationSettings__ctor_mA20608A16443434DAE9FEF0BF8BD076270FA660E (void);
// 0x000000E7 UnityEngine.TextCore.Text.TextGenerator UnityEngine.TextCore.Text.TextGenerator::GetTextGenerator()
extern void TextGenerator_GetTextGenerator_mE998D0B33A1DE99A0DE3436AE0FA47B997E21781 (void);
// 0x000000E8 System.Void UnityEngine.TextCore.Text.TextGenerator::GenerateText(UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_GenerateText_mCF9D4EB0CC6D0BEA0136B23FCEE39EA9A48D6B5F (void);
// 0x000000E9 UnityEngine.Vector2 UnityEngine.TextCore.Text.TextGenerator::GetCursorPosition(UnityEngine.TextCore.Text.TextInfo,UnityEngine.Rect,System.Int32,System.Boolean)
extern void TextGenerator_GetCursorPosition_mE6F486439659265C1B4ACF04B9DAA0452CAABE41 (void);
// 0x000000EA UnityEngine.Vector2 UnityEngine.TextCore.Text.TextGenerator::GetPreferredValues(UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_GetPreferredValues_m00CB10940AD7561839EBA19B67E32B92B19F1CB6 (void);
// 0x000000EB System.Void UnityEngine.TextCore.Text.TextGenerator::Prepare(UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_Prepare_mD0A24977334138340CA73FB9787627373C6AA255 (void);
// 0x000000EC System.Void UnityEngine.TextCore.Text.TextGenerator::GenerateTextMesh(UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831 (void);
// 0x000000ED System.Void UnityEngine.TextCore.Text.TextGenerator::SaveWordWrappingState(UnityEngine.TextCore.Text.WordWrapState&,System.Int32,System.Int32,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936 (void);
// 0x000000EE System.Int32 UnityEngine.TextCore.Text.TextGenerator::RestoreWordWrappingState(UnityEngine.TextCore.Text.WordWrapState&,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61 (void);
// 0x000000EF System.Boolean UnityEngine.TextCore.Text.TextGenerator::ValidateHtmlTag(System.Int32[],System.Int32,System.Int32&,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_ValidateHtmlTag_m9C85462F15A6165B10E4C4EE93620AC1021BE5CD (void);
// 0x000000F0 System.Void UnityEngine.TextCore.Text.TextGenerator::SaveGlyphVertexInfo(System.Single,System.Single,UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_SaveGlyphVertexInfo_m0CD6E1D45488FFC6675294AC64F40AC23C986A09 (void);
// 0x000000F1 System.Void UnityEngine.TextCore.Text.TextGenerator::SaveSpriteVertexInfo(UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_SaveSpriteVertexInfo_m4B47901F01927E7CC4E486A1C4354AFBF4D138A5 (void);
// 0x000000F2 System.Void UnityEngine.TextCore.Text.TextGenerator::DrawUnderlineMesh(UnityEngine.Vector3,UnityEngine.Vector3,System.Int32&,System.Single,System.Single,System.Single,System.Single,UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E (void);
// 0x000000F3 System.Void UnityEngine.TextCore.Text.TextGenerator::DrawTextHighlight(UnityEngine.Vector3,UnityEngine.Vector3,System.Int32&,UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B (void);
// 0x000000F4 System.Void UnityEngine.TextCore.Text.TextGenerator::ClearMesh(System.Boolean,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_ClearMesh_mE8A81193AF7ACE3CFE55E0C18FCCD751503A997F (void);
// 0x000000F5 System.Void UnityEngine.TextCore.Text.TextGenerator::EnableMasking()
extern void TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991 (void);
// 0x000000F6 System.Void UnityEngine.TextCore.Text.TextGenerator::DisableMasking()
extern void TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950 (void);
// 0x000000F7 System.Void UnityEngine.TextCore.Text.TextGenerator::SetArraySizes(System.Int32[],UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_SetArraySizes_mF0041F3D79936C05EB87DEE399F1DC389CCD1BD5 (void);
// 0x000000F8 UnityEngine.TextCore.Text.TextElement UnityEngine.TextCore.Text.TextGenerator::GetTextElement(UnityEngine.TextCore.Text.TextGenerationSettings,System.UInt32,UnityEngine.TextCore.Text.FontAsset,UnityEngine.TextCore.Text.FontStyles,UnityEngine.TextCore.Text.TextFontWeight,System.Boolean&)
extern void TextGenerator_GetTextElement_mC46F0E788A0F6EB5A62601BCE4F383C3143C78CB (void);
// 0x000000F9 System.Void UnityEngine.TextCore.Text.TextGenerator::ComputeMarginSize(UnityEngine.Rect,UnityEngine.Vector4)
extern void TextGenerator_ComputeMarginSize_m485F8B01196058B15F597DE99D6F6A47FA539D3F (void);
// 0x000000FA System.Void UnityEngine.TextCore.Text.TextGenerator::GetSpecialCharacters(UnityEngine.TextCore.Text.TextGenerationSettings)
extern void TextGenerator_GetSpecialCharacters_mA82879FA537C58223BB660E797AC135A8E07B492 (void);
// 0x000000FB System.Void UnityEngine.TextCore.Text.TextGenerator::GetEllipsisSpecialCharacter(UnityEngine.TextCore.Text.TextGenerationSettings)
extern void TextGenerator_GetEllipsisSpecialCharacter_m5139CAE03CD2E25C9A528A6A6FC984A8515C2460 (void);
// 0x000000FC System.Void UnityEngine.TextCore.Text.TextGenerator::GetUnderlineSpecialCharacter(UnityEngine.TextCore.Text.TextGenerationSettings)
extern void TextGenerator_GetUnderlineSpecialCharacter_mE5E9D5DEB9A7758333CDDCAD05EF25F076EC1AD5 (void);
// 0x000000FD System.Single UnityEngine.TextCore.Text.TextGenerator::GetPaddingForMaterial(UnityEngine.Material,System.Boolean)
extern void TextGenerator_GetPaddingForMaterial_mE5A4DEF3F64851861C092F7A4FC58C902F775C74 (void);
// 0x000000FE UnityEngine.Vector2 UnityEngine.TextCore.Text.TextGenerator::GetPreferredValuesInternal(UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_GetPreferredValuesInternal_m125B070164DFEA503C67525D1F418DAF41300ABD (void);
// 0x000000FF UnityEngine.Vector2 UnityEngine.TextCore.Text.TextGenerator::CalculatePreferredValues(System.Single,UnityEngine.Vector2,System.Boolean,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGenerator_CalculatePreferredValues_mBBE23FA780CF24415963F32F7C500F0394C2545E (void);
// 0x00000100 System.Void UnityEngine.TextCore.Text.TextGenerator::.ctor()
extern void TextGenerator__ctor_m52E4D01DC28BDF753BF52F6501E7FD2FB2B30D90 (void);
// 0x00000101 System.Void UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter::.ctor(UnityEngine.TextCore.Text.Character,System.Int32)
extern void SpecialCharacter__ctor_m6697A8BF272F0144733EE12368C038F45E99F969 (void);
// 0x00000102 System.Boolean UnityEngine.TextCore.Text.TextGeneratorUtilities::Approximately(System.Single,System.Single)
extern void TextGeneratorUtilities_Approximately_m2333A8491C1BBC4F26738A240A7AA9E699508E6D (void);
// 0x00000103 UnityEngine.Color32 UnityEngine.TextCore.Text.TextGeneratorUtilities::HexCharsToColor(System.Char[],System.Int32)
extern void TextGeneratorUtilities_HexCharsToColor_mB7D42327546D443ADF83696B99E2CFD921FEE21F (void);
// 0x00000104 UnityEngine.Color32 UnityEngine.TextCore.Text.TextGeneratorUtilities::HexCharsToColor(System.Char[],System.Int32,System.Int32)
extern void TextGeneratorUtilities_HexCharsToColor_m0FC6E21EF35547ADFEA41B876C6FC1CD37C71019 (void);
// 0x00000105 System.Int32 UnityEngine.TextCore.Text.TextGeneratorUtilities::HexToInt(System.Char)
extern void TextGeneratorUtilities_HexToInt_mE6FAC19C36EDFE1E5AE08F14483B1D1BB773C61C (void);
// 0x00000106 System.Single UnityEngine.TextCore.Text.TextGeneratorUtilities::ConvertToFloat(System.Char[],System.Int32,System.Int32)
extern void TextGeneratorUtilities_ConvertToFloat_m5D83113DC84E90EC14F041B5870C73D2AE688978 (void);
// 0x00000107 System.Single UnityEngine.TextCore.Text.TextGeneratorUtilities::ConvertToFloat(System.Char[],System.Int32,System.Int32,System.Int32&)
extern void TextGeneratorUtilities_ConvertToFloat_mB4E9E5A7211E9B01EF9482A90AC073886FEB00A5 (void);
// 0x00000108 UnityEngine.Vector2 UnityEngine.TextCore.Text.TextGeneratorUtilities::PackUV(System.Single,System.Single,System.Single)
extern void TextGeneratorUtilities_PackUV_mFEB61C8552EE615440A86C18582F5A8117082259 (void);
// 0x00000109 System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::StringToCharArray(System.String,System.Int32[]&,UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>&,UnityEngine.TextCore.Text.TextGenerationSettings)
extern void TextGeneratorUtilities_StringToCharArray_m8268FA89F86210B39C56D1ED4C0FEBB27DA2713B (void);
// 0x0000010A System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::ResizeInternalArray(T[]&)
// 0x0000010B System.Boolean UnityEngine.TextCore.Text.TextGeneratorUtilities::IsTagName(System.String&,System.String,System.Int32)
extern void TextGeneratorUtilities_IsTagName_m8C1935BCF2324F0D59287C5BBAC0CB2980D773F4 (void);
// 0x0000010C System.Boolean UnityEngine.TextCore.Text.TextGeneratorUtilities::IsTagName(System.Int32[]&,System.String,System.Int32)
extern void TextGeneratorUtilities_IsTagName_m96D644793638F2469B031FCBFDBE3793BDCA5689 (void);
// 0x0000010D System.Boolean UnityEngine.TextCore.Text.TextGeneratorUtilities::ReplaceOpeningStyleTag(System.Int32[]&,System.Int32,System.Int32&,System.Int32[]&,System.Int32&,UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>&,UnityEngine.TextCore.Text.TextGenerationSettings&)
extern void TextGeneratorUtilities_ReplaceOpeningStyleTag_mCE630D2A5A1B3FCF640A2B8E02668C3AB63E0767 (void);
// 0x0000010E System.Boolean UnityEngine.TextCore.Text.TextGeneratorUtilities::ReplaceOpeningStyleTag(System.String&,System.Int32,System.Int32&,System.Int32[]&,System.Int32&,UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>&,UnityEngine.TextCore.Text.TextGenerationSettings&)
extern void TextGeneratorUtilities_ReplaceOpeningStyleTag_mCC7B70BC030D71272C3921A6FA25FF9A5E16B8CA (void);
// 0x0000010F System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::ReplaceClosingStyleTag(System.Int32[]&,System.Int32&,UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>&,UnityEngine.TextCore.Text.TextGenerationSettings&)
extern void TextGeneratorUtilities_ReplaceClosingStyleTag_mC09AB95297B63C4DED7FAAEE45AFB191F0AE2311 (void);
// 0x00000110 UnityEngine.TextCore.Text.TextStyle UnityEngine.TextCore.Text.TextGeneratorUtilities::GetStyle(UnityEngine.TextCore.Text.TextGenerationSettings,System.Int32)
extern void TextGeneratorUtilities_GetStyle_m1050359E87C4619E7597CB2D793D41FDB96067E5 (void);
// 0x00000111 System.Int32 UnityEngine.TextCore.Text.TextGeneratorUtilities::GetUtf32(System.String,System.Int32)
extern void TextGeneratorUtilities_GetUtf32_mAA6CFF8B51E54A1852998106D92FB93F9371CEB7 (void);
// 0x00000112 System.Int32 UnityEngine.TextCore.Text.TextGeneratorUtilities::GetUtf16(System.String,System.Int32)
extern void TextGeneratorUtilities_GetUtf16_mD28A180C7A2199550EED77DB8E3C078B9233775F (void);
// 0x00000113 System.Int32 UnityEngine.TextCore.Text.TextGeneratorUtilities::GetTagHashCode(System.Int32[]&,System.Int32,System.Int32&)
extern void TextGeneratorUtilities_GetTagHashCode_m43B3AAC5D68F9F98E94A8976F450CA89887B6A42 (void);
// 0x00000114 System.Int32 UnityEngine.TextCore.Text.TextGeneratorUtilities::GetTagHashCode(System.String&,System.Int32,System.Int32&)
extern void TextGeneratorUtilities_GetTagHashCode_m93E064B76CC421C2FE5CEF751147BF05C9A06737 (void);
// 0x00000115 System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::FillCharacterVertexBuffers(System.Int32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGeneratorUtilities_FillCharacterVertexBuffers_m4DB26BF6316D0ED0518093F81E7703326B7BF4A7 (void);
// 0x00000116 System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::FillSpriteVertexBuffers(System.Int32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
extern void TextGeneratorUtilities_FillSpriteVertexBuffers_m0AA6B96B32824157B84B59AD6E6B77B5F0689FCF (void);
// 0x00000117 System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::AdjustLineOffset(System.Int32,System.Int32,System.Single,UnityEngine.TextCore.Text.TextInfo)
extern void TextGeneratorUtilities_AdjustLineOffset_m9B686B22546C23700D8611CBA140B5EEB0527229 (void);
// 0x00000118 System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::ResizeLineExtents(System.Int32,UnityEngine.TextCore.Text.TextInfo)
extern void TextGeneratorUtilities_ResizeLineExtents_m31C939F88EAEDD9CA7475304E55550A3FE98CD19 (void);
// 0x00000119 UnityEngine.TextCore.Text.FontStyles UnityEngine.TextCore.Text.TextGeneratorUtilities::LegacyStyleToNewStyle(UnityEngine.FontStyle)
extern void TextGeneratorUtilities_LegacyStyleToNewStyle_m28425B06C6AB2A84893AA950144B76A2D8C1669B (void);
// 0x0000011A UnityEngine.TextCore.Text.TextAlignment UnityEngine.TextCore.Text.TextGeneratorUtilities::LegacyAlignmentToNewAlignment(UnityEngine.TextAnchor)
extern void TextGeneratorUtilities_LegacyAlignmentToNewAlignment_mA4CAC934F661F28168F132CF2B77D3DF89DBB301 (void);
// 0x0000011B System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::.cctor()
extern void TextGeneratorUtilities__cctor_m4A9C9782E18EE8E0BB6783A65370482BBE97F46C (void);
// 0x0000011C System.Void UnityEngine.TextCore.Text.TextInfo::.ctor()
extern void TextInfo__ctor_m241E24715CC5F6293DC90A4D25884548BAD0D602 (void);
// 0x0000011D System.Void UnityEngine.TextCore.Text.TextInfo::Clear()
extern void TextInfo_Clear_m60412774208F9D920707448E71E89C99233D9128 (void);
// 0x0000011E System.Void UnityEngine.TextCore.Text.TextInfo::ClearMeshInfo(System.Boolean)
extern void TextInfo_ClearMeshInfo_mCA598F01C7F302CFCD0F508E2DBF072E66CA74F3 (void);
// 0x0000011F System.Void UnityEngine.TextCore.Text.TextInfo::ClearLineInfo()
extern void TextInfo_ClearLineInfo_m986C886D34A324C8C4D30F9D8EF24AC242A10AD7 (void);
// 0x00000120 System.Void UnityEngine.TextCore.Text.TextInfo::Resize(T[]&,System.Int32)
// 0x00000121 System.Void UnityEngine.TextCore.Text.TextInfo::Resize(T[]&,System.Int32,System.Boolean)
// 0x00000122 System.Void UnityEngine.TextCore.Text.TextInfo::.cctor()
extern void TextInfo__cctor_m2F1EF99C8719E2B8B98D008C4F259413E5C9DBB9 (void);
// 0x00000123 System.Void UnityEngine.TextCore.Text.FontStyleStack::Clear()
extern void FontStyleStack_Clear_m989659363648B27540168E46F23E1EF9877C06E0 (void);
// 0x00000124 System.Byte UnityEngine.TextCore.Text.FontStyleStack::Add(UnityEngine.TextCore.Text.FontStyles)
extern void FontStyleStack_Add_m26E701C9F052EEEBB213B9B8BC6CB8F1F8F6AFCB (void);
// 0x00000125 System.Byte UnityEngine.TextCore.Text.FontStyleStack::Remove(UnityEngine.TextCore.Text.FontStyles)
extern void FontStyleStack_Remove_mC2B4F44A6596E92D6992DBCA298648F8A7416CAB (void);
// 0x00000126 System.Void UnityEngine.TextCore.Text.TextProcessingStack`1::.ctor(T[])
// 0x00000127 System.Void UnityEngine.TextCore.Text.TextProcessingStack`1::.ctor(System.Int32)
// 0x00000128 System.Void UnityEngine.TextCore.Text.TextProcessingStack`1::Clear()
// 0x00000129 System.Void UnityEngine.TextCore.Text.TextProcessingStack`1::SetDefault(T)
// 0x0000012A System.Void UnityEngine.TextCore.Text.TextProcessingStack`1::Add(T)
// 0x0000012B T UnityEngine.TextCore.Text.TextProcessingStack`1::Remove()
// 0x0000012C System.Void UnityEngine.TextCore.Text.TextProcessingStack`1::Push(T)
// 0x0000012D T UnityEngine.TextCore.Text.TextProcessingStack`1::Pop()
// 0x0000012E T UnityEngine.TextCore.Text.TextProcessingStack`1::Peek()
// 0x0000012F T UnityEngine.TextCore.Text.TextProcessingStack`1::CurrentItem()
// 0x00000130 System.Void UnityEngine.TextCore.Text.TextResourceManager::AddFontAsset(UnityEngine.TextCore.Text.FontAsset)
extern void TextResourceManager_AddFontAsset_m593E23B8489420BAB880DBC5F8D12AC006E04662 (void);
// 0x00000131 System.Void UnityEngine.TextCore.Text.TextResourceManager::.cctor()
extern void TextResourceManager__cctor_m485811EE8DC7D867DFAFF02ACED0C667E8FDC366 (void);
// 0x00000132 System.Void UnityEngine.TextCore.Text.TextResourceManager/FontAssetRef::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.TextCore.Text.FontAsset)
extern void FontAssetRef__ctor_m5553FC4D7E51DE97D70CE09E1C99B002A61FFDB5 (void);
// 0x00000133 System.String UnityEngine.TextCore.Text.TextSettings::get_version()
extern void TextSettings_get_version_mB5B7C3F04FFC8DCDFCFF63CFFF7612B768E267CB (void);
// 0x00000134 System.Void UnityEngine.TextCore.Text.TextSettings::set_version(System.String)
extern void TextSettings_set_version_m7BEE644EEDD77892C295170F9B2B68BC45C7C6CF (void);
// 0x00000135 UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextSettings::get_defaultFontAsset()
extern void TextSettings_get_defaultFontAsset_mC6280464BFEE081DB23243BB94E49C72A0885A1F (void);
// 0x00000136 System.Void UnityEngine.TextCore.Text.TextSettings::set_defaultFontAsset(UnityEngine.TextCore.Text.FontAsset)
extern void TextSettings_set_defaultFontAsset_mC0137D9AEB9EE7A9E1B3D7C499414EDD217AF3BA (void);
// 0x00000137 System.String UnityEngine.TextCore.Text.TextSettings::get_defaultFontAssetPath()
extern void TextSettings_get_defaultFontAssetPath_mF7B1713753CFAE048C745C3572332CE18CD51D3B (void);
// 0x00000138 System.Void UnityEngine.TextCore.Text.TextSettings::set_defaultFontAssetPath(System.String)
extern void TextSettings_set_defaultFontAssetPath_m35111382F9C2E3C76FA6B77BABEE8149BDDCC7ED (void);
// 0x00000139 System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset> UnityEngine.TextCore.Text.TextSettings::get_fallbackFontAssets()
extern void TextSettings_get_fallbackFontAssets_m332526E834C994425141A58C968FD40320573F98 (void);
// 0x0000013A System.Void UnityEngine.TextCore.Text.TextSettings::set_fallbackFontAssets(System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset>)
extern void TextSettings_set_fallbackFontAssets_mEBEC769B2FF339BDB44D72CB48F0010577889772 (void);
// 0x0000013B System.Boolean UnityEngine.TextCore.Text.TextSettings::get_matchMaterialPreset()
extern void TextSettings_get_matchMaterialPreset_m4675979547AE4C83E680260EAE5ACBC4FAC53B87 (void);
// 0x0000013C System.Void UnityEngine.TextCore.Text.TextSettings::set_matchMaterialPreset(System.Boolean)
extern void TextSettings_set_matchMaterialPreset_mD5A3DDE2D93FE2872C869A2AE0B0C984CF5BC12C (void);
// 0x0000013D System.Int32 UnityEngine.TextCore.Text.TextSettings::get_missingCharacterUnicode()
extern void TextSettings_get_missingCharacterUnicode_mA707E5E6633633BBB3BAFB96B97A5A995100F3F3 (void);
// 0x0000013E System.Void UnityEngine.TextCore.Text.TextSettings::set_missingCharacterUnicode(System.Int32)
extern void TextSettings_set_missingCharacterUnicode_mE3E3E2F902BE89B9FE78F03D3B8C508583D1CDA3 (void);
// 0x0000013F System.Boolean UnityEngine.TextCore.Text.TextSettings::get_clearDynamicDataOnBuild()
extern void TextSettings_get_clearDynamicDataOnBuild_m0C130F53F106D77250F38239FB73DCB97299FB79 (void);
// 0x00000140 System.Void UnityEngine.TextCore.Text.TextSettings::set_clearDynamicDataOnBuild(System.Boolean)
extern void TextSettings_set_clearDynamicDataOnBuild_m86B73E68953D42C6AE4210BEA5D678768155A1AD (void);
// 0x00000141 UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextSettings::get_defaultSpriteAsset()
extern void TextSettings_get_defaultSpriteAsset_m8FA900F9747B7ADBCD2A2F612E7D977DB58D6445 (void);
// 0x00000142 System.Void UnityEngine.TextCore.Text.TextSettings::set_defaultSpriteAsset(UnityEngine.TextCore.Text.SpriteAsset)
extern void TextSettings_set_defaultSpriteAsset_m6083C46D0B3AFB6816363CF2564D2DB2D1ECFEB9 (void);
// 0x00000143 System.String UnityEngine.TextCore.Text.TextSettings::get_defaultSpriteAssetPath()
extern void TextSettings_get_defaultSpriteAssetPath_mF57875222B7FACC9B69369305EEEB53FFE7986E0 (void);
// 0x00000144 System.Void UnityEngine.TextCore.Text.TextSettings::set_defaultSpriteAssetPath(System.String)
extern void TextSettings_set_defaultSpriteAssetPath_m9C49C00A96230DAF828E629C106B229A4552F753 (void);
// 0x00000145 System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteAsset> UnityEngine.TextCore.Text.TextSettings::get_fallbackSpriteAssets()
extern void TextSettings_get_fallbackSpriteAssets_mC6D74088EBDFDFBACD581FE4AB4EAA447ED242AD (void);
// 0x00000146 System.Void UnityEngine.TextCore.Text.TextSettings::set_fallbackSpriteAssets(System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteAsset>)
extern void TextSettings_set_fallbackSpriteAssets_mB28744780B58AE04BA7F1275508FF7DEE4E485E5 (void);
// 0x00000147 System.UInt32 UnityEngine.TextCore.Text.TextSettings::get_missingSpriteCharacterUnicode()
extern void TextSettings_get_missingSpriteCharacterUnicode_m496D85B0D88C91F2A5CC9929C233EAA84831523E (void);
// 0x00000148 System.Void UnityEngine.TextCore.Text.TextSettings::set_missingSpriteCharacterUnicode(System.UInt32)
extern void TextSettings_set_missingSpriteCharacterUnicode_mFE1AFD04C4AA793559E0A157C9E5472E3C3F6701 (void);
// 0x00000149 UnityEngine.TextCore.Text.TextStyleSheet UnityEngine.TextCore.Text.TextSettings::get_defaultStyleSheet()
extern void TextSettings_get_defaultStyleSheet_mDA420960556C00405FA66CBD2DA36807F8F4B4F2 (void);
// 0x0000014A System.Void UnityEngine.TextCore.Text.TextSettings::set_defaultStyleSheet(UnityEngine.TextCore.Text.TextStyleSheet)
extern void TextSettings_set_defaultStyleSheet_m2867A0B047E623E4485F10EE717FF0B46BAAECEE (void);
// 0x0000014B System.String UnityEngine.TextCore.Text.TextSettings::get_styleSheetsResourcePath()
extern void TextSettings_get_styleSheetsResourcePath_mE65A055D1C99CA2048BE6F246258EF262E43C4E6 (void);
// 0x0000014C System.Void UnityEngine.TextCore.Text.TextSettings::set_styleSheetsResourcePath(System.String)
extern void TextSettings_set_styleSheetsResourcePath_m19A5C893047D78B43AC5EB43FB9EA79792464C05 (void);
// 0x0000014D System.String UnityEngine.TextCore.Text.TextSettings::get_defaultColorGradientPresetsPath()
extern void TextSettings_get_defaultColorGradientPresetsPath_m1571454580E1F0DC859D3F201BB1F6355A5DBB8E (void);
// 0x0000014E System.Void UnityEngine.TextCore.Text.TextSettings::set_defaultColorGradientPresetsPath(System.String)
extern void TextSettings_set_defaultColorGradientPresetsPath_m951D5A7AE71C87BFA5B9B8CE8EA2F78A474FE01D (void);
// 0x0000014F UnityEngine.TextCore.Text.UnicodeLineBreakingRules UnityEngine.TextCore.Text.TextSettings::get_lineBreakingRules()
extern void TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04 (void);
// 0x00000150 System.Void UnityEngine.TextCore.Text.TextSettings::set_lineBreakingRules(UnityEngine.TextCore.Text.UnicodeLineBreakingRules)
extern void TextSettings_set_lineBreakingRules_mB1174FE0F923443130A3D4686C119EDB0430992D (void);
// 0x00000151 System.Boolean UnityEngine.TextCore.Text.TextSettings::get_displayWarnings()
extern void TextSettings_get_displayWarnings_m3CA9FCB44B30CC06F54CD3716D68285FF844DF83 (void);
// 0x00000152 System.Void UnityEngine.TextCore.Text.TextSettings::set_displayWarnings(System.Boolean)
extern void TextSettings_set_displayWarnings_m08373EE3900E911B4021CBF8AF915DA69856CC20 (void);
// 0x00000153 System.Void UnityEngine.TextCore.Text.TextSettings::InitializeFontReferenceLookup()
extern void TextSettings_InitializeFontReferenceLookup_m34B5FB3D61296A7620196398D267812EEFCE0B04 (void);
// 0x00000154 UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextSettings::GetCachedFontAssetInternal(UnityEngine.Font)
extern void TextSettings_GetCachedFontAssetInternal_m9308E0DDEF8F6D8ACA17DAADB43745C860788202 (void);
// 0x00000155 System.Void UnityEngine.TextCore.Text.TextSettings::.ctor()
extern void TextSettings__ctor_m860D28B10258792A195E1C6391479E16D04CA8BF (void);
// 0x00000156 System.Void UnityEngine.TextCore.Text.TextSettings/FontReferenceMap::.ctor(UnityEngine.Font,UnityEngine.TextCore.Text.FontAsset)
extern void FontReferenceMap__ctor_mA94127060F9F3FDC3093D9356832503BFBCE44F5 (void);
// 0x00000157 UnityEngine.Shader UnityEngine.TextCore.Text.TextShaderUtilities::get_ShaderRef_MobileSDF()
extern void TextShaderUtilities_get_ShaderRef_MobileSDF_m07A195460277381844289DBB77C18BD8D625280D (void);
// 0x00000158 UnityEngine.Shader UnityEngine.TextCore.Text.TextShaderUtilities::get_ShaderRef_MobileBitmap()
extern void TextShaderUtilities_get_ShaderRef_MobileBitmap_m668C39791DB1388D169A99FBD01E30B0C90C13DC (void);
// 0x00000159 System.Void UnityEngine.TextCore.Text.TextShaderUtilities::.cctor()
extern void TextShaderUtilities__cctor_m307B99F084FCE6CE802EB507756CBAB9C2E43CD7 (void);
// 0x0000015A System.Void UnityEngine.TextCore.Text.TextShaderUtilities::GetShaderPropertyIDs()
extern void TextShaderUtilities_GetShaderPropertyIDs_mE049EE63FF1F02C91EA3B6FA0CB82FE2C6DA526E (void);
// 0x0000015B System.Void UnityEngine.TextCore.Text.TextShaderUtilities::UpdateShaderRatios(UnityEngine.Material)
extern void TextShaderUtilities_UpdateShaderRatios_m7ACDAE788233935CE733F66FFA6AE1995671A29A (void);
// 0x0000015C System.Boolean UnityEngine.TextCore.Text.TextShaderUtilities::IsMaskingEnabled(UnityEngine.Material)
extern void TextShaderUtilities_IsMaskingEnabled_m9B499B7017691BA2805367567166484812807E45 (void);
// 0x0000015D System.Single UnityEngine.TextCore.Text.TextShaderUtilities::GetPadding(UnityEngine.Material,System.Boolean,System.Boolean)
extern void TextShaderUtilities_GetPadding_m2745B16C068222A2DCFA6EAD1A497D66F0A17BFA (void);
// 0x0000015E System.Int32 UnityEngine.TextCore.Text.TextStyle::get_hashCode()
extern void TextStyle_get_hashCode_mA1F4D3630B6AE71C2A31F94B7054C28BDD96084F (void);
// 0x0000015F System.Int32[] UnityEngine.TextCore.Text.TextStyle::get_styleOpeningTagArray()
extern void TextStyle_get_styleOpeningTagArray_m32B909EFDDBCFFECC7D1F4D551DCB520A72240EA (void);
// 0x00000160 System.Int32[] UnityEngine.TextCore.Text.TextStyle::get_styleClosingTagArray()
extern void TextStyle_get_styleClosingTagArray_mB5F9A0BD01EF3E6ABFF44311ADF2A1511D838033 (void);
// 0x00000161 System.Void UnityEngine.TextCore.Text.TextStyle::RefreshStyle()
extern void TextStyle_RefreshStyle_m2D0771408F06C24EF303749ED8E656C800575BDB (void);
// 0x00000162 System.Collections.Generic.List`1<UnityEngine.TextCore.Text.TextStyle> UnityEngine.TextCore.Text.TextStyleSheet::get_styles()
extern void TextStyleSheet_get_styles_m7916C62D70AA430314D85EA5B5A778FFAE1544DB (void);
// 0x00000163 UnityEngine.TextCore.Text.TextStyle UnityEngine.TextCore.Text.TextStyleSheet::GetStyle(System.Int32)
extern void TextStyleSheet_GetStyle_m648B766D750E1B37DD126918BF7EB22DDFD21D29 (void);
// 0x00000164 UnityEngine.TextCore.Text.TextStyle UnityEngine.TextCore.Text.TextStyleSheet::GetStyle(System.String)
extern void TextStyleSheet_GetStyle_mF87D8108EEF60C3FC32A2B01D5C1C23D3F22A4D1 (void);
// 0x00000165 System.Void UnityEngine.TextCore.Text.TextStyleSheet::RefreshStyles()
extern void TextStyleSheet_RefreshStyles_m92525DE6F7951D03D906E18EC89349AA2794AEC5 (void);
// 0x00000166 System.Void UnityEngine.TextCore.Text.TextStyleSheet::LoadStyleDictionaryInternal()
extern void TextStyleSheet_LoadStyleDictionaryInternal_m482E4CDF0CD2ED291F85869E141EEB5EC21F6D81 (void);
// 0x00000167 System.Void UnityEngine.TextCore.Text.TextStyleSheet::.ctor()
extern void TextStyleSheet__ctor_m1A0B93B55B12CE15FFF1053443179BD010022B75 (void);
// 0x00000168 System.Char UnityEngine.TextCore.Text.TextUtilities::ToUpperFast(System.Char)
extern void TextUtilities_ToUpperFast_m1B4220B35AD2E271021CB352FF5321B922AB56B8 (void);
// 0x00000169 System.UInt32 UnityEngine.TextCore.Text.TextUtilities::ToUpperASCIIFast(System.UInt32)
extern void TextUtilities_ToUpperASCIIFast_mCA372CC9A0CF7A2B86CC2C3914CB7FA5D3441CFF (void);
// 0x0000016A System.Int32 UnityEngine.TextCore.Text.TextUtilities::GetHashCodeCaseInSensitive(System.String)
extern void TextUtilities_GetHashCodeCaseInSensitive_m4248854DDCB679D1C66D4B49050764D9839CE98E (void);
// 0x0000016B System.String UnityEngine.TextCore.Text.TextUtilities::UintToString(System.Collections.Generic.List`1<System.UInt32>)
extern void TextUtilities_UintToString_mBD2991FDADB67054E3EEC452E58316101026B8DD (void);
// 0x0000016C System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::get_leadingCharactersLookup()
extern void UnicodeLineBreakingRules_get_leadingCharactersLookup_m1DAC015D7E37112EAE0437E6472AEA0719DFF3DC (void);
// 0x0000016D System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::get_followingCharactersLookup()
extern void UnicodeLineBreakingRules_get_followingCharactersLookup_m5510A21873DC5DA66F4A2DFA4C26A5EFAD494D8B (void);
// 0x0000016E System.Void UnityEngine.TextCore.Text.UnicodeLineBreakingRules::LoadLineBreakingRules()
extern void UnicodeLineBreakingRules_LoadLineBreakingRules_m4686111E39B00E27AA6AD88762793EEFCCC14A75 (void);
// 0x0000016F System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::GetCharacters(UnityEngine.TextAsset)
extern void UnicodeLineBreakingRules_GetCharacters_m998BFBC4A98C3393D2C405CB2BC7A62717B04C40 (void);
// 0x00000170 System.Void UnityEngine.TextCore.Text.UnicodeLineBreakingRules::.ctor()
extern void UnicodeLineBreakingRules__ctor_mD94779B4996B56EA84C847EC4DD287AB1A8ADE85 (void);
// 0x00000171 System.Void UnityEngine.TextCore.Text.UnicodeLineBreakingRules::.cctor()
extern void UnicodeLineBreakingRules__cctor_m0335FB329027F3D00564801E12A0CB29854F05F4 (void);
static Il2CppMethodPointer s_methodPointers[369] = 
{
	Character__ctor_m5DCCE862D40487C733C29A233DB8513A9A6A02F6,
	Character__ctor_mEEAC42D4227E0053C8008C12B222CC208D781795,
	Character__ctor_m21FBFAF1F6324565246096EFFB81C3F9E15D43CC,
	ColorUtilities_CompareColors_m66829BD52BE7906CCEAC57DE94C4024AF372BD8D,
	ColorUtilities_MultiplyColors_m1C827E2736C56C30621318B1358ABC9BF5B59C68,
	FontAsset_get_sourceFontFile_m6B0E805BD1B7712F0B5135D157E96F3F40314830,
	FontAsset_set_sourceFontFile_m2E6D2AED5E5D2585A09E9BF830387DEB10A2F4E8,
	FontAsset_get_atlasPopulationMode_m5364C5A9E84969D8E4FF8436BD18A3F10BF90366,
	FontAsset_set_atlasPopulationMode_m1A9DD5C702ED0924B9C208F4CE5ADEACF9188268,
	FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9,
	FontAsset_set_faceInfo_mCCA87B67C4CA2C0A1F6D85FB1FAA09667996EDCD,
	FontAsset_get_familyNameHashCode_mF2DB211A5712A291B2D28FCDB7F7C29057770330,
	FontAsset_set_familyNameHashCode_mE1495199BCE7B771CC920E2DBB86A8AF1518CB55,
	FontAsset_get_styleNameHashCode_m3CD3D77F64DAEB31D8F69E4D7CC1AD0AC784ABF5,
	FontAsset_set_styleNameHashCode_mE1BE5B75DE1E9EA0F76569609E6C4FFDC57558BA,
	FontAsset_get_fontWeightTable_m8DADE0BCE53D53EEECE27025F7E94FDD4BF00099,
	FontAsset_set_fontWeightTable_m39D8B63BD3FCC773AAB5634C6D9314C713161814,
	FontAsset_get_glyphTable_m212E940F74AEE62ACBB3374486296CA518D934B5,
	FontAsset_set_glyphTable_m2753BC6CEE011983C2B4B181867C3EB00CDE87D4,
	FontAsset_get_glyphLookupTable_mD04A90D8262F1963EDC472272B67BBFAF73DEEA5,
	FontAsset_get_characterTable_mC77FAE1355269834F7C8A2D46AFB4BFE7B7AD72D,
	FontAsset_set_characterTable_m44703292F669F2F6D4920EB9427077E24FB1512C,
	FontAsset_get_characterLookupTable_m7E76D6C706C5CEB04A9541C68AE6D9E5C75F0FFC,
	FontAsset_get_atlasTexture_mC49216F40093C7AC4FA5DA68F9F5C9FCC83B8F27,
	FontAsset_get_atlasTextures_mADD7A506F0444A1EE4F1D52536B0C5DA9BE35075,
	FontAsset_set_atlasTextures_m5315BA4903B77742EFA1E54CEA2AF12726B10A99,
	FontAsset_get_atlasTextureCount_mC20300C53E52D7A8351DE296BAD565268568119F,
	FontAsset_get_isMultiAtlasTexturesEnabled_mF222228A76102BB0EA593A60439D22F912761F1E,
	FontAsset_set_isMultiAtlasTexturesEnabled_mA470AF6D312989E752C68DC0FD5700235877566B,
	FontAsset_get_clearDynamicDataOnBuild_mC1F714E56F087B29E0A3B43D820EDCEB78E9EE75,
	FontAsset_set_clearDynamicDataOnBuild_mA1C6F298742DF78EC0F81157F0E04246F8B82F7E,
	FontAsset_get_atlasWidth_mE711550FDD4B5F988B77AB5D332A80A34B5CF364,
	FontAsset_set_atlasWidth_mFFB9D37EB1C648384ED1426B42E26A4104D329B1,
	FontAsset_get_atlasHeight_m306FBF7D35C39123A4770E147FAF95B1B8DE8086,
	FontAsset_set_atlasHeight_m7116DFD32F38971CE39D7F4BF84CB5217DCAA2B5,
	FontAsset_get_atlasPadding_m251A35FB5F499EE66CC2E2150CBEDB2C8C5D5581,
	FontAsset_set_atlasPadding_mB34AA836A3D02722ABED71B3583D767560CA956D,
	FontAsset_get_atlasRenderMode_m036D4BA220E5D4B0C407CA6BC1B09D8914B5058A,
	FontAsset_set_atlasRenderMode_m993764193CE75D57DC4CC755336596681A7866D2,
	FontAsset_get_usedGlyphRects_mE039AEF3AE45A15A86B2C0F774E6ED58AFA2F341,
	FontAsset_set_usedGlyphRects_mBF80C1063C0A274AD95F55C43DA734E126F6643F,
	FontAsset_get_freeGlyphRects_mCDAEF0519586C5248BBEDEAA85086CC117903E88,
	FontAsset_set_freeGlyphRects_mED3C0E01ABFC63CE700C701476BA2B66D112AA9B,
	FontAsset_get_fontFeatureTable_m7C4EB9A655B237CE02FAF7B8B16C2F2863FE5070,
	FontAsset_set_fontFeatureTable_m3FD11B99122416777808E1CE5414D7BA40920C3B,
	FontAsset_get_fallbackFontAssetTable_m43303BFBE8A8C55D8CE8A67C47EFAFF5A712CB69,
	FontAsset_set_fallbackFontAssetTable_mE22C3D2323111FD6A5DF9847FB812BD41E18832E,
	FontAsset_get_fontAssetCreationEditorSettings_m024033F91B976A8EAA5CBE67D3DB2A756B91CF01,
	FontAsset_set_fontAssetCreationEditorSettings_mF7EE6A46807D78A7E99872171D2AD774DE20C7EB,
	FontAsset_get_regularStyleWeight_m6C4B4D4CAD36800E6E686A05A5DB8D4475F2707F,
	FontAsset_set_regularStyleWeight_m2D1E5440A5E1794A003FF087A87393DA9A114385,
	FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1,
	FontAsset_set_regularStyleSpacing_m7CCE54FB9163D65A6B40269B2BDD30199023E797,
	FontAsset_get_boldStyleWeight_m804ACC85DD80DC72DB4BCC83C3FB866411F8EFCA,
	FontAsset_set_boldStyleWeight_m204B04CF9E98AD8669025BFDC0EF3CE9AB5CBBA2,
	FontAsset_get_boldStyleSpacing_mB8CF4F4880B110E41D566648FF1D995010CF1FF0,
	FontAsset_set_boldStyleSpacing_m62DAA35837E8563DD76E3D162B6DB59BE3804914,
	FontAsset_get_italicStyleSlant_m69E70060C6E7940B4ACE61F2B7CB8965F86DA96B,
	FontAsset_set_italicStyleSlant_m223875ED81B0397CA36E94A6F346AEE68510C0D2,
	FontAsset_get_tabMultiple_m9C0422A00BFCF82091F14F4E303E2717247350AE,
	FontAsset_set_tabMultiple_mC927B74D27FBB94245E09FE39D9F6749AF07017B,
	FontAsset_CreateFontAsset_mCEBA2B83D9355D570A4B115E529DBBAB30C53931,
	FontAsset_CreateFontAsset_mEB7722C56F39849ED3BF9A934DA9CB5D5E586D97,
	FontAsset_CreateFontAsset_mCCDD828A47635EA30F5AA67EC244BE2929D8E1F7,
	FontAsset_CreateFontAsset_m23E71782F785F220F1DD2BBBEB3322B3D4A2750C,
	FontAsset_CreateFontAsset_m87F9CF95DFE84FE372688E2D76610A552C64E971,
	FontAsset_CreateFontAssetInstance_mFEFE28AC7D600C71046F743917BE70DC5A7532A0,
	FontAsset_Awake_mB7906A1E21F5FAB84A023B97435F75C09EAB92ED,
	FontAsset_OnDestroy_m3587016A089072C5C03168AA4C6AA1956FE12785,
	FontAsset_ReadFontAssetDefinition_m6D84DBCB130D530B2F78A7E24232D8A6A81AEC48,
	FontAsset_InitializeDictionaryLookupTables_m29A4AEF49CF11A0E49C229EF13B2262AE66757FF,
	FontAsset_InitializeGlyphLookupDictionary_m82782B7B5C602AD5097A016BF668868C0892CCF6,
	FontAsset_InitializeCharacterLookupDictionary_m8886A4CA911334BD319AB78F1CBBD68E13624BB6,
	FontAsset_InitializeGlyphPaidAdjustmentRecordsLookupDictionary_mDF1C20792344999B9CF500685E6256B0642CE7DD,
	FontAsset_AddSynthesizedCharactersAndFaceMetrics_m203BD62D0A537A6EA7CD7DBA1FF9A94301492933,
	FontAsset_AddSynthesizedCharacter_m6ABFCE6454A09D5CF7914F318DDC79198C47F9EA,
	FontAsset_AddCharacterToLookupCache_mB90E06CE313CC0BB6F81415BF8FB4E043108EED8,
	FontAsset_LoadFontFace_m64C78A2FE5DA2E7029E43B467A1B242827B45B4F,
	FontAsset_SortCharacterTable_m9A551DF3B19E246E8C4BE86463E0ED1DEB27D321,
	FontAsset_SortGlyphTable_mC853714CB002D923A19C3A925BB24D6BF42A08CD,
	FontAsset_SortFontFeatureTable_m072B32D6D8C562F60D3D6CBCC7DCB3282EDD587F,
	FontAsset_SortAllTables_mACA7063865A460F5949E5B8A8D978D588124A094,
	FontAsset_HasCharacter_m6BAF48714E1BF5D8EE7ACF33F774C8C6EEE452F3,
	FontAsset_HasCharacter_mE87EEF6CDA1F4E1D6928CC9A3C01A91922D4FB21,
	FontAsset_HasCharacter_Internal_mDC0D2954E0975A7DBC8829E894CDBCABEA7D6A60,
	FontAsset_HasCharacters_mD670CCEB48448CE5C1430B938F99D4FC659FB2F8,
	FontAsset_HasCharacters_m97A50BC627C163418CAE0B42A50893057B025E90,
	FontAsset_HasCharacters_m048839FDD1876CDCA3C5A744592545B46C75E15B,
	FontAsset_GetCharacters_mEDFC9A3D23C31F641DC97FB5D19577C2EE3E7D23,
	FontAsset_GetCharactersArray_m0BCE8CB0B1BB70A75F7A1FF5C97C49FE6352AC28,
	FontAsset_GetGlyphIndex_mF20097CDB68A8CE866E61D4C237FBB95257A9745,
	FontAsset_RegisterFontAssetForFontFeatureUpdate_mA98498DA5D471A6504E3BC67AEAD6462B1B62C7F,
	FontAsset_UpdateFontFeaturesForFontAssetsInQueue_m0EB26B49967B52B2EEFF4A2F9234D994B9E62621,
	FontAsset_RegisterAtlasTextureForApply_m2123B35C0CD237E87C111A32C33D3D81AB8C3D08,
	FontAsset_UpdateAtlasTexturesInQueue_m70787779BB9231349342D9036761321A34286A70,
	FontAsset_UpdateFontAssetInUpdateQueue_mF38C30B72EBABBF805BD542501783E2730F8B9B8,
	FontAsset_TryAddCharacters_m7F1D0CB7E4D9B8D3CE44D4D01F9CDCEFD4D1B46B,
	FontAsset_TryAddCharacters_m9618B4F12C004B8267E0D17ED81B94BE48D85119,
	FontAsset_TryAddCharacters_m5E282618D9ED92AD0112BC7B6B2C3B1066DDFA63,
	FontAsset_TryAddCharacters_mDA1C3A68799C84A80C27CDB84482684F6822137F,
	FontAsset_TryAddCharacterInternal_mCDC9AE2C61B9F73B8879C3F5AE00598A67B2BA7F,
	FontAsset_TryGetCharacter_and_QueueRenderToTexture_mA76A244F58E0F2978178FBBEB18F2E0DCA568AEC,
	FontAsset_TryAddGlyphsToAtlasTextures_m83F7EDB3193B3C9A4FA86B89A51E9FA6A41F6834,
	FontAsset_TryAddGlyphsToNewAtlasTexture_m8F98FBF7A0EC1B37C4DB43536DA42D3864F6F3AB,
	FontAsset_SetupNewAtlasTexture_m38F81BE1582A15DDDB950E7AAC650CD9B7D14168,
	FontAsset_UpdateAtlasTexture_m30D7C235A878B1A33F2A3891D8096F534C10F6C5,
	FontAsset_UpdateGlyphAdjustmentRecords_mD1C9297EA75EA767A823709CC39B6E57905E22A3,
	FontAsset_UpdateGlyphAdjustmentRecords_mC9882537E81709FE1EFA9B744D88C6C32ACEDF52,
	FontAsset_UpdateGlyphAdjustmentRecords_m2D0444352012E8DFDD6036025886EC0CED0AD82A,
	FontAsset_UpdateGlyphAdjustmentRecords_m9410421BA99635607C50EED1C9C374570EFABC60,
	NULL,
	FontAsset_ClearFontAssetData_m225ADFCBB0CFD481E18637F3D3FDFFEAFC6FE9A1,
	FontAsset_ClearFontAssetDataInternal_mD3DB3516BB6D61F0A9630D9F6958F474DFE044F7,
	FontAsset_UpdateFontAssetData_mAAC0ED05410942C08E8EFD4678F9565FD8C373D4,
	FontAsset_ClearFontAssetTables_m38470615509BEFAE39C90C234D8B460F05824C39,
	FontAsset_ClearAtlasTextures_m5B320A65E1CD35F2C17E27F09158F8E9BDA9EA2B,
	FontAsset_DestroyAtlasTextures_mBE2810F8C55E286B5B7ABE24A6F9132F51CBE027,
	FontAsset__ctor_mD55676BD025F9D05DBC9A5B32480E092169B9D45,
	FontAsset__cctor_m644B5E11138863C477F86E3EE75FA0A82CC6BB29,
	U3CU3Ec__cctor_m7CA74DE9372A832562FB866FB79E5A0CB25D23E1,
	U3CU3Ec__ctor_m3CDF0903C024856278B5A7DF46C7EFCBA6F6B651,
	U3CU3Ec_U3CSortCharacterTableU3Eb__144_0_m5655A423C374C42F5761CFBFBEA41E6566421B0B,
	U3CU3Ec_U3CSortGlyphTableU3Eb__145_0_m2BB897F83BD1FE22634624544AFCD8B5988788A0,
	FontAssetUtilities_GetCharacterFromFontAsset_m2AADCA590977FA4C398D4ECF6E7DF0BE77527801,
	FontAssetUtilities_GetCharacterFromFontAsset_Internal_m9B21F45D7C1568509888D6CAC3F428DD4B874AA4,
	FontAssetUtilities_GetCharacterFromFontAssets_mB1612268F7A1926C2C39A4EFFB5AB795F234F9DF,
	FontAssetUtilities_GetSpriteCharacterFromSpriteAsset_m0B6133849B1B4BDEF41D1DEADD26B8EB6174DD09,
	FontAssetUtilities_GetSpriteCharacterFromSpriteAsset_Internal_mD1A527D6C350A716AEA20E61BBE7D958C4960060,
	FontFeatureTable_get_glyphPairAdjustmentRecords_mABE78F7C2EA171927CC33170617D72E6C976323E,
	FontFeatureTable__ctor_m5F00F284C63F1867F679A3250ABFC1393C27025C,
	FontFeatureTable_SortGlyphPairAdjustmentRecords_m2F5E2ED405FCAEE946CE5CF81163DDCC1B02A905,
	U3CU3Ec__cctor_m1B7CCD6084985489A1607E2A0038672BB2080482,
	U3CU3Ec__ctor_m51815D1379A3BDB616D65C006DA7AB32406723F4,
	U3CU3Ec_U3CSortGlyphPairAdjustmentRecordsU3Eb__6_0_m4A2B8B22BA5C619432654E7A0F5DEDAE949E12BA,
	U3CU3Ec_U3CSortGlyphPairAdjustmentRecordsU3Eb__6_1_m5BF29DF1AB0CBEC9E1D73F20A998CBEC05DC7572,
	Extents_ToString_m8A1F748127EE9CCCD6FFAF4CE1F38E37C07831AC,
	LinkInfo_SetLinkId_mB4145264190D5C857705261CB27F87C6E10C3F3F,
	MaterialManager_GetFallbackMaterial_m7BB3FDBF4411623DBA57727F2C54A33DA7F22554,
	MaterialManager_GetFallbackMaterial_mEABF84B8A8BC620A6CB6D830089FB6890389C8B6,
	MaterialManager__cctor_m851601D11F644A7CB79FC4FA3B7D716EACB6CC39,
	MaterialReference__ctor_m044AAA2C1079EB25A5534A6E0FA2314F033DB15A,
	MaterialReference_AddMaterialReference_m6C0963F5E7C06B0371F2B18FE177D55B6C4C1105,
	MaterialReference_AddMaterialReference_m04F13DFCB5D0C707877E45A48B6C47CE80FC99E7,
	MaterialReferenceManager_get_instance_m4AB9F74DE21C3A47D7592AD444FACD97A375BE91,
	MaterialReferenceManager_AddFontAsset_m52CD48B3A314C766C40A0D5BAAA092FFD2F6A204,
	MaterialReferenceManager_AddFontAssetInternal_m6F5A4E5ED988BA6F482F015F051ACD19D7B0A005,
	MaterialReferenceManager_AddSpriteAsset_mC871D76124B93F40E57F5E99BAAB51770E347F49,
	MaterialReferenceManager_AddSpriteAssetInternal_m788619DC6BAD5B77E9419ACBDECBCCFE1A6AC97C,
	MaterialReferenceManager_AddFontMaterial_mBE61E1B0E6CBB58695731DC975859E349CA99C8A,
	MaterialReferenceManager_AddFontMaterialInternal_m732F46EF768A41B9519917F4FA1E746E056C745C,
	MaterialReferenceManager_AddColorGradientPreset_m8D59A614318734899E9AAD9924EBF4A18F76777D,
	MaterialReferenceManager_AddColorGradientPreset_Internal_mF27270501EB3725B4CBE4C241B4A2FCD8D871BF1,
	MaterialReferenceManager_TryGetFontAsset_m81063D8799AF27566284930B3D3656A3022A1113,
	MaterialReferenceManager_TryGetFontAssetInternal_m2FECC618624B12D200EB311F59CBEECA7CDBB69D,
	MaterialReferenceManager_TryGetSpriteAsset_m848DD587C2EB15DF11C64095BAD6E34FE7CA8E3A,
	MaterialReferenceManager_TryGetSpriteAssetInternal_mC434A7C6DB005EDBBA52154E2AB0E36ED7083C84,
	MaterialReferenceManager_TryGetColorGradientPreset_m379362C98A5E71979208D750F9699E6F7E3D5C44,
	MaterialReferenceManager_TryGetColorGradientPresetInternal_mD8018B3225786E71F804D629F3107AB75EE5212B,
	MaterialReferenceManager_TryGetMaterial_m54A7E79A8D506AB95FED10236597C60C9F4CC8C1,
	MaterialReferenceManager_TryGetMaterialInternal_mEBFC9CE0A6063B25FEA9070F22FD8AD27107ECE7,
	MaterialReferenceManager__ctor_mC102EC445A27BE8E3968ADB80EF8FEF3BCFB7778,
	MeshInfo__ctor_mCC2410C5590BEA974468F4CECFA874BE966CDE61,
	MeshInfo_ResizeMeshInfo_mE411FE40935FB9CFB7C334B3A1F216A98B96F5FC,
	MeshInfo_Clear_m06992FEB7AC9B2AE1728BEDFC8D8A39DE1AAD475,
	MeshInfo_ClearUnusedVertices_m7B6003EF4CA72C0ABBA4D25DEA8B0BF3934B2830,
	MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1,
	MeshInfo_SwapVertexData_mD145A4C2B45422DFCB2D9697956E16395E717C7F,
	MeshInfo__cctor_mFFE09A28F0CFD120A1F4B3539FDC79122B1ACC48,
	SpriteAsset_get_faceInfo_m54EC5227F682ED6A24F5633283258E6641CDA4DC,
	SpriteAsset_set_faceInfo_m060A5DBBD5941A53BFE9D45E2B637D88ED8223EA,
	SpriteAsset_get_spriteSheet_mC53205114A12A79F7495FA5F5EFC9948F151256B,
	SpriteAsset_set_spriteSheet_m1DE591615ABCBB4B10118BF4C0E1B57F559C6469,
	SpriteAsset_get_spriteCharacterTable_m8D0D65C430AD8BC8C2BC8151DC4672CC0F690E0A,
	SpriteAsset_set_spriteCharacterTable_m38553B81E01B502CCD568A654E9EF3B0D0BCA92D,
	SpriteAsset_get_spriteCharacterLookupTable_mDB0BA7D703F58A05BB765AE44D6244D98C17DE03,
	SpriteAsset_set_spriteCharacterLookupTable_m38F3E7A0A52B82595C87E6A630B156E4D22F2E25,
	SpriteAsset_get_spriteGlyphTable_m491B3F4A5350C38D8B5166A60B7C43ED3608C0BA,
	SpriteAsset_set_spriteGlyphTable_m7402B7CF195E4B9F15DDA3273F49CA460A68DAD3,
	SpriteAsset_Awake_m3A012935612A7EB924A77B85EDCF6C09257F60BE,
	SpriteAsset_UpdateLookupTables_mCC7A470A65A72908C9CDBDDFD17A056188A5C7CE,
	SpriteAsset_GetSpriteIndexFromHashcode_mE73615D1D9A8BB45C3426197EC54B1A002642DE0,
	SpriteAsset_GetSpriteIndexFromUnicode_m321E02B6000E5F6673F5724155C3EF1DE3F5A66B,
	SpriteAsset_GetSpriteIndexFromName_mBCB684ED6E3DF5663A7FDA02CA69C99D9B17281B,
	SpriteAsset_SearchForSpriteByUnicode_mA7D1BEA72B7BB631ADD94B3391C968EE2F94C744,
	SpriteAsset_SearchForSpriteByUnicodeInternal_m9ACF49A920E0594B3E9387AE48BB84490FA14EBE,
	SpriteAsset_SearchForSpriteByUnicodeInternal_m19491D77C3D6F01BB25A85C9B0D96380977CE814,
	SpriteAsset_SearchForSpriteByHashCode_mE89EE4F71AA7F78A18D9C4BABBF8BD393E2A5035,
	SpriteAsset_SearchForSpriteByHashCodeInternal_mC1583A1E630DFC7C4B7424B8A618E68E85738A9C,
	SpriteAsset_SearchForSpriteByHashCodeInternal_m13FE1B5D13A07618190680252FD3354F6047DB9A,
	SpriteAsset_SortGlyphTable_mA700CE5246D5798FA65779BE53179FFF4FFED6E5,
	SpriteAsset_SortCharacterTable_m5447649977AF2C9F62A14415B44CDDD897A53AE1,
	SpriteAsset_SortGlyphAndCharacterTables_m0E2B691E7C1F284E12A88B47B705307E83C7D927,
	SpriteAsset__ctor_mE03F69799389DE8D90E69CD70054955033C4ED3C,
	U3CU3Ec__cctor_m8B8A7374E1675126A3FD5136CDF2731C98F62741,
	U3CU3Ec__ctor_mEFC122BF1D0D0CA8F0EAE9CE353C37A8CFABB5F3,
	U3CU3Ec_U3CSortGlyphTableU3Eb__37_0_mC479CF63F85C34FC407D92E67878B9B2AD99B739,
	U3CU3Ec_U3CSortCharacterTableU3Eb__38_0_m6A3F26D4286DF4F04DC23D23D04E12CA014D6E92,
	SpriteCharacter_get_name_mD5A9CC908308BB48D459973C8844FE1FD7C925B1,
	SpriteCharacter__ctor_m0B3812DF9A667CA2C3AA321DF3403197EEBC83BA,
	SpriteGlyph__ctor_mFFE2D9AA5A28EA0C20C10694569A1E23A664BB4D,
	TextAsset_get_version_m2316C9F212FE4A13335032354A496CAEC86CB25B,
	TextAsset_set_version_m24718A4A6A86F4CE41D9ED1E0F796CCF367516CD,
	TextAsset_get_instanceID_m843A6CAA7FE9322CD19546671D3F0E90A0E27AFB,
	TextAsset_get_hashCode_m4D519E837097D8869A8D38EBD11611FADE411092,
	TextAsset_set_hashCode_mC6ED3271A5EFC05562FD1083BE1C872CB69CFF74,
	TextAsset_get_material_m4B9C02D34426436FDB01F1963A9FDC11D75604EF,
	TextAsset_set_material_mD9988165763E0E72C7FB7537760899EC1841C829,
	TextAsset_get_materialHashCode_m9BAA469D5760D87EEC6E09B9ED3C5902B75017E6,
	TextAsset_set_materialHashCode_m15EE7CCAF81DBAA326049F00788BCC918FDB2631,
	TextAsset__ctor_m2C43EAC2D75854E6724A235794DEAF8A1AF9E786,
	TextColorGradient__ctor_mAF03C3B68C29D94ED1F1517E65477CFC2B078FAC,
	TextColorGradient__ctor_m0712D0C09E7BCBC00909CEB71B43F2276ADB8B55,
	TextColorGradient__ctor_m0A6B9264A8FBABEEC5BA84353D9B3DD7999DD2FF,
	TextColorGradient__cctor_m0C9B1A60EE8153D1DA39DC78EAF62F53C0202C86,
	TextElement_get_elementType_m7BF97842479112227C1C3C83E0E94A176CD7D31A,
	TextElement_get_unicode_m40C69806537940F7BA1D3969713DA10CCBE57BC7,
	TextElement_set_unicode_m99608D824B25E3529236C06BCC0983B5FC094F98,
	TextElement_get_textAsset_m52383A3758AABF5BEA013155765BD1141479685A,
	TextElement_set_textAsset_m3F65429660C011F6F25B65D6BA7C4B2CF05659FA,
	TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2,
	TextElement_set_glyph_m6E8E2F1366089FA638680F1CF53F6F5027D022A5,
	TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56,
	TextElement_set_glyphIndex_mFD72B93816998BE291DA6379EAF5E4153BC64F6C,
	TextElement_get_scale_mD16946900449FEE9E2F86B2C4C71E26F4491A0E6,
	TextElement_set_scale_m83FC0850B2B0F31BDFC779954923F50FD06DC03F,
	TextElement__ctor_m8CB701D9A4C0444E834F178D97E9FC63E6D7E0B9,
	TextGenerationSettings_Equals_mA5EDDF0453F2A7314AF5E1FE29F4138CD97E52D5,
	TextGenerationSettings_Equals_mDCEEB056B70FC65ED6065E3BFE8D69D823DFEFD0,
	TextGenerationSettings_GetHashCode_m1F750434FCE1853C36A579827B064619E85453E0,
	TextGenerationSettings__ctor_mA20608A16443434DAE9FEF0BF8BD076270FA660E,
	TextGenerator_GetTextGenerator_mE998D0B33A1DE99A0DE3436AE0FA47B997E21781,
	TextGenerator_GenerateText_mCF9D4EB0CC6D0BEA0136B23FCEE39EA9A48D6B5F,
	TextGenerator_GetCursorPosition_mE6F486439659265C1B4ACF04B9DAA0452CAABE41,
	TextGenerator_GetPreferredValues_m00CB10940AD7561839EBA19B67E32B92B19F1CB6,
	TextGenerator_Prepare_mD0A24977334138340CA73FB9787627373C6AA255,
	TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831,
	TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936,
	TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61,
	TextGenerator_ValidateHtmlTag_m9C85462F15A6165B10E4C4EE93620AC1021BE5CD,
	TextGenerator_SaveGlyphVertexInfo_m0CD6E1D45488FFC6675294AC64F40AC23C986A09,
	TextGenerator_SaveSpriteVertexInfo_m4B47901F01927E7CC4E486A1C4354AFBF4D138A5,
	TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E,
	TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B,
	TextGenerator_ClearMesh_mE8A81193AF7ACE3CFE55E0C18FCCD751503A997F,
	TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991,
	TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950,
	TextGenerator_SetArraySizes_mF0041F3D79936C05EB87DEE399F1DC389CCD1BD5,
	TextGenerator_GetTextElement_mC46F0E788A0F6EB5A62601BCE4F383C3143C78CB,
	TextGenerator_ComputeMarginSize_m485F8B01196058B15F597DE99D6F6A47FA539D3F,
	TextGenerator_GetSpecialCharacters_mA82879FA537C58223BB660E797AC135A8E07B492,
	TextGenerator_GetEllipsisSpecialCharacter_m5139CAE03CD2E25C9A528A6A6FC984A8515C2460,
	TextGenerator_GetUnderlineSpecialCharacter_mE5E9D5DEB9A7758333CDDCAD05EF25F076EC1AD5,
	TextGenerator_GetPaddingForMaterial_mE5A4DEF3F64851861C092F7A4FC58C902F775C74,
	TextGenerator_GetPreferredValuesInternal_m125B070164DFEA503C67525D1F418DAF41300ABD,
	TextGenerator_CalculatePreferredValues_mBBE23FA780CF24415963F32F7C500F0394C2545E,
	TextGenerator__ctor_m52E4D01DC28BDF753BF52F6501E7FD2FB2B30D90,
	SpecialCharacter__ctor_m6697A8BF272F0144733EE12368C038F45E99F969,
	TextGeneratorUtilities_Approximately_m2333A8491C1BBC4F26738A240A7AA9E699508E6D,
	TextGeneratorUtilities_HexCharsToColor_mB7D42327546D443ADF83696B99E2CFD921FEE21F,
	TextGeneratorUtilities_HexCharsToColor_m0FC6E21EF35547ADFEA41B876C6FC1CD37C71019,
	TextGeneratorUtilities_HexToInt_mE6FAC19C36EDFE1E5AE08F14483B1D1BB773C61C,
	TextGeneratorUtilities_ConvertToFloat_m5D83113DC84E90EC14F041B5870C73D2AE688978,
	TextGeneratorUtilities_ConvertToFloat_mB4E9E5A7211E9B01EF9482A90AC073886FEB00A5,
	TextGeneratorUtilities_PackUV_mFEB61C8552EE615440A86C18582F5A8117082259,
	TextGeneratorUtilities_StringToCharArray_m8268FA89F86210B39C56D1ED4C0FEBB27DA2713B,
	NULL,
	TextGeneratorUtilities_IsTagName_m8C1935BCF2324F0D59287C5BBAC0CB2980D773F4,
	TextGeneratorUtilities_IsTagName_m96D644793638F2469B031FCBFDBE3793BDCA5689,
	TextGeneratorUtilities_ReplaceOpeningStyleTag_mCE630D2A5A1B3FCF640A2B8E02668C3AB63E0767,
	TextGeneratorUtilities_ReplaceOpeningStyleTag_mCC7B70BC030D71272C3921A6FA25FF9A5E16B8CA,
	TextGeneratorUtilities_ReplaceClosingStyleTag_mC09AB95297B63C4DED7FAAEE45AFB191F0AE2311,
	TextGeneratorUtilities_GetStyle_m1050359E87C4619E7597CB2D793D41FDB96067E5,
	TextGeneratorUtilities_GetUtf32_mAA6CFF8B51E54A1852998106D92FB93F9371CEB7,
	TextGeneratorUtilities_GetUtf16_mD28A180C7A2199550EED77DB8E3C078B9233775F,
	TextGeneratorUtilities_GetTagHashCode_m43B3AAC5D68F9F98E94A8976F450CA89887B6A42,
	TextGeneratorUtilities_GetTagHashCode_m93E064B76CC421C2FE5CEF751147BF05C9A06737,
	TextGeneratorUtilities_FillCharacterVertexBuffers_m4DB26BF6316D0ED0518093F81E7703326B7BF4A7,
	TextGeneratorUtilities_FillSpriteVertexBuffers_m0AA6B96B32824157B84B59AD6E6B77B5F0689FCF,
	TextGeneratorUtilities_AdjustLineOffset_m9B686B22546C23700D8611CBA140B5EEB0527229,
	TextGeneratorUtilities_ResizeLineExtents_m31C939F88EAEDD9CA7475304E55550A3FE98CD19,
	TextGeneratorUtilities_LegacyStyleToNewStyle_m28425B06C6AB2A84893AA950144B76A2D8C1669B,
	TextGeneratorUtilities_LegacyAlignmentToNewAlignment_mA4CAC934F661F28168F132CF2B77D3DF89DBB301,
	TextGeneratorUtilities__cctor_m4A9C9782E18EE8E0BB6783A65370482BBE97F46C,
	TextInfo__ctor_m241E24715CC5F6293DC90A4D25884548BAD0D602,
	TextInfo_Clear_m60412774208F9D920707448E71E89C99233D9128,
	TextInfo_ClearMeshInfo_mCA598F01C7F302CFCD0F508E2DBF072E66CA74F3,
	TextInfo_ClearLineInfo_m986C886D34A324C8C4D30F9D8EF24AC242A10AD7,
	NULL,
	NULL,
	TextInfo__cctor_m2F1EF99C8719E2B8B98D008C4F259413E5C9DBB9,
	FontStyleStack_Clear_m989659363648B27540168E46F23E1EF9877C06E0,
	FontStyleStack_Add_m26E701C9F052EEEBB213B9B8BC6CB8F1F8F6AFCB,
	FontStyleStack_Remove_mC2B4F44A6596E92D6992DBCA298648F8A7416CAB,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	TextResourceManager_AddFontAsset_m593E23B8489420BAB880DBC5F8D12AC006E04662,
	TextResourceManager__cctor_m485811EE8DC7D867DFAFF02ACED0C667E8FDC366,
	FontAssetRef__ctor_m5553FC4D7E51DE97D70CE09E1C99B002A61FFDB5,
	TextSettings_get_version_mB5B7C3F04FFC8DCDFCFF63CFFF7612B768E267CB,
	TextSettings_set_version_m7BEE644EEDD77892C295170F9B2B68BC45C7C6CF,
	TextSettings_get_defaultFontAsset_mC6280464BFEE081DB23243BB94E49C72A0885A1F,
	TextSettings_set_defaultFontAsset_mC0137D9AEB9EE7A9E1B3D7C499414EDD217AF3BA,
	TextSettings_get_defaultFontAssetPath_mF7B1713753CFAE048C745C3572332CE18CD51D3B,
	TextSettings_set_defaultFontAssetPath_m35111382F9C2E3C76FA6B77BABEE8149BDDCC7ED,
	TextSettings_get_fallbackFontAssets_m332526E834C994425141A58C968FD40320573F98,
	TextSettings_set_fallbackFontAssets_mEBEC769B2FF339BDB44D72CB48F0010577889772,
	TextSettings_get_matchMaterialPreset_m4675979547AE4C83E680260EAE5ACBC4FAC53B87,
	TextSettings_set_matchMaterialPreset_mD5A3DDE2D93FE2872C869A2AE0B0C984CF5BC12C,
	TextSettings_get_missingCharacterUnicode_mA707E5E6633633BBB3BAFB96B97A5A995100F3F3,
	TextSettings_set_missingCharacterUnicode_mE3E3E2F902BE89B9FE78F03D3B8C508583D1CDA3,
	TextSettings_get_clearDynamicDataOnBuild_m0C130F53F106D77250F38239FB73DCB97299FB79,
	TextSettings_set_clearDynamicDataOnBuild_m86B73E68953D42C6AE4210BEA5D678768155A1AD,
	TextSettings_get_defaultSpriteAsset_m8FA900F9747B7ADBCD2A2F612E7D977DB58D6445,
	TextSettings_set_defaultSpriteAsset_m6083C46D0B3AFB6816363CF2564D2DB2D1ECFEB9,
	TextSettings_get_defaultSpriteAssetPath_mF57875222B7FACC9B69369305EEEB53FFE7986E0,
	TextSettings_set_defaultSpriteAssetPath_m9C49C00A96230DAF828E629C106B229A4552F753,
	TextSettings_get_fallbackSpriteAssets_mC6D74088EBDFDFBACD581FE4AB4EAA447ED242AD,
	TextSettings_set_fallbackSpriteAssets_mB28744780B58AE04BA7F1275508FF7DEE4E485E5,
	TextSettings_get_missingSpriteCharacterUnicode_m496D85B0D88C91F2A5CC9929C233EAA84831523E,
	TextSettings_set_missingSpriteCharacterUnicode_mFE1AFD04C4AA793559E0A157C9E5472E3C3F6701,
	TextSettings_get_defaultStyleSheet_mDA420960556C00405FA66CBD2DA36807F8F4B4F2,
	TextSettings_set_defaultStyleSheet_m2867A0B047E623E4485F10EE717FF0B46BAAECEE,
	TextSettings_get_styleSheetsResourcePath_mE65A055D1C99CA2048BE6F246258EF262E43C4E6,
	TextSettings_set_styleSheetsResourcePath_m19A5C893047D78B43AC5EB43FB9EA79792464C05,
	TextSettings_get_defaultColorGradientPresetsPath_m1571454580E1F0DC859D3F201BB1F6355A5DBB8E,
	TextSettings_set_defaultColorGradientPresetsPath_m951D5A7AE71C87BFA5B9B8CE8EA2F78A474FE01D,
	TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04,
	TextSettings_set_lineBreakingRules_mB1174FE0F923443130A3D4686C119EDB0430992D,
	TextSettings_get_displayWarnings_m3CA9FCB44B30CC06F54CD3716D68285FF844DF83,
	TextSettings_set_displayWarnings_m08373EE3900E911B4021CBF8AF915DA69856CC20,
	TextSettings_InitializeFontReferenceLookup_m34B5FB3D61296A7620196398D267812EEFCE0B04,
	TextSettings_GetCachedFontAssetInternal_m9308E0DDEF8F6D8ACA17DAADB43745C860788202,
	TextSettings__ctor_m860D28B10258792A195E1C6391479E16D04CA8BF,
	FontReferenceMap__ctor_mA94127060F9F3FDC3093D9356832503BFBCE44F5,
	TextShaderUtilities_get_ShaderRef_MobileSDF_m07A195460277381844289DBB77C18BD8D625280D,
	TextShaderUtilities_get_ShaderRef_MobileBitmap_m668C39791DB1388D169A99FBD01E30B0C90C13DC,
	TextShaderUtilities__cctor_m307B99F084FCE6CE802EB507756CBAB9C2E43CD7,
	TextShaderUtilities_GetShaderPropertyIDs_mE049EE63FF1F02C91EA3B6FA0CB82FE2C6DA526E,
	TextShaderUtilities_UpdateShaderRatios_m7ACDAE788233935CE733F66FFA6AE1995671A29A,
	TextShaderUtilities_IsMaskingEnabled_m9B499B7017691BA2805367567166484812807E45,
	TextShaderUtilities_GetPadding_m2745B16C068222A2DCFA6EAD1A497D66F0A17BFA,
	TextStyle_get_hashCode_mA1F4D3630B6AE71C2A31F94B7054C28BDD96084F,
	TextStyle_get_styleOpeningTagArray_m32B909EFDDBCFFECC7D1F4D551DCB520A72240EA,
	TextStyle_get_styleClosingTagArray_mB5F9A0BD01EF3E6ABFF44311ADF2A1511D838033,
	TextStyle_RefreshStyle_m2D0771408F06C24EF303749ED8E656C800575BDB,
	TextStyleSheet_get_styles_m7916C62D70AA430314D85EA5B5A778FFAE1544DB,
	TextStyleSheet_GetStyle_m648B766D750E1B37DD126918BF7EB22DDFD21D29,
	TextStyleSheet_GetStyle_mF87D8108EEF60C3FC32A2B01D5C1C23D3F22A4D1,
	TextStyleSheet_RefreshStyles_m92525DE6F7951D03D906E18EC89349AA2794AEC5,
	TextStyleSheet_LoadStyleDictionaryInternal_m482E4CDF0CD2ED291F85869E141EEB5EC21F6D81,
	TextStyleSheet__ctor_m1A0B93B55B12CE15FFF1053443179BD010022B75,
	TextUtilities_ToUpperFast_m1B4220B35AD2E271021CB352FF5321B922AB56B8,
	TextUtilities_ToUpperASCIIFast_mCA372CC9A0CF7A2B86CC2C3914CB7FA5D3441CFF,
	TextUtilities_GetHashCodeCaseInSensitive_m4248854DDCB679D1C66D4B49050764D9839CE98E,
	TextUtilities_UintToString_mBD2991FDADB67054E3EEC452E58316101026B8DD,
	UnicodeLineBreakingRules_get_leadingCharactersLookup_m1DAC015D7E37112EAE0437E6472AEA0719DFF3DC,
	UnicodeLineBreakingRules_get_followingCharactersLookup_m5510A21873DC5DA66F4A2DFA4C26A5EFAD494D8B,
	UnicodeLineBreakingRules_LoadLineBreakingRules_m4686111E39B00E27AA6AD88762793EEFCCC14A75,
	UnicodeLineBreakingRules_GetCharacters_m998BFBC4A98C3393D2C405CB2BC7A62717B04C40,
	UnicodeLineBreakingRules__ctor_mD94779B4996B56EA84C847EC4DD287AB1A8ADE85,
	UnicodeLineBreakingRules__cctor_m0335FB329027F3D00564801E12A0CB29854F05F4,
};
extern void Extents_ToString_m8A1F748127EE9CCCD6FFAF4CE1F38E37C07831AC_AdjustorThunk (void);
extern void LinkInfo_SetLinkId_mB4145264190D5C857705261CB27F87C6E10C3F3F_AdjustorThunk (void);
extern void MaterialReference__ctor_m044AAA2C1079EB25A5534A6E0FA2314F033DB15A_AdjustorThunk (void);
extern void MeshInfo__ctor_mCC2410C5590BEA974468F4CECFA874BE966CDE61_AdjustorThunk (void);
extern void MeshInfo_ResizeMeshInfo_mE411FE40935FB9CFB7C334B3A1F216A98B96F5FC_AdjustorThunk (void);
extern void MeshInfo_Clear_m06992FEB7AC9B2AE1728BEDFC8D8A39DE1AAD475_AdjustorThunk (void);
extern void MeshInfo_ClearUnusedVertices_m7B6003EF4CA72C0ABBA4D25DEA8B0BF3934B2830_AdjustorThunk (void);
extern void MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1_AdjustorThunk (void);
extern void MeshInfo_SwapVertexData_mD145A4C2B45422DFCB2D9697956E16395E717C7F_AdjustorThunk (void);
extern void SpecialCharacter__ctor_m6697A8BF272F0144733EE12368C038F45E99F969_AdjustorThunk (void);
extern void FontStyleStack_Clear_m989659363648B27540168E46F23E1EF9877C06E0_AdjustorThunk (void);
extern void FontStyleStack_Add_m26E701C9F052EEEBB213B9B8BC6CB8F1F8F6AFCB_AdjustorThunk (void);
extern void FontStyleStack_Remove_mC2B4F44A6596E92D6992DBCA298648F8A7416CAB_AdjustorThunk (void);
extern void FontAssetRef__ctor_m5553FC4D7E51DE97D70CE09E1C99B002A61FFDB5_AdjustorThunk (void);
extern void FontReferenceMap__ctor_mA94127060F9F3FDC3093D9356832503BFBCE44F5_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[15] = 
{
	{ 0x06000088, Extents_ToString_m8A1F748127EE9CCCD6FFAF4CE1F38E37C07831AC_AdjustorThunk },
	{ 0x06000089, LinkInfo_SetLinkId_mB4145264190D5C857705261CB27F87C6E10C3F3F_AdjustorThunk },
	{ 0x0600008D, MaterialReference__ctor_m044AAA2C1079EB25A5534A6E0FA2314F033DB15A_AdjustorThunk },
	{ 0x060000A2, MeshInfo__ctor_mCC2410C5590BEA974468F4CECFA874BE966CDE61_AdjustorThunk },
	{ 0x060000A3, MeshInfo_ResizeMeshInfo_mE411FE40935FB9CFB7C334B3A1F216A98B96F5FC_AdjustorThunk },
	{ 0x060000A4, MeshInfo_Clear_m06992FEB7AC9B2AE1728BEDFC8D8A39DE1AAD475_AdjustorThunk },
	{ 0x060000A5, MeshInfo_ClearUnusedVertices_m7B6003EF4CA72C0ABBA4D25DEA8B0BF3934B2830_AdjustorThunk },
	{ 0x060000A6, MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1_AdjustorThunk },
	{ 0x060000A7, MeshInfo_SwapVertexData_mD145A4C2B45422DFCB2D9697956E16395E717C7F_AdjustorThunk },
	{ 0x06000101, SpecialCharacter__ctor_m6697A8BF272F0144733EE12368C038F45E99F969_AdjustorThunk },
	{ 0x06000123, FontStyleStack_Clear_m989659363648B27540168E46F23E1EF9877C06E0_AdjustorThunk },
	{ 0x06000124, FontStyleStack_Add_m26E701C9F052EEEBB213B9B8BC6CB8F1F8F6AFCB_AdjustorThunk },
	{ 0x06000125, FontStyleStack_Remove_mC2B4F44A6596E92D6992DBCA298648F8A7416CAB_AdjustorThunk },
	{ 0x06000132, FontAssetRef__ctor_m5553FC4D7E51DE97D70CE09E1C99B002A61FFDB5_AdjustorThunk },
	{ 0x06000156, FontReferenceMap__ctor_mA94127060F9F3FDC3093D9356832503BFBCE44F5_AdjustorThunk },
};
static const int32_t s_InvokerIndices[369] = 
{
	5418,
	1186,
	2351,
	7145,
	7308,
	5312,
	4309,
	5284,
	4283,
	5249,
	4248,
	5284,
	4283,
	5284,
	4283,
	5312,
	4309,
	5312,
	4309,
	5312,
	5312,
	4309,
	5312,
	5312,
	5312,
	4309,
	5284,
	5223,
	4219,
	5223,
	4219,
	5284,
	4283,
	5284,
	4283,
	5284,
	4283,
	5284,
	4283,
	5312,
	4309,
	5312,
	4309,
	5312,
	4309,
	5312,
	4309,
	5250,
	4252,
	5354,
	4343,
	5354,
	4343,
	5354,
	4343,
	5354,
	4343,
	5223,
	4219,
	5223,
	4219,
	6706,
	5579,
	8133,
	5600,
	5579,
	5630,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	5418,
	1185,
	2349,
	5284,
	5418,
	5418,
	5418,
	5418,
	2955,
	907,
	910,
	1326,
	427,
	2983,
	8133,
	8133,
	3914,
	8319,
	8497,
	8319,
	8497,
	8497,
	1327,
	877,
	1327,
	877,
	909,
	909,
	5418,
	5223,
	5418,
	5418,
	5418,
	4309,
	4309,
	2281,
	0,
	4219,
	5418,
	5418,
	5418,
	4219,
	5418,
	5418,
	8497,
	8497,
	5418,
	3913,
	3913,
	5694,
	5694,
	5636,
	6720,
	6720,
	5312,
	5418,
	5418,
	8497,
	5418,
	3911,
	3911,
	5312,
	1140,
	7455,
	6706,
	8497,
	369,
	6196,
	6196,
	8458,
	8319,
	4309,
	7663,
	2071,
	7663,
	2071,
	7663,
	2071,
	7172,
	1291,
	7172,
	1291,
	7172,
	1291,
	7172,
	1291,
	5418,
	4283,
	4283,
	4219,
	5418,
	4283,
	2047,
	8497,
	5249,
	4248,
	5312,
	4309,
	5312,
	4309,
	5312,
	4309,
	5312,
	4309,
	5418,
	5418,
	3500,
	3579,
	3524,
	6330,
	6330,
	6330,
	5898,
	6316,
	6316,
	5418,
	5418,
	5418,
	5418,
	8497,
	5418,
	3913,
	3913,
	5312,
	5418,
	5418,
	5312,
	4309,
	5284,
	5284,
	4283,
	5312,
	4309,
	5284,
	4283,
	5418,
	5418,
	4222,
	719,
	8497,
	5223,
	5405,
	4387,
	5312,
	4309,
	5312,
	4309,
	5405,
	4387,
	5354,
	4343,
	5418,
	2983,
	2983,
	5284,
	5418,
	8458,
	7693,
	6345,
	7557,
	2281,
	2281,
	703,
	1494,
	214,
	403,
	1057,
	12,
	205,
	7653,
	5418,
	5418,
	1162,
	160,
	2322,
	4309,
	4309,
	4309,
	1733,
	1753,
	334,
	5418,
	2276,
	7212,
	7310,
	6574,
	8030,
	6742,
	6339,
	6775,
	6416,
	0,
	6524,
	6524,
	5614,
	5614,
	6355,
	7451,
	7381,
	7381,
	6605,
	6605,
	6959,
	6959,
	6400,
	7663,
	8023,
	8023,
	8497,
	5418,
	5418,
	4219,
	5418,
	0,
	0,
	8497,
	5418,
	2955,
	2955,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	8319,
	8497,
	735,
	5312,
	4309,
	5312,
	4309,
	5312,
	4309,
	5312,
	4309,
	5223,
	4219,
	5284,
	4283,
	5223,
	4219,
	5312,
	4309,
	5312,
	4309,
	5312,
	4309,
	5405,
	4387,
	5312,
	4309,
	5312,
	4309,
	5312,
	4309,
	5312,
	4309,
	5223,
	4219,
	5418,
	3763,
	5418,
	2281,
	8458,
	8458,
	8497,
	8497,
	8319,
	7931,
	6741,
	5284,
	5312,
	5312,
	5418,
	5312,
	3757,
	3763,
	5418,
	5418,
	5418,
	8254,
	8268,
	8027,
	8133,
	5312,
	5312,
	8497,
	8133,
	5418,
	8497,
};
static const Il2CppTokenRangePair s_rgctxIndices[5] = 
{
	{ 0x02000032, { 8, 2 } },
	{ 0x0600006F, { 0, 5 } },
	{ 0x0600010A, { 5, 1 } },
	{ 0x06000120, { 6, 1 } },
	{ 0x06000121, { 7, 1 } },
};
extern const uint32_t g_rgctx_List_1_tA286387994A1339C2CF844BE5728698C1E998AFA;
extern const uint32_t g_rgctx_List_1_get_Count_m94023DC2882A00FF3E2A87B830A03C35E07FAED7;
extern const uint32_t g_rgctx_TU5BU5D_tDFCEC986C8C5C9107923D8936ADFFA31D6C82631;
extern const uint32_t g_rgctx_Array_Resize_TisT_tC526A9C1F5DF2DFE47235494265CDBAC2F3C7084_mE8F701D8B9BB79C8767E2F0399D7343270FA5401;
extern const uint32_t g_rgctx_List_1_get_Item_mE8A0A11819707997B5CBE996B1D1A5498DF9FF44;
extern const uint32_t g_rgctx_Array_Resize_TisT_tEF2E41F3E29F027ECE0DB60D5C9004A021F3F849_mC292899DEB57C9835195BD444907F99BA20DB4F9;
extern const uint32_t g_rgctx_Array_Resize_TisT_t140CD6F63B95AD73612429C32ECBB8EA16904CF8_m816A28A4B6981FA39DDF8A1505C5C7FB9F66CFDD;
extern const uint32_t g_rgctx_Array_Resize_TisT_tE4B9F6615C925438B0DAB95179A2B6FFE25204C4_m81C2AE447917E74522EE7EA2F7DFE441F494406C;
extern const uint32_t g_rgctx_TU5BU5D_tF671EEC26D8310D901066C4094937EF74C4BDB43;
extern const uint32_t g_rgctx_Array_Resize_TisT_t221CFDD3BE5C61800E826B7B924C88413E6CFAD5_m821C94A9691801FEC45D00321D6B7312A97302AF;
static const Il2CppRGCTXDefinition s_rgctxValues[10] = 
{
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_tA286387994A1339C2CF844BE5728698C1E998AFA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_m94023DC2882A00FF3E2A87B830A03C35E07FAED7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_tDFCEC986C8C5C9107923D8936ADFFA31D6C82631 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Array_Resize_TisT_tC526A9C1F5DF2DFE47235494265CDBAC2F3C7084_mE8F701D8B9BB79C8767E2F0399D7343270FA5401 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Item_mE8A0A11819707997B5CBE996B1D1A5498DF9FF44 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Array_Resize_TisT_tEF2E41F3E29F027ECE0DB60D5C9004A021F3F849_mC292899DEB57C9835195BD444907F99BA20DB4F9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Array_Resize_TisT_t140CD6F63B95AD73612429C32ECBB8EA16904CF8_m816A28A4B6981FA39DDF8A1505C5C7FB9F66CFDD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Array_Resize_TisT_tE4B9F6615C925438B0DAB95179A2B6FFE25204C4_m81C2AE447917E74522EE7EA2F7DFE441F494406C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_tF671EEC26D8310D901066C4094937EF74C4BDB43 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Array_Resize_TisT_t221CFDD3BE5C61800E826B7B924C88413E6CFAD5_m821C94A9691801FEC45D00321D6B7312A97302AF },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_TextCoreTextEngineModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_TextCoreTextEngineModule_CodeGenModule = 
{
	"UnityEngine.TextCoreTextEngineModule.dll",
	369,
	s_methodPointers,
	15,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	5,
	s_rgctxIndices,
	10,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
